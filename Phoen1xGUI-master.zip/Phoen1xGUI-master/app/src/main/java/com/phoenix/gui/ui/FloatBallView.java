package com.phoenix.gui.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.wufan.client.R;
import com.phoenix.gui.config.ConfigManager;
import com.phoenix.gui.module.ModuleCategory;

import java.util.ArrayList;
import java.util.List;

/**
 * FloatBallView：浮球本身是独立悬浮窗（WRAP_CONTENT）。
 * 菜单展开时，每个 MenuView 也是独立悬浮窗，互不干扰。
 */
public class FloatBallView extends LinearLayout {

    private final List<MenuView> menuViews = new ArrayList<>();
    private boolean menusVisible = false;
    private final Context ctx;

    private final LinearLayout outerBall;
    private final LinearLayout innerBall;
    private ImageView decorationView;

    // 浮球自身的 WindowManager 参数（记录位置供更新用）
    private WindowManager.LayoutParams selfWlp;

    public FloatBallView(Context context) {
        super(context);
        this.ctx = context;
        ConfigManager.init(context);

        setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        ));

        int size = (int)(getScreenHeight() * 0.05);
        outerBall = new LinearLayout(context);
        outerBall.setLayoutParams(new LayoutParams(size, size));
        GradientDrawable grad = new GradientDrawable();
        grad.setColors(new int[]{ThemeManager.getGradientStart(), ThemeManager.getGradientEnd()});
        grad.setGradientType(GradientDrawable.LINEAR_GRADIENT);
        grad.setShape(GradientDrawable.OVAL);
        outerBall.setBackground(grad);
        outerBall.setGravity(Gravity.CENTER);

        int innerSize = (int)(getScreenHeight() * 0.03);
        innerBall = new LinearLayout(context);
        innerBall.setLayoutParams(new LayoutParams(innerSize, innerSize));
        GradientDrawable innerGrad = new GradientDrawable();
        innerGrad.setColor(ThemeManager.getTextPrimary());
        innerGrad.setShape(GradientDrawable.OVAL);
        innerBall.setBackground(innerGrad);

        outerBall.addView(innerBall);
        LinearLayout ctrl = new LinearLayout(context);
        ctrl.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        ctrl.addView(outerBall);
        addView(ctrl);

        setupTouchListeners();
        createMenus();
    }

    /** 旧构造保持兼容（menusContainer 参数忽略） */
    public FloatBallView(Context context, FrameLayout ignored) {
        this(context);
    }

    private void createMenus() {
        menuViews.add(new MenuView(ctx, ModuleCategory.PLAYER,   MenuView.MenuPosition.POSITION_1));
        menuViews.add(new MenuView(ctx, ModuleCategory.WORLD,    MenuView.MenuPosition.POSITION_2));
        menuViews.add(new MenuView(ctx, ModuleCategory.MOVEMENT, MenuView.MenuPosition.POSITION_3));
        menuViews.add(new MenuView(ctx, ModuleCategory.COMBAT,   MenuView.MenuPosition.POSITION_4));
        menuViews.add(new MenuView(ctx, ModuleCategory.VISUAL,   MenuView.MenuPosition.POSITION_5));
        menuViews.add(new MenuView(ctx, ModuleCategory.MISC,     MenuView.MenuPosition.POSITION_6));
    }

    private void setupTouchListeners() {
        final float[] downPos = new float[2];
        final boolean[] hasMoved = {false};
        final long[] downTime = {0};

        setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downPos[0] = event.getRawX();
                    downPos[1] = event.getRawY();
                    hasMoved[0] = false;
                    downTime[0] = System.currentTimeMillis();
                    animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).start();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downPos[0];
                    float dy = event.getRawY() - downPos[1];
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                        hasMoved[0] = true;
                        // 通过 updateViewLayout 移动浮球窗口位置
                        if (selfWlp != null && getParent() != null) {
                            selfWlp.x += (int) dx;
                            selfWlp.y += (int) dy;
                            downPos[0] = event.getRawX();
                            downPos[1] = event.getRawY();
                            OverlayWindowHelper.updateLayout(ctx, this, selfWlp);
                        }
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                    if (!hasMoved[0] && System.currentTimeMillis() - downTime[0] < 300) {
                        toggleMenus();
                    }
                    return true;
            }
            return false;
        });
    }

    /** 注册浮球自身的 wlp，供拖动时 updateViewLayout 使用 */
    public void setSelfWlp(WindowManager.LayoutParams wlp) {
        this.selfWlp = wlp;
    }

    private void toggleMenus() {
        menusVisible = !menusVisible;
        if (menusVisible) showMenus();
        else hideMenus();
    }

    private void showMenus() {
        for (MenuView menu : menuViews) {
            // 每个 MenuView 作为独立悬浮窗，位置由 MenuPosition 决定
            if (menu.getParent() == null) {
                WindowManager.LayoutParams wlp = OverlayWindowHelper.makeWrapParams(menu.getOverlayGravity());
                wlp.x = menu.getOverlayX(getScreenWidth(), getScreenHeight());
                wlp.y = menu.getOverlayY(getScreenWidth(), getScreenHeight());
                WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
                if (wm != null) {
                    try { wm.addView(menu, wlp); } catch (Exception ignored) {}
                }
            }
            menu.show();
        }
        showDecoration();
    }

    private void showDecoration() {
        if (decorationView == null) {
            decorationView = new ImageView(ctx);
            try { decorationView.setImageResource(R.drawable.clickgui_decoration); } catch (Exception ignored) {}
            decorationView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            decorationView.setAlpha(0f);
            float dp = ctx.getResources().getDisplayMetrics().density;
            WindowManager.LayoutParams wlp = OverlayWindowHelper.makeWrapParams(Gravity.BOTTOM | Gravity.START);
            wlp.width  = (int)(150 * dp);
            wlp.height = (int)(190 * dp);
            wlp.x = 0; wlp.y = 0;
            WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) {
                try { wm.addView(decorationView, wlp); } catch (Exception ignored) {}
            }
        }
        decorationView.setVisibility(View.VISIBLE);
        decorationView.setTranslationX(-dpToPx(180));
        decorationView.animate()
            .translationX(0f).alpha(0.92f)
            .setDuration(520).setInterpolator(new DecelerateInterpolator(2.5f))
            .setStartDelay(80).start();
    }

    private void hideDecoration() {
        if (decorationView == null) return;
        decorationView.animate()
            .translationX(-dpToPx(200)).alpha(0f)
            .setDuration(350).setInterpolator(new DecelerateInterpolator(1.5f))
            .setListener(new AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(Animator animation) {
                    decorationView.setVisibility(View.GONE);
                    decorationView.animate().setListener(null);
                }
            }).start();
    }

    private void hideMenus() {
        hideDecoration();
        for (MenuView menu : menuViews) {
            menu.hide();
        }
        // 动画结束后从 WindowManager 移除
        postDelayed(() -> {
            for (MenuView menu : menuViews) {
                OverlayWindowHelper.removeView(ctx, menu);
            }
        }, 320);
    }

    public void show() {
        setVisibility(View.VISIBLE);
        setAlpha(0f); setScaleX(0.8f); setScaleY(0.8f);
        animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(250).start();
    }

    public void hide() {
        if (menusVisible) { hideMenus(); menusVisible = false; }
        OverlayWindowHelper.removeView(ctx, decorationView);
        decorationView = null;
        animate().alpha(0f).scaleX(0.8f).scaleY(0.8f).setDuration(250)
            .withEndAction(() -> setVisibility(View.GONE)).start();
    }

    public void destroy() {
        for (MenuView menu : menuViews) {
            OverlayWindowHelper.removeView(ctx, menu);
            menu.destroy();
        }
        menuViews.clear();
        OverlayWindowHelper.removeView(ctx, decorationView);
        decorationView = null;
        OverlayWindowHelper.removeView(ctx, this);
    }

    private int getScreenHeight() {
        WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics m = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(m);
        return m.heightPixels;
    }

    private int getScreenWidth() {
        WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics m = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(m);
        return m.widthPixels;
    }

    private int dpToPx(float dp) {
        return (int)(dp * ctx.getResources().getDisplayMetrics().density);
    }
}
