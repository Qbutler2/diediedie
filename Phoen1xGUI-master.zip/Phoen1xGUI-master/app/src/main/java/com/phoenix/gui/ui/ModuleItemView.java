package com.phoenix.gui.ui;

import android.animation.ArgbEvaluator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

public class ModuleItemView extends LinearLayout {

    private final Module module;
    private final MenuView parentMenu;

    private final FrameLayout mainContainer;
    private final TextView normalText;
    private final TextView boldText;
    private final SubMenuPanel subMenuPanel;

    // MC风格：左侧状态指示条
    private final View indicatorBar;

    private ValueAnimator colorAnimator;
    private ValueAnimator indicatorAnimator;
    private ValueAnimator touchStateAnimator;
    private final Handler longPressHandler = new Handler(Looper.getMainLooper());
    private Runnable longPressRunnable;
    private boolean isLongPressing = false;

    private float touchStartX = 0f;
    private float touchStartY = 0f;
    private boolean hasMoved = false;
    private final int touchSlop;

    private float scaleFactor = 1.0f;
    private boolean lastKnownState = false;

    // 动画参数
    private static final long LONG_PRESS_DELAY        = 500L;
    private static final float PRESS_SCALE            = 0.96f;
    private static final int PRESS_ANIMATION_DURATION = 120;
    private static final int RELEASE_ANIMATION_DURATION = 220;
    private static final int STATE_ANIM_DURATION      = 200;

    private final TimeInterpolator pressInterpolator   = new DecelerateInterpolator();
    private final TimeInterpolator releaseInterpolator = new OvershootInterpolator(1.5f);

    // MC客户端风格颜色
    private static final int COLOR_ENABLED_BG   = 0x1A5FCF50; // 极淡绿色背景
    private static final int COLOR_DISABLED_BG  = Color.TRANSPARENT;
    private static final int COLOR_INDICATOR_ON = ThemeManager.COLOR_MODULE_ON;  // 绿
    private static final int COLOR_INDICATOR_OFF= 0x33FFFFFF;                    // 淡白

    public ModuleItemView(Context context, Module module, MenuView parentMenu, float scaleFactor) {
        super(context);
        this.module        = module;
        this.parentMenu    = parentMenu;
        this.touchSlop     = ViewConfiguration.get(context).getScaledTouchSlop();
        this.lastKnownState= module.isEnabled();
        this.scaleFactor   = scaleFactor;

        setOrientation(VERTICAL);
        setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        // ===== 水平行（指示条 + 主内容）=====
        LinearLayout rowLayout = new LinearLayout(context);
        rowLayout.setOrientation(LinearLayout.HORIZONTAL);
        rowLayout.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        // ===== 左侧指示条（MC风格）=====
        indicatorBar = new View(context);
        int barW = scaled(3);
        int barH = scaled(28);
        LayoutParams barParams = new LayoutParams(barW, barH);
        barParams.gravity = Gravity.CENTER_VERTICAL;
        barParams.setMargins(scaled(8), 0, scaled(6), 0);
        indicatorBar.setBackground(createIndicatorDrawable(module.isEnabled()));
        rowLayout.addView(indicatorBar, barParams);

        // ===== 主内容区 =====
        mainContainer = createMainContainer();
        normalText    = createNormalText();
        boldText      = createBoldText();
        mainContainer.addView(normalText);
        mainContainer.addView(boldText);
        rowLayout.addView(mainContainer, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        addView(rowLayout, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        // ===== 子菜单（直接加到 VERTICAL 的外层）=====
        subMenuPanel = new SubMenuPanel(context, module, scaleFactor);
        addView(subMenuPanel, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        setupTouchListeners();
        updateVisualState(module.isEnabled(), false);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.HONEYCOMB) {
            setLayerType(LAYER_TYPE_HARDWARE, null);
        }
    }

    // ===== 指示条样式（MC风格小圆角矩形）=====

    private GradientDrawable createIndicatorDrawable(boolean enabled) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setCornerRadius(scaled(1.5f));
        if (enabled) {
            // 启用：绿色渐变（上浅下深）
            d.setColors(new int[]{
                    ThemeManager.getGradientStart(),
                    adjustAlpha(ThemeManager.getGradientStart(), 0.7f)
            });
            d.setGradientType(GradientDrawable.LINEAR_GRADIENT);
            d.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        } else {
            d.setColor(0x33FFFFFF); // 禁用：淡白
        }
        return d;
    }

    private int adjustAlpha(int color, float factor) {
        int alpha = Math.round(Color.alpha(color) * factor);
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    // ===== 主容器 =====

    private FrameLayout createMainContainer() {
        FrameLayout container = new FrameLayout(getContext());
        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        container.setLayoutParams(params);
        container.setBackgroundColor(Color.TRANSPARENT);
        return container;
    }

    private TextView createNormalText() {
        TextView tv = new TextView(getContext());
        tv.setText(module.getName());
        tv.setTextSize(11f * scaleFactor);
        tv.setTextColor(ThemeManager.getTextSecondary()); // 禁用时稍暗
        tv.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        int pV = scaled(8), pH = scaled(10);
        tv.setPadding(pH, pV, pH, pV);
        tv.setTypeface(Typeface.DEFAULT);
        tv.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT));
        return tv;
    }

    private TextView createBoldText() {
        TextView tv = new TextView(getContext());
        tv.setText(module.getName());
        tv.setTextSize(11f * scaleFactor);
        tv.setTextColor(ThemeManager.getTextPrimary()); // 启用时纯白
        tv.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        int pV = scaled(8), pH = scaled(10);
        tv.setPadding(pH, pV, pH, pV);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT));
        tv.setAlpha(0f);
        return tv;
    }

    // ===== 触摸 =====

    private void setupTouchListeners() {
        mainContainer.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    touchStartX = event.getX();
                    touchStartY = event.getY();
                    hasMoved = false;
                    isLongPressing = false;
                    longPressRunnable = () -> {
                        if (!hasMoved) {
                            isLongPressing = true;
                            onLongPress();
                        }
                    };
                    longPressHandler.postDelayed(longPressRunnable, LONG_PRESS_DELAY);
                    animateTouchState(true);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = Math.abs(event.getX() - touchStartX);
                    float dy = Math.abs(event.getY() - touchStartY);
                    boolean oob = event.getX() < 0 || event.getX() > getWidth()
                               || event.getY() < 0 || event.getY() > getHeight();
                    if (!hasMoved && (dx > touchSlop || dy > touchSlop || oob)) {
                        hasMoved = true;
                        cancelLongPressDetection();
                        animateTouchState(false);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    cancelLongPressDetection();
                    animateTouchState(false);
                    if (!hasMoved && !isLongPressing) {
                        module.toggle();
                        lastKnownState = module.isEnabled();
                        updateVisualState(lastKnownState, true);
                    }
                    isLongPressing = false;
                    hasMoved = false;
                    return true;
            }
            return false;
        });
    }

    private void animateTouchState(boolean pressed) {
        if (touchStateAnimator != null) touchStateAnimator.cancel();
        final float startScale = mainContainer.getScaleX();
        final float endScale   = pressed ? PRESS_SCALE : 1.0f;

        touchStateAnimator = ValueAnimator.ofFloat(0f, 1f);
        touchStateAnimator.setDuration(pressed ? PRESS_ANIMATION_DURATION : RELEASE_ANIMATION_DURATION);
        touchStateAnimator.setInterpolator(pressed ? pressInterpolator : releaseInterpolator);
        touchStateAnimator.addUpdateListener(a -> {
            float f = a.getAnimatedFraction();
            float s = startScale + (endScale - startScale) * f;
            mainContainer.setScaleX(s);
            mainContainer.setScaleY(s);
        });
        touchStateAnimator.start();
    }

    private void onLongPress() {
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
        subMenuPanel.toggle();
    }

    private void cancelLongPressDetection() {
        if (longPressRunnable != null) longPressHandler.removeCallbacks(longPressRunnable);
        longPressRunnable = null;
    }

    // ===== 视觉状态更新（MC风格）=====

    public void updateVisualState(boolean isEnabled, boolean animated) {
        if (animated) {
            animateToState(isEnabled);
        } else {
            setStateImmediately(isEnabled);
        }
    }

    private void setStateImmediately(boolean isEnabled) {
        // 指示条
        indicatorBar.setBackground(createIndicatorDrawable(isEnabled));

        // 背景色（启用时有极淡绿色背景）
        mainContainer.setBackgroundColor(isEnabled ? COLOR_ENABLED_BG : COLOR_DISABLED_BG);

        // 文字
        normalText.setAlpha(isEnabled ? 0f : 1f);
        boldText.setAlpha(isEnabled ? 1f : 0f);
    }

    private void animateToState(boolean isEnabled) {
        // ── 背景色动画 ──
        if (colorAnimator != null) colorAnimator.cancel();
        int fromBg = isEnabled ? COLOR_DISABLED_BG : COLOR_ENABLED_BG;
        int toBg   = isEnabled ? COLOR_ENABLED_BG  : COLOR_DISABLED_BG;
        colorAnimator = ValueAnimator.ofObject(new ArgbEvaluator(), fromBg, toBg);
        colorAnimator.setDuration(STATE_ANIM_DURATION);
        colorAnimator.addUpdateListener(a -> mainContainer.setBackgroundColor((int) a.getAnimatedValue()));
        colorAnimator.start();

        // ── 指示条动画（颜色切换）──
        if (indicatorAnimator != null) indicatorAnimator.cancel();
        int fromInd = isEnabled ? COLOR_INDICATOR_OFF : COLOR_INDICATOR_ON;
        int toInd   = isEnabled ? COLOR_INDICATOR_ON  : COLOR_INDICATOR_OFF;
        indicatorAnimator = ValueAnimator.ofObject(new ArgbEvaluator(), fromInd, toInd);
        indicatorAnimator.setDuration(STATE_ANIM_DURATION);
        indicatorAnimator.addUpdateListener(a -> {
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.RECTANGLE);
            d.setCornerRadius(scaled(1.5f));
            d.setColor((int) a.getAnimatedValue());
            indicatorBar.setBackground(d);
        });
        indicatorAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                // 结束后设置最终的渐变指示条
                indicatorBar.setBackground(createIndicatorDrawable(isEnabled));
            }
        });
        indicatorAnimator.start();

        // ── 文字动画 ──
        normalText.animate().alpha(isEnabled ? 0f : 1f).setDuration(STATE_ANIM_DURATION).start();
        boldText.animate().alpha(isEnabled ? 1f : 0f).setDuration(STATE_ANIM_DURATION).start();
    }

    // ===== 公开接口 =====

    public void syncWithModuleState(boolean currentState) {
        if (lastKnownState != currentState) {
            lastKnownState = currentState;
            updateVisualState(currentState, true);
        }
    }

    public void updateScale(float scaleFactor) {
        this.scaleFactor = scaleFactor;

        float textSize = 11f * scaleFactor;
        int pV = scaled(8), pH = scaled(10);

        normalText.setTextSize(textSize);
        normalText.setPadding(pH, pV, pH, pV);
        boldText.setTextSize(textSize);
        boldText.setPadding(pH, pV, pH, pV);

        // 更新指示条尺寸
        LayoutParams barParams = (LayoutParams) indicatorBar.getLayoutParams();
        barParams.width  = scaled(3);
        barParams.height = scaled(28);
        barParams.setMargins(scaled(8), 0, scaled(6), 0);
        indicatorBar.setLayoutParams(barParams);

        subMenuPanel.updateScale(scaleFactor);
        requestLayout();
    }

    public void updateThemeColor() {
        // 如果启用，重新渲染指示条颜色
        if (module.isEnabled()) {
            indicatorBar.setBackground(createIndicatorDrawable(true));
        }
    }

    public void closeSubMenuIfOpen() {
        if (subMenuPanel.isOpen()) subMenuPanel.forceCollapse();
    }

    public void cancelAllAnimations() {
        if (colorAnimator     != null) colorAnimator.cancel();
        if (indicatorAnimator != null) indicatorAnimator.cancel();
        if (touchStateAnimator!= null) touchStateAnimator.cancel();
        mainContainer.animate().cancel();
        normalText.animate().cancel();
        boldText.animate().cancel();
        cancelLongPressDetection();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        cancelAllAnimations();
        longPressHandler.removeCallbacksAndMessages(null);
    }

    // ===== 工具 =====

    private int scaled(int baseDp) {
        return (int) (dpToPx(baseDp) * scaleFactor);
    }

    private float scaled(float baseDp) {
        return dpToPx((int) baseDp) * scaleFactor;
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}
