package com.phoenix.gui.ui;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import com.phoenix.gui.config.ConfigManager;

import java.util.ArrayList;
import java.util.List;

public class ThemeManager {

    private static final String CONFIG_MODULE_NAME = "GlobalTheme";
    private static final String CONFIG_KEY_THEME_COLOR = "theme_color";
    private static final int DEFAULT_THEME_COLOR = 0xFF5FCF50; // MC风格绿色

    private static int themeColor = DEFAULT_THEME_COLOR;

    // 背景色 - 更深更沉稳
    private static int bgPrimary    = 0xFF111414;
    private static int bgSecondary  = 0xFF0D1010;
    private static int bgDisabled   = 0xFF1A1A1A;

    // 文字色
    private static int textPrimary   = 0xFFFFFFFF;
    private static int textSecondary = 0xFFAAAAAA;
    private static int textTertiary  = 0xFF666666;
    private static int textOnTheme   = 0xFF0D1010;

    private static int stateDisabled = 0xFF333333;

    // 发光色 - 用主题色发光
    private static int glowColor = 0x665FCF50;

    // 玻璃背景 - 半透明黑，匹配MC客户端的 Color(0,0,0,130)
    private static int glassBackground = 0x82000000;

    // 渐变色 - MC风格绿→蓝
    private static int gradientStart = 0xFF5FCF50;
    private static int gradientEnd   = 0xFF307593;

    // 通知状态色（对应MC客户端的 SUCCESS/WARNING/INFO）
    public static final int COLOR_SUCCESS = 0xC85F8F50; // 绿
    public static final int COLOR_WARNING = 0xC88F5050; // 红
    public static final int COLOR_INFO    = 0xC8307593; // 蓝
    public static final int COLOR_MODULE_ON  = 0xFF5FCF50; // 启用绿
    public static final int COLOR_MODULE_OFF = 0xFF555555; // 禁用灰

    // 渐变动画
    private static boolean gradientAnimEnabled = false;
    private static int gradientAnimColorA     = 0xFF5FCF50;
    private static int gradientAnimColorB     = 0xFF307593;
    private static int gradientAnimIntervalMs = 2000;   // 单次渐变时长
    private static int gradientAnimStepMs     = 16;     // 每帧间隔
    private static final Handler animHandler  = new Handler(Looper.getMainLooper());
    private static float gradientAnimProgress = 0f;
    private static boolean gradientAnimDir    = true;   // true=A->B, false=B->A

    private static final Runnable animRunnable = new Runnable() {
        @Override public void run() {
            if (!gradientAnimEnabled) return;
            float step = (float) gradientAnimStepMs / gradientAnimIntervalMs;
            if (gradientAnimDir) {
                gradientAnimProgress += step;
                if (gradientAnimProgress >= 1f) { gradientAnimProgress = 1f; gradientAnimDir = false; }
            } else {
                gradientAnimProgress -= step;
                if (gradientAnimProgress <= 0f) { gradientAnimProgress = 0f; gradientAnimDir = true; }
            }
            int r = (int)(Color.red(gradientAnimColorA)   + (Color.red(gradientAnimColorB)   - Color.red(gradientAnimColorA))   * gradientAnimProgress);
            int g = (int)(Color.green(gradientAnimColorA) + (Color.green(gradientAnimColorB) - Color.green(gradientAnimColorA)) * gradientAnimProgress);
            int b = (int)(Color.blue(gradientAnimColorA)  + (Color.blue(gradientAnimColorB)  - Color.blue(gradientAnimColorA))  * gradientAnimProgress);
            themeColor = Color.rgb(r, g, b);
            glowColor  = (themeColor & 0x00FFFFFF) | 0x66000000;
            notifyListeners();
            animHandler.postDelayed(this, gradientAnimStepMs);
        }
    };

    public static boolean isGradientAnimEnabled()   { return gradientAnimEnabled; }
    public static int getGradientAnimColorA()        { return gradientAnimColorA; }
    public static int getGradientAnimColorB()        { return gradientAnimColorB; }
    public static int getGradientAnimIntervalMs()    { return gradientAnimIntervalMs; }

    public static void setGradientAnimEnabled(boolean enabled) {
        gradientAnimEnabled = enabled;
        animHandler.removeCallbacks(animRunnable);
        if (enabled) { gradientAnimProgress = 0f; gradientAnimDir = true; animHandler.post(animRunnable); }
    }
    public static void setGradientAnimColorA(int c)    { gradientAnimColorA = c; }
    public static void setGradientAnimColorB(int c)    { gradientAnimColorB = c; }
    public static void setGradientAnimIntervalMs(int ms) { gradientAnimIntervalMs = Math.max(200, ms); }

    private static final List<OnThemeColorChangeListener> listeners = new ArrayList<>();

    public interface OnThemeColorChangeListener {
        void onThemeColorChanged(int newColor);
    }

    private static void saveThemeColor() {
        ConfigManager.saveModuleConfig(CONFIG_MODULE_NAME, CONFIG_KEY_THEME_COLOR, themeColor);
    }

    public static int getThemeColor() { return themeColor; }

    public static void setThemeColor(int color) {
        if (themeColor != color) {
            themeColor = color;
            // 联动更新发光色
            glowColor = (color & 0x00FFFFFF) | 0x66000000;
            saveThemeColor();
            notifyListeners();
        }
    }

    public static float[] getThemeColorHSV() {
        float[] hsv = new float[3];
        Color.colorToHSV(themeColor, hsv);
        return hsv;
    }

    public static int getBgPrimary()    { return bgPrimary; }
    public static void setBgPrimary(int c)    { bgPrimary = c;    notifyListeners(); }
    public static int getBgSecondary()  { return bgSecondary; }
    public static void setBgSecondary(int c)  { bgSecondary = c;  notifyListeners(); }
    public static int getBgDisabled()   { return bgDisabled; }
    public static void setBgDisabled(int c)   { bgDisabled = c;   notifyListeners(); }
    public static int getTextPrimary()  { return textPrimary; }
    public static void setTextPrimary(int c)  { textPrimary = c;  notifyListeners(); }
    public static int getTextSecondary(){ return textSecondary; }
    public static void setTextSecondary(int c){ textSecondary = c; notifyListeners(); }
    public static int getTextTertiary() { return textTertiary; }
    public static void setTextTertiary(int c) { textTertiary = c; notifyListeners(); }
    public static int getTextOnTheme()  { return textOnTheme; }
    public static void setTextOnTheme(int c)  { textOnTheme = c;  notifyListeners(); }
    public static int getStateDisabled(){ return stateDisabled; }
    public static void setStateDisabled(int c){ stateDisabled = c; notifyListeners(); }
    public static int getGlowColor()    { return glowColor; }
    public static void setGlowColor(int c)    { glowColor = c;    notifyListeners(); }
    public static int getGlassBackground()    { return glassBackground; }
    public static void setGlassBackground(int c){ glassBackground = c; notifyListeners(); }
    public static int getGradientStart(){ return gradientStart; }
    public static void setGradientStart(int c){ gradientStart = c; notifyListeners(); }
    public static int getGradientEnd()  { return gradientEnd; }
    public static void setGradientEnd(int c)  { gradientEnd = c;  notifyListeners(); }

    // 预设主题
    public static void applyDefaultTheme() { setThemeColor(0xFF5FCF50); } // 绿
    public static void applyGreenTheme()   { setThemeColor(0xFF5FCF50); } // 绿
    public static void applyBlueTheme()    { setThemeColor(0xFF307593); } // 蓝
    public static void applyPurpleTheme()  { setThemeColor(0xFFBB86FC); } // 紫
    public static void applyOrangeTheme()  { setThemeColor(0xFFFF9800); } // 橙
    public static void applyPinkTheme()    { setThemeColor(0xFFE91E63); } // 粉
    public static void applyRedTheme()     { setThemeColor(0xFF8F5050); } // 红

    public static void setThemeColorRGB(int r, int g, int b) {
        setThemeColor(Color.rgb(r, g, b));
    }

    public static void setThemeColorHSV(float hue, float saturation, float value) {
        setThemeColor(Color.HSVToColor(new float[]{hue, saturation, value}));
    }

    public static void addListener(OnThemeColorChangeListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public static void removeListener(OnThemeColorChangeListener listener) {
        listeners.remove(listener);
    }

    private static void notifyListeners() {
        for (OnThemeColorChangeListener listener : new ArrayList<>(listeners)) {
            try {
                listener.onThemeColorChanged(themeColor);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private ThemeManager() {}
}
