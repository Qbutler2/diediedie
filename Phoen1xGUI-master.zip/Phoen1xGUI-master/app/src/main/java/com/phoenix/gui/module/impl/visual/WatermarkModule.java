package com.phoenix.gui.module.impl.visual;

import android.view.Gravity;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.WatermarkView;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

public class WatermarkModule extends Module {

    private WatermarkView watermarkView;

    public WatermarkModule() {
        super("Watermark", ModuleCategory.VISUAL, "Show Wufan Client watermark on screen.");
    }

    @Override
    protected void onEnable() {
        // WatermarkView 由 FloatBallView 通过 ModuleToggleListener 控制
    }

    @Override
    protected void onDisable() {
    }

    @Override
    public boolean supportsShortcut() {
        return true; // 支持快捷键，和其他模块一样
    }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        // 先调用父类加快捷键开关
        super.configureSubMenu(subMenu);
        subMenu.addText("Displays 'Wufan Client' in the top-left corner with glow & shadow.");
    }
}
