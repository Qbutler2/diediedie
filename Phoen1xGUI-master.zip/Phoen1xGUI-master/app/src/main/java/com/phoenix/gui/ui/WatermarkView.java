package com.phoenix.gui.ui;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

import com.phoenix.gui.ui.ThemeManager;

/**
 * 左上角水印 — "Wufan Client"
 * 带字体发光 + 阴影
 */
public class WatermarkView extends View implements ThemeManager.OnThemeColorChangeListener {

    private final Paint glowPaint;
    private final Paint shadowPaint;
    private final Paint textPaint;
    private final String text = "Wufan Client";
    private final float textSizeSp;

    public WatermarkView(Context context) {
        super(context);
        setLayerType(LAYER_TYPE_SOFTWARE, null); // 软件层，支持 MaskFilter

        textSizeSp = spToPx(18f);

        // 阴影层（黑色偏移）
        shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        shadowPaint.setTypeface(Typeface.DEFAULT_BOLD);
        shadowPaint.setTextSize(textSizeSp);
        shadowPaint.setColor(0xAA000000);

        // 发光层（主题色模糊）
        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setTypeface(Typeface.DEFAULT_BOLD);
        glowPaint.setTextSize(textSizeSp);
        glowPaint.setColor(ThemeManager.getThemeColor());
        glowPaint.setMaskFilter(new BlurMaskFilter(dpToPx(8f), BlurMaskFilter.Blur.NORMAL));

        // 主文字层（渐变色）
        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(textSizeSp);
        textPaint.setColor(ThemeManager.getThemeColor());
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        updateGradient(w);
    }

    private void updateGradient(int w) {
        if (w <= 0) return;
        float textW = textPaint.measureText(text);
        LinearGradient grad = new LinearGradient(
                0, 0, textW, 0,
                new int[]{ThemeManager.getThemeColor(), ThemeManager.getGradientEnd()},
                null,
                Shader.TileMode.CLAMP
        );
        textPaint.setShader(grad);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float x = dpToPx(14f);
        float y = dpToPx(14f) + textSizeSp;

        // 1. 阴影（偏移 2dp）
        canvas.drawText(text, x + dpToPx(2f), y + dpToPx(2f), shadowPaint);

        // 2. 发光（原位）
        canvas.drawText(text, x, y, glowPaint);

        // 3. 主文字（原位）
        canvas.drawText(text, x, y, textPaint);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        float textW = textPaint.measureText(text);
        int w = (int) (textW + dpToPx(28f));
        int h = (int) (textSizeSp + dpToPx(28f));
        setMeasuredDimension(w, h);
    }

    @Override
    public void onThemeColorChanged(int newColor) {
        glowPaint.setColor(newColor);
        textPaint.setColor(newColor);
        updateGradient(getWidth());
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ThemeManager.addListener(this);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ThemeManager.removeListener(this);
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }

    private float spToPx(float sp) {
        return sp * getResources().getDisplayMetrics().scaledDensity;
    }
}
