package com.phoenix.gui;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.dynamic.DynamicIslandManager;
import com.phoenix.gui.ui.dynamic.DynamicIslandView;
import com.phoenix.gui.ui.dynamic.DynamicIslandWindow;

/**
 * OverlayService - 悬浮窗服务
 *
 * 使用 TYPE_APPLICATION_OVERLAY（Android 8+）在所有应用上方显示 GUI。
 * 需要 SYSTEM_ALERT_WINDOW 权限（AndroidManifest 已有）。
 *
 * 使用方法：
 *   // 启动悬浮窗
 *   Intent intent = new Intent(this, OverlayService.class);
 *   startForegroundService(intent);
 *
 *   // 停止悬浮窗
 *   stopService(new Intent(this, OverlayService.class));
 */
public class OverlayService extends Service {

    private static final String CHANNEL_ID   = "phoenix_overlay";
    private static final int    NOTIF_ID     = 1001;

    private WindowManager windowManager;
    private View overlayRoot;

    // 公开引用，供外部控制
    public static OverlayService instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());
        showOverlay();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        hideOverlay();
        instance = null;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ── 显示悬浮窗 ──

    private void showOverlay() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // 创建根布局
        overlayRoot = new FrameLayout(this);

        // DynamicIsland 容器（顶部居中）
        FrameLayout islandContainer = new FrameLayout(this);
        islandContainer.setId(R.id.dynamic_island_container);
        FrameLayout.LayoutParams islandLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        islandLp.topMargin = dpToPx(24);
        ((FrameLayout) overlayRoot).addView(islandContainer, islandLp);

        // 浮球容器（全屏覆盖）
        FrameLayout floatBallContainer = new FrameLayout(this);
        floatBallContainer.setId(R.id.float_ball_container);
        ((FrameLayout) overlayRoot).addView(floatBallContainer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        // 菜单容器
        FrameLayout menusContainer = new FrameLayout(this);
        menusContainer.setId(R.id.menus_container);
        menusContainer.setVisibility(View.GONE);
        ((FrameLayout) overlayRoot).addView(menusContainer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        // 水印容器
        FrameLayout watermarkContainer = new FrameLayout(this);
        watermarkContainer.setId(R.id.watermark_container);
        watermarkContainer.setVisibility(View.GONE);
        ((FrameLayout) overlayRoot).addView(watermarkContainer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.START));

        // Arraylist 容器
        FrameLayout arraylistContainer = new FrameLayout(this);
        arraylistContainer.setId(R.id.arraylist_container);
        ((FrameLayout) overlayRoot).addView(arraylistContainer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        // WindowManager.LayoutParams
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;

        windowManager.addView(overlayRoot, params);

        // 初始化 UI（传入 overlayRoot 作为伪 Activity）
        UI.initFromService(this, (FrameLayout) overlayRoot,
                islandContainer, floatBallContainer, menusContainer,
                watermarkContainer, arraylistContainer);
    }

    private void hideOverlay() {
        try {
            UI.hide();
            if (windowManager != null && overlayRoot != null) {
                windowManager.removeView(overlayRoot);
                overlayRoot = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── 前台通知 ──

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Phoenix GUI Overlay",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Floating GUI overlay");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, OverlayService.class);
        stopIntent.setAction("STOP");
        PendingIntent stopPi = PendingIntent.getService(this, 0, stopIntent,
                PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Phoenix GUI")
                .setContentText("Overlay is active")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .addAction(android.R.drawable.ic_delete, "Stop", stopPi)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private int dpToPx(float dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}
