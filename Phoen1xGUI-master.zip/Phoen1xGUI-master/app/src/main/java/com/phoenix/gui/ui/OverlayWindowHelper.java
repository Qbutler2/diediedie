package com.phoenix.gui.ui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/**
 * 工具类：把任意 View 作为独立悬浮窗添加到 WindowManager。
 * 每个 View 只占自身内容大小（WRAP_CONTENT），不影响其他区域的触摸。
 */
public class OverlayWindowHelper {

    public static WindowManager.LayoutParams makeWrapParams(int gravity) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        p.gravity = gravity;
        return p;
    }

    public static void addView(Context ctx, View view, int gravity) {
        WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;
        try {
            wm.addView(view, makeWrapParams(gravity));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void removeView(Context ctx, View view) {
        if (view == null || view.getParent() == null) return;
        WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;
        try {
            wm.removeView(view);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateLayout(Context ctx, View view, WindowManager.LayoutParams params) {
        if (view == null || view.getParent() == null) return;
        WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;
        try {
            wm.updateViewLayout(view, params);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
