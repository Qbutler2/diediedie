package com.phoenix.gui.ui;

import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;

/**
 * BlurHelper - 带图层感知的高斯模糊工具
 *
 * 规则：只有比自身 z 值低的 View 才会被模糊进来。
 * 即：自身图层越高，背景模糊范围越大（包含更多底层内容）。
 * 自身图层越低，背景模糊范围越窄（只包含比它更底层的内容）。
 *
 * 实现方式：
 *   截取 RootView 全图 → 遮盖掉所有 z 值 >= 自身 z 值的兄弟 View → 再做模糊
 */
public class BlurHelper {

    /**
     * 截取背景并做多级模糊，自动排除比 targetView 图层高或相同的兄弟节点。
     *
     * @param targetView 需要模糊背景的 View
     * @param passes     模糊强度（推荐 4）
     * @return 模糊后的 Bitmap，如果失败返回 null
     */
    public static Bitmap captureBlurredBackground(View targetView, int passes) {
        try {
            View root = targetView.getRootView();
            if (root == null || targetView.getWidth() <= 0 || targetView.getHeight() <= 0) return null;

            // 暂时隐藏比自身图层高或相等的兄弟 View
            float selfZ = targetView.getZ();
            ViewGroup parent = (ViewGroup) targetView.getParent();
            java.util.List<View> hiddenViews = new java.util.ArrayList<>();

            if (parent != null) {
                for (int i = 0; i < parent.getChildCount(); i++) {
                    View child = parent.getChildAt(i);
                    if (child != targetView && child.getZ() >= selfZ && child.getVisibility() == View.VISIBLE) {
                        child.setVisibility(View.INVISIBLE);
                        hiddenViews.add(child);
                    }
                }
            }

            // 截图
            root.setDrawingCacheEnabled(true);
            Bitmap cache = root.getDrawingCache(true);
            Bitmap result = null;

            if (cache != null && !cache.isRecycled()) {
                int[] loc = new int[2];
                targetView.getLocationOnScreen(loc);
                int x = loc[0], y = loc[1];
                int w = targetView.getWidth(), h = targetView.getHeight();

                if (x >= 0 && y >= 0 && x + w <= cache.getWidth() && y + h <= cache.getHeight()) {
                    Bitmap cropped = Bitmap.createBitmap(cache, x, y, w, h);
                    result = multiPassBlur(cropped, w, h, passes);
                }
            }

            // 还原被隐藏的 View
            for (View v : hiddenViews) {
                v.setVisibility(View.VISIBLE);
            }

            return result;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 多级缩放模糊
     */
    private static Bitmap multiPassBlur(Bitmap src, int targetW, int targetH, int passes) {
        Bitmap result = src;
        for (int i = 0; i < passes; i++) {
            int nw = Math.max(1, result.getWidth()  / 2);
            int nh = Math.max(1, result.getHeight() / 2);
            Bitmap small = Bitmap.createScaledBitmap(result, nw, nh, true);
            if (result != src) result.recycle();
            result = small;
        }
        Bitmap blurred = Bitmap.createScaledBitmap(result, targetW, targetH, true);
        if (result != src) result.recycle();
        return blurred;
    }
}
