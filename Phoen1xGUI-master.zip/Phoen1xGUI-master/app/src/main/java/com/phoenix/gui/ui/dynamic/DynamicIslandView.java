package com.phoenix.gui.ui.dynamic;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.interpolator.view.animation.FastOutSlowInInterpolator;

import com.phoenix.gui.ui.ThemeManager;

import java.util.ArrayList;
import java.util.List;

/**
 * DynamicIslandView - 仿照 MC 客户端 DynamicIslandManager 风格
 *
 * 核心特性（对应 MC 客户端逻辑）：
 *  - 宽度/高度平滑 lerp 动画（对应 AnimationUtil.smooth(width, targetWidth, 0.2f)）
 *  - 黑色半透明胶囊（对应 RoundedUtil.drawRoundedRect + Color(0,0,0,130)）
 *  - 绿色发光（对应 RenderUtil.addBloom）
 *  - 模块开关时显示切换动画（对应 EaseOutExpo + Direction.FORWARDS/BACKWARDS）
 *  - 内容优先级系统（对应 PriorityUtil）
 *  - 流光扫描（自加）
 */
public class DynamicIslandView extends FrameLayout
        implements DynamicIslandManager.StateChangeListener, ThemeManager.OnThemeColorChangeListener {

    // ── 尺寸常量 ──
    private static final float COLLAPSED_H_DP    = 36f;
    private static final float EXPANDED_R_DP     = 24f;
    private static final float ITEM_H_DP         = 52f;
    private static final float PAD_DP            = 12f;
    private static final float H_PAD_DP          = 24f;
    private static final float ICON_DP           = 40f;
    private static final float ICON_GAP_DP       = 12f;
    private static final float GLOW_DP           = 18f;
    private static final float SPREAD_DP         = 5f;
    private static final float SAFE_DP           = 8f;

    // ── 动画时长 ──
    private static final int   SIZE_ANIM_MS      = 500;  // 宽高变化
    private static final int   FADE_OUT_MS       = 100;
    private static final int   FADE_IN_MS        = 200;

    // ── lerp 速度（对应 MC 客户端 smooth 0.2f）──
    // 每帧靠近目标 20%
    private static final float LERP_SPEED        = 0.18f;

    private DynamicIslandManager manager;

    // ── 画笔 ──
    private Paint bgPaint;       // 黑色胶囊背景
    private Paint glowPaint;     // 绿色发光
    private Paint borderPaint;   // 细白边框
    private Paint sheenPaint;    // 流光

    private final RectF bgRect   = new RectF();
    private final RectF glowRect = new RectF();

    // ── 平滑尺寸（对应 MC 客户端 smooth(width/height, target, 0.2f)）──
    private float smoothWidth  = 0f;
    private float smoothHeight = 0f;
    private float smoothCorner = 0f;
    private float targetWidth  = 0f;
    private float targetHeight = 0f;
    private float targetCorner = 0f;

    // ── 弹簧动画（展开/收起用）──
    private ValueAnimator sizeAnimator;
    private boolean wasExpanded = false;

    // ── 流光 ──
    private float sheenX = -1f;
    private ValueAnimator sheenAnim;

    // ── 子View ──
    private CollapsedContentView collapsedContent;
    private FrameLayout expandedContainer;

    // ── FPS ──
    private int frameCount = 0;
    private long lastFpsNano = System.nanoTime();

    // ── Choreographer 驱动的 lerp 循环 ──
    private boolean lerpRunning = false;
    private final Choreographer.FrameCallback lerpCallback = new Choreographer.FrameCallback() {
        @Override
        public void doFrame(long frameTimeNanos) {
            // FPS 统计
            frameCount++;
            long elapsed = frameTimeNanos - lastFpsNano;
            if (elapsed >= 1_000_000_000L) {
                if (manager != null) manager.setCurrentFps(frameCount);
                if (collapsedContent != null) collapsedContent.updateFps(frameCount);
                frameCount = 0;
                lastFpsNano = frameTimeNanos;
            }

            // 平滑 lerp（对应 MC 客户端 AnimationUtil.smooth）
            boolean needsMore = false;
            if (Math.abs(smoothWidth - targetWidth) > 0.5f) {
                smoothWidth += (targetWidth - smoothWidth) * LERP_SPEED;
                needsMore = true;
            } else {
                smoothWidth = targetWidth;
            }
            if (Math.abs(smoothHeight - targetHeight) > 0.5f) {
                smoothHeight += (targetHeight - smoothHeight) * LERP_SPEED;
                needsMore = true;
            } else {
                smoothHeight = targetHeight;
            }
            if (Math.abs(smoothCorner - targetCorner) > 0.5f) {
                smoothCorner += (targetCorner - smoothCorner) * LERP_SPEED;
                needsMore = true;
            } else {
                smoothCorner = targetCorner;
            }

            if (needsMore || lerpRunning) {
                requestLayout();
                Choreographer.getInstance().postFrameCallback(this);
            } else {
                lerpRunning = false;
            }
        }
    };

    public DynamicIslandView(@NonNull Context context) {
        super(context);
        init(context);
    }

    public DynamicIslandView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        setWillNotDraw(false);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setClipChildren(false);
        setClipToPadding(false);

        initPaints();
        initSheen();
        initContentViews(context);
        startLerpLoop();
    }

    // ── 画笔初始化 ──

    private void initPaints() {
        // 黑色胶囊（对应 MC Color(0,0,0,130)）
        bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(0x82000000);
        bgPaint.setStyle(Paint.Style.FILL);

        // 绿色发光（对应 RenderUtil.addBloom）
        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setColor(ThemeManager.getGlowColor());
        glowPaint.setStyle(Paint.Style.FILL);
        glowPaint.setMaskFilter(new BlurMaskFilter(dpToPx(GLOW_DP), BlurMaskFilter.Blur.NORMAL));

        // 细边框
        borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dpToPx(0.7f));
        borderPaint.setColor(0x28FFFFFF);

        sheenPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    }

    // ── 流光动画 ──

    private void initSheen() {
        sheenAnim = ValueAnimator.ofFloat(-1f, 2f);
        sheenAnim.setDuration(3200);
        sheenAnim.setStartDelay(800);
        sheenAnim.setInterpolator(new android.view.animation.LinearInterpolator());
        sheenAnim.setRepeatCount(ValueAnimator.INFINITE);
        sheenAnim.setRepeatMode(ValueAnimator.RESTART);
        sheenAnim.addUpdateListener(a -> {
            sheenX = (float) a.getAnimatedValue();
            invalidate();
        });
        sheenAnim.start();
    }

    // ── 子 View ──

    private void initContentViews(Context context) {
        collapsedContent = new CollapsedContentView(context);
        collapsedContent.setVisibility(VISIBLE);
        LayoutParams cp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT);
        cp.gravity = Gravity.CENTER;
        addView(collapsedContent, cp);

        expandedContainer = new FrameLayout(context);
        expandedContainer.setVisibility(GONE);
        expandedContainer.setAlpha(0f);
        expandedContainer.setBackgroundColor(Color.TRANSPARENT);
        LayoutParams ep = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        ep.gravity = Gravity.CENTER;
        addView(expandedContainer, ep);
    }

    // ── Lerp 循环 ──

    private void startLerpLoop() {
        lerpRunning = true;
        Choreographer.getInstance().postFrameCallback(lerpCallback);
    }

    // ── 绘制（对应 MC RoundedUtil.drawRoundedRect + addBloom）──

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        float s = manager != null ? manager.getScale() : 0.7f;
        int pad = totalPadding(s);

        if (smoothWidth == 0 || smoothHeight == 0) {
            boolean expanded = manager != null && manager.isExpanded();
            smoothHeight = expanded ? calcExpandedH(s) : dpToPx(COLLAPSED_H_DP) * s;
            smoothWidth  = expanded ? calcExpandedW(s) : calcCollapsedW(s);
            smoothCorner = expanded ? dpToPx(EXPANDED_R_DP) * s : smoothHeight / 2f;
            targetWidth  = smoothWidth;
            targetHeight = smoothHeight;
            targetCorner = smoothCorner;
        }

        int cW = (int) smoothWidth;
        int cH = (int) smoothHeight;
        measureChild(collapsedContent,
                MeasureSpec.makeMeasureSpec(cW, MeasureSpec.AT_MOST),
                MeasureSpec.makeMeasureSpec(cH, MeasureSpec.EXACTLY));
        measureChild(expandedContainer,
                MeasureSpec.makeMeasureSpec(cW, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(cH, MeasureSpec.EXACTLY));

        setMeasuredDimension(cW + pad * 2, cH + pad * 2);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        float s = manager != null ? manager.getScale() : 0.7f;
        int pad  = totalPadding(s);
        int cL   = pad, cT = pad, cR = getWidth() - pad, cB = getHeight() - pad;
        int cW   = cR - cL;
        int colW = collapsedContent.getMeasuredWidth();
        int colL = cL + (cW - colW) / 2;
        collapsedContent.layout(colL, cT, colL + colW, cB);
        expandedContainer.layout(cL, cT, cR, cB);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float s   = manager != null ? manager.getScale() : 0.7f;
        int   pad = totalPadding(s);
        float cL  = pad, cT = pad, cR = getWidth() - pad, cB = getHeight() - pad;

        bgRect.set(cL, cT, cR, cB);
        float sp = dpToPx(SPREAD_DP) * s;
        glowRect.set(cL - sp, cT - sp, cR + sp, cB + sp);

        float r = smoothCorner;

        // 1. 发光（对应 addBloom）
        canvas.drawRoundRect(glowRect, r, r, glowPaint);

        // 2. 黑色胶囊（对应 Color(0,0,0,130)）
        canvas.drawRoundRect(bgRect, r, r, bgPaint);

        // 3. 细边框
        canvas.drawRoundRect(bgRect, r, r, borderPaint);

        // 4. 流光
        drawSheen(canvas, bgRect, r);

        // 5. 顶部渐变高光线
        drawTopLine(canvas, bgRect, r);
    }

    private void drawSheen(Canvas canvas, RectF rect, float r) {
        float gw   = rect.width() * 0.4f;
        float gStart = rect.width() * sheenX + rect.left;
        LinearGradient lg = new LinearGradient(
                gStart - gw, rect.top, gStart, rect.bottom,
                new int[]{0x00FFFFFF, 0x16FFFFFF, 0x00FFFFFF},
                new float[]{0f, .5f, 1f}, Shader.TileMode.CLAMP);
        sheenPaint.setShader(lg);
        canvas.save();
        Path p = new Path();
        p.addRoundRect(rect, r, r, Path.Direction.CW);
        canvas.clipPath(p);
        canvas.drawRoundRect(rect, r, r, sheenPaint);
        canvas.restore();
    }

    private void drawTopLine(Canvas canvas, RectF rect, float r) {
        int gs = ThemeManager.getGradientStart();
        int ge = ThemeManager.getGradientEnd();
        LinearGradient lg = new LinearGradient(
                rect.left + r, rect.top, rect.right - r, rect.top,
                new int[]{0x00FFFFFF, gs, ge, 0x00FFFFFF},
                new float[]{0f, .3f, .7f, 1f}, Shader.TileMode.CLAMP);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(lg);
        p.setAlpha(160);
        canvas.drawRect(rect.left + r, rect.top, rect.right - r, rect.top + dpToPx(1f), p);
    }

    // ── 状态回调 ──

    @Override
    public void onTasksChanged() {
        updateContent();
        updateTargetSize();
    }

    @Override
    public void onExpandedStateChanged(boolean expanded) {
        if (wasExpanded != expanded) {
            wasExpanded = expanded;
            updateContent();
            animateToState(expanded);
        }
    }

    @Override
    public void onConfigChanged(float scale, String text) {
        if (collapsedContent != null) collapsedContent.updateConfig(scale, text);
        updateTargetSize();
    }

    @Override
    public void onThemeColorChanged(int color) {
        glowPaint.setColor(ThemeManager.getGlowColor());
        invalidate();
    }

    // ── 内容更新 ──

    private void updateContent() {
        if (manager == null) return;
        if (manager.isExpanded()) {
            LinearLayout tc = null;
            if (expandedContainer.getChildCount() > 0
                    && expandedContainer.getChildAt(0) instanceof LinearLayout)
                tc = (LinearLayout) expandedContainer.getChildAt(0);
            if (tc == null || !tasksMatch(tc)) rebuildExpanded();
            else updateExisting(tc);
        }
        if (collapsedContent != null) collapsedContent.updateContent();
    }

    private boolean tasksMatch(LinearLayout tc) {
        List<DynamicIslandManager.TaskItem> tasks = manager.getVisibleTasks();
        if (tc.getChildCount() != tasks.size()) return false;
        for (int i = 0; i < tasks.size(); i++) {
            View child = tc.getChildAt(i);
            if (!(child instanceof TaskItemView)) return false;
            TaskItemView tv = (TaskItemView) child;
            DynamicIslandManager.TaskItem task = tasks.get(i);
            if (!tv.task.identifier.equals(task.identifier) || tv.task.type != task.type) return false;
        }
        return true;
    }

    private void updateExisting(LinearLayout tc) {
        List<DynamicIslandManager.TaskItem> tasks = manager.getVisibleTasks();
        for (int i = 0; i < tasks.size(); i++) {
            if (i >= tc.getChildCount()) break;
            View c = tc.getChildAt(i);
            if (c instanceof TaskItemView) {
                ((TaskItemView) c).task = tasks.get(i);
                ((TaskItemView) c).updateContent();
            }
        }
    }

    private void rebuildExpanded() {
        expandedContainer.removeAllViews();
        LinearLayout tc = new LinearLayout(getContext());
        tc.setOrientation(LinearLayout.VERTICAL);
        float s = manager.getScale();
        tc.setPadding(0, (int)(dpToPx(PAD_DP)*s), 0, (int)(dpToPx(PAD_DP)*s));
        for (DynamicIslandManager.TaskItem task : manager.getVisibleTasks()) {
            tc.addView(makeTaskView(task));
        }
        expandedContainer.addView(tc, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
    }

    private TaskItemView makeTaskView(DynamicIslandManager.TaskItem task) {
        float s = manager.getScale();
        switch (task.type) {
            case SWITCH:   return new SwitchItemView(getContext(), task, s);
            case PROGRESS: return new ProgressItemView(getContext(), task, s);
            default: throw new IllegalArgumentException("Unknown type: " + task.type);
        }
    }

    // ── 尺寸动画（平滑 lerp 驱动）──

    private void updateTargetSize() {
        if (manager == null) return;
        float s = manager.getScale();
        boolean exp = manager.isExpanded();
        targetHeight = exp ? calcExpandedH(s) : dpToPx(COLLAPSED_H_DP) * s;
        targetWidth  = exp ? calcExpandedW(s)  : calcCollapsedW(s);
        targetCorner = exp ? dpToPx(EXPANDED_R_DP) * s : targetHeight / 2f;
        startLerpLoop(); // 重新激活 lerp
    }

    private void animateToState(boolean expanded) {
        float s = manager != null ? manager.getScale() : 0.7f;
        targetHeight = expanded ? calcExpandedH(s) : dpToPx(COLLAPSED_H_DP) * s;
        targetWidth  = expanded ? calcExpandedW(s)  : calcCollapsedW(s);
        targetCorner = expanded ? dpToPx(EXPANDED_R_DP) * s : targetHeight / 2f;
        startLerpLoop();

        if (expanded) {
            collapsedContent.animate().alpha(0f).scaleX(.9f).scaleY(.9f)
                    .setDuration(FADE_OUT_MS).setInterpolator(new FastOutSlowInInterpolator())
                    .withEndAction(() -> collapsedContent.setVisibility(GONE)).start();
            expandedContainer.setVisibility(VISIBLE);
            expandedContainer.setAlpha(0f); expandedContainer.setScaleX(.9f); expandedContainer.setScaleY(.9f);
            expandedContainer.animate().alpha(1f).scaleX(1f).scaleY(1f)
                    .setDuration(FADE_IN_MS).setInterpolator(new FastOutSlowInInterpolator()).start();
        } else {
            expandedContainer.animate().alpha(0f).scaleX(.9f).scaleY(.9f)
                    .setDuration(FADE_OUT_MS).setInterpolator(new FastOutSlowInInterpolator())
                    .withEndAction(() -> expandedContainer.setVisibility(GONE)).start();
            collapsedContent.setVisibility(VISIBLE);
            collapsedContent.setAlpha(0f); collapsedContent.setScaleX(.9f); collapsedContent.setScaleY(.9f);
            collapsedContent.animate().alpha(1f).scaleX(1f).scaleY(1f)
                    .setDuration(FADE_IN_MS).setInterpolator(new FastOutSlowInInterpolator()).start();
        }
    }

    // ── 尺寸计算 ──

    private int calcExpandedH(float s) {
        if (manager == null) return (int)(dpToPx(COLLAPSED_H_DP)*s);
        int total = 0;
        for (DynamicIslandManager.TaskItem t : manager.getVisibleTasks()) {
            total += (int)(dpToPx(t.type == DynamicIslandManager.TaskItem.Type.PROGRESS
                    ? ITEM_H_DP + 20 : ITEM_H_DP) * s);
        }
        return total + (int)(dpToPx(PAD_DP*2)*s);
    }

    private int calcExpandedW(float s) {
        int min = (int)(dpToPx(280)*s);
        int max = min;
        if (manager != null)
            for (DynamicIslandManager.TaskItem t : manager.getVisibleTasks())
                max = Math.max(max, calcTaskW(t, s));
        return Math.min(max, (int)(dpToPx(450)*s));
    }

    private int calcCollapsedW(float s) {
        if (collapsedContent == null) return (int)(dpToPx(280)*s);
        collapsedContent.measure(
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),
                MeasureSpec.makeMeasureSpec((int)(dpToPx(COLLAPSED_H_DP)*s), MeasureSpec.EXACTLY));
        return collapsedContent.getMeasuredWidth() + (int)(dpToPx(40)*s);
    }

    private int calcTaskW(DynamicIslandManager.TaskItem t, float s) {
        float side  = dpToPx(H_PAD_DP*2)*s;
        float iconW = dpToPx(t.type == DynamicIslandManager.TaskItem.Type.SWITCH ? 52 : ICON_DP)*s;
        float gap   = dpToPx(ICON_GAP_DP)*s;
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTextSize(spToPx(15*s));
        tp.setTypeface(Typeface.DEFAULT_BOLD);
        float tw = tp.measureText(t.text);
        float sw = 0;
        if (t.subtitle != null) {
            tp.setTextSize(spToPx(12*s));
            tp.setTypeface(Typeface.DEFAULT);
            sw = tp.measureText(t.subtitle.replace("|", " "));
        }
        return (int)(side + iconW + gap + Math.max(tw, sw) + dpToPx(32)*s);
    }

    private int totalPadding(float s) {
        return (int)((dpToPx(GLOW_DP + SPREAD_DP) + dpToPx(SAFE_DP)) * s);
    }

    // ── Manager 绑定 ──

    public void setManager(DynamicIslandManager manager) {
        if (this.manager != null) this.manager.removeListener(this);
        this.manager = manager;
        this.manager.addListener(this);
        if (collapsedContent != null) collapsedContent.setManager(manager);
        updateContent();
        updateTargetSize();
    }

    // ── 生命周期 ──

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ThemeManager.addListener(this);
        startLerpLoop();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        lerpRunning = false;
        if (sheenAnim != null) sheenAnim.cancel();
        if (sizeAnimator != null) sizeAnimator.cancel();
        ThemeManager.removeListener(this);
    }

    // ── 工具 ──

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }

    private int spToPx(float sp) {
        return (int)(sp * getResources().getDisplayMetrics().scaledDensity);
    }
}
