package com.phoenix.gui.module.impl.visual;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.widgets.ColorPickerView;
import com.phoenix.gui.ui.widgets.GradientAnimPickerView;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

public class ThemeModule extends Module {

    public ThemeModule() {
        super("Theme", ModuleCategory.VISUAL, "Customize the UI colors and themes.");
    }

    @Override
    protected void onEnable() {}

    @Override
    protected void onDisable() {}

    @Override
    public boolean supportsShortcut() {
        return false;
    }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        subMenu.addText("Select a preset theme or create your own color below.");
        subMenu.addThemeButtons();

        ColorPickerView colorPicker = new ColorPickerView(subMenu.getContext());
        subMenu.addCustomView(colorPicker);

        subMenu.addText("Gradient Animation");
        GradientAnimPickerView gradientPicker = new GradientAnimPickerView(subMenu.getContext());
        subMenu.addCustomView(gradientPicker);
    }
}
