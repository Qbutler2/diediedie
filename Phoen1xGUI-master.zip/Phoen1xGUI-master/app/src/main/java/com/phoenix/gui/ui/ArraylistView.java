package com.phoenix.gui.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;

import java.util.*;

/**
 * Solstice 风格 Arraylist：
 * - 右侧对齐，按文字宽度降序排列
 * - 每项颜色基于 Y 位置偏移色相
 * - 无背景框，只有文字+右侧竖条+阴影
 * - 滑入/滑出动画
 */
public class ArraylistView extends LinearLayout {

    private List<ArraylistModule> modules = new ArrayList<>();
    private Map<String, ArraylistItemView> itemViews = new HashMap<>();
    // 动画进度 0~1，key=moduleName
    private Map<String, Float> animProgress = new HashMap<>();

    public ArraylistView(Context context) { super(context); init(); }
    public ArraylistView(Context context, AttributeSet a) { super(context, a); init(); }
    public ArraylistView(Context context, AttributeSet a, int d) { super(context, a, d); init(); }

    private void init() {
        setOrientation(VERTICAL);
        setGravity(Gravity.END | Gravity.TOP);
        setClipChildren(false);
        setClipToPadding(false);
        setPadding(0, dpToPx(16), 0, 0);
    }

    // ── 公开 API ──

    public void addModule(String name) { addModule(new ArraylistModule(name)); }
    public void addModule(String name, int color) { addModule(new ArraylistModule(name, color)); }

    public void addModule(ArraylistModule module) {
        if (itemViews.containsKey(module.getName())) return;

        modules.add(module);

        ArraylistItemView item = new ArraylistItemView(getContext());
        item.setText(module.getName());
        if (!module.isUseThemeColor()) item.setTextColor(module.getColor());
        item.setGlowEnabled(module.isGlowEnabled());
        itemViews.put(module.getName(), item);
        animProgress.put(module.getName(), 0f);

        sortModules();
        rebuildViews();
        animateItemIn(module.getName());
    }

    public void removeModule(String name) {
        ArraylistModule toRemove = null;
        for (ArraylistModule m : modules) if (m.getName().equals(name)) { toRemove = m; break; }
        if (toRemove == null) return;
        final ArraylistModule finalRemove = toRemove;
        animateItemOut(name, () -> {
            modules.remove(finalRemove);
            ArraylistItemView v = itemViews.remove(name);
            if (v != null) { removeView(v); v.cleanup(); }
            animProgress.remove(name);
            sortModules();
            rebuildViews();
        });
    }

    public void clearModules() {
        for (ArraylistItemView v : itemViews.values()) v.cleanup();
        modules.clear();
        itemViews.clear();
        animProgress.clear();
        removeAllViews();
    }

    public void show() { setVisibility(VISIBLE); }
    public void hide() { setVisibility(GONE); }
    public List<ArraylistModule> getModules() { return modules; }

    // ── 内部 ──

    private void sortModules() {
        Collections.sort(modules, (a, b) -> {
            ArraylistItemView va = itemViews.get(a.getName());
            ArraylistItemView vb = itemViews.get(b.getName());
            float wa = va != null ? va.getMeasuredTextWidth() : 0;
            float wb = vb != null ? vb.getMeasuredTextWidth() : 0;
            int cmp = Float.compare(wb, wa);
            return cmp != 0 ? cmp : a.getName().compareTo(b.getName());
        });
    }

    private void rebuildViews() {
        // 先全部移除
        for (int i = getChildCount() - 1; i >= 0; i--) removeViewAt(i);

        int count = modules.size();
        // 计算累计高度，用于色相偏移
        int cumulativeY = 0;

        for (int i = 0; i < count; i++) {
            ArraylistModule mod = modules.get(i);
            ArraylistItemView item = itemViews.get(mod.getName());
            if (item == null) continue;

            // 位置类型
            if (count == 1)      item.setPositionType(ArraylistItemView.PositionType.SINGLE);
            else if (i == 0)     item.setPositionType(ArraylistItemView.PositionType.FIRST);
            else if (i == count - 1) item.setPositionType(ArraylistItemView.PositionType.LAST);
            else                 item.setPositionType(ArraylistItemView.PositionType.MIDDLE);

            // 色相偏移（Solstice: y*2 对应色相偏移）
            float hueShift = (cumulativeY * 2f) % 360f;
            item.setColorHueOffset(hueShift);

            // 动画：translationX 由 animProgress 控制
            Float progress = animProgress.getOrDefault(mod.getName(), 1f);
            if (progress == null) progress = 1f;
            item.setAlpha(progress);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.END;
            lp.topMargin = 0;
            addView(item, lp);

            cumulativeY += dpToPx(22); // 约每行高度
        }
    }

    private void animateItemIn(String name) {
        ArraylistItemView item = itemViews.get(name);
        if (item == null) return;

        item.setTranslationX(dpToPx(100));
        item.setAlpha(0f);

        ValueAnimator anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(300);
        anim.setInterpolator(new DecelerateInterpolator(2f));
        anim.addUpdateListener(a -> {
            float f = (float) a.getAnimatedValue();
            animProgress.put(name, f);
            item.setAlpha(f);
            item.setTranslationX(dpToPx(100) * (1f - f));
        });
        anim.start();
    }

    private void animateItemOut(String name, Runnable onDone) {
        ArraylistItemView item = itemViews.get(name);
        if (item == null) { if (onDone != null) onDone.run(); return; }

        ValueAnimator anim = ValueAnimator.ofFloat(1f, 0f);
        anim.setDuration(250);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            float f = (float) a.getAnimatedValue();
            animProgress.put(name, f);
            item.setAlpha(f);
            item.setTranslationX(dpToPx(60) * (1f - f));
        });
        anim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                if (onDone != null) onDone.run();
            }
        });
        anim.start();
    }

    private int dpToPx(float dp) {
        return (int)(dp * getContext().getResources().getDisplayMetrics().density);
    }
}
