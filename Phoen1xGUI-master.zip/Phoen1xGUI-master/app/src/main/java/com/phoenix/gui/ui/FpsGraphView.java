package com.phoenix.gui.ui;

import android.content.Context;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * FPS 心电图可视化 View（可拖动浮动卡片）
 * Y 轴自适应，每 30 FPS 一个网格节点
 */
public class FpsGraphView extends View {

    private static final int MAX_POINTS   = 120;
    private static final int GRID_STEP    = 30;  // 每 30 FPS 一个节点

    private final Deque<Float> fpsHistory = new ArrayDeque<>();
    private final Paint linePaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gridPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path  linePath   = new Path();

    // FPS 计算
    private long    lastSampleTime = 0;
    private int     frameCount     = 0;
    private float   currentFps     = 0f;
    private float   peakFps        = 60f; // 动态最大值，最低 60
    private boolean running        = false;

    // 挂钩真实 vsync
    private final Runnable frameCallback = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            frameCount++;
            long now = System.nanoTime();
            if (lastSampleTime == 0) lastSampleTime = now;
            long elapsed = now - lastSampleTime;
            if (elapsed >= 500_000_000L) {
                currentFps = frameCount * 1_000_000_000f / elapsed;
                frameCount     = 0;
                lastSampleTime = now;
                // 更新动态峰值：取历史最大值，向上对齐到 GRID_STEP 倍数，最低 60
                if (fpsHistory.size() >= MAX_POINTS) fpsHistory.pollFirst();
                fpsHistory.addLast(currentFps);
                updatePeakFps();
                invalidate();
            }
            postOnAnimation(this);
        }
    };

    // 拖动
    private float dragStartX, dragStartY, viewStartX, viewStartY;

    public FpsGraphView(Context context) {
        super(context);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setWillNotDraw(false);

        bgPaint.setColor(0xCC0A0E10);
        bgPaint.setStyle(Paint.Style.FILL);

        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(dpToPx(1.8f));
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        linePaint.setStrokeJoin(Paint.Join.ROUND);

        glowPaint.setStyle(Paint.Style.STROKE);
        glowPaint.setStrokeWidth(dpToPx(4f));
        glowPaint.setStrokeCap(Paint.Cap.ROUND);
        glowPaint.setMaskFilter(new BlurMaskFilter(dpToPx(6f), BlurMaskFilter.Blur.NORMAL));

        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(dpToPx(0.5f));
        gridPaint.setColor(0x22FFFFFF);

        labelPaint.setTextSize(dpToPx(9f));
        labelPaint.setColor(0x88FFFFFF);
        labelPaint.setAntiAlias(true);
        labelPaint.setTypeface(Typeface.MONOSPACE);

        // 拖动支持
        setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragStartX = event.getRawX();
                    dragStartY = event.getRawY();
                    viewStartX = getX();
                    viewStartY = getY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    setX(viewStartX + event.getRawX() - dragStartX);
                    setY(viewStartY + event.getRawY() - dragStartY);
                    return true;
            }
            return false;
        });
    }

    private void updatePeakFps() {
        float max = 60f;
        for (Float f : fpsHistory) if (f > max) max = f;
        // 向上对齐到 GRID_STEP 倍数
        int steps = (int) Math.ceil(max / GRID_STEP);
        peakFps = steps * GRID_STEP;
    }

    public void startMonitoring() {
        if (running) return;
        running = true;
        frameCount     = 0;
        lastSampleTime = 0;
        fpsHistory.clear();
        peakFps = 60f;
        setVisibility(VISIBLE);
        postOnAnimation(frameCallback);
    }

    public void stopMonitoring() {
        running = false;
        removeCallbacks(frameCallback);
        setVisibility(GONE);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        float pad    = dpToPx(4f);
        float graphW = w - pad * 2;
        float graphH = h - pad * 2 - dpToPx(14f); // 留底部给 FPS 标签
        float baseY  = pad + graphH;               // 0 FPS 对应的 Y

        // 背景
        canvas.drawRoundRect(new RectF(0, 0, w, h), dpToPx(6f), dpToPx(6f), bgPaint);

        // Y 轴网格：每 GRID_STEP FPS 一条线
        labelPaint.setColor(0x88FFFFFF);
        labelPaint.setTextSize(dpToPx(9f));
        labelPaint.setTypeface(Typeface.MONOSPACE);
        int gridLevel = GRID_STEP;
        while (gridLevel <= peakFps) {
            float y = baseY - (gridLevel / peakFps) * graphH;
            canvas.drawLine(pad, y, w - pad, y, gridPaint);
            canvas.drawText(String.valueOf(gridLevel), pad + dpToPx(2f), y - dpToPx(1f), labelPaint);
            gridLevel += GRID_STEP;
        }

        // 当前 FPS 标签（右下角）
        String fpsLabel = String.format("%.0f FPS", currentFps);
        labelPaint.setColor(getFpsColor(currentFps));
        labelPaint.setTextSize(dpToPx(10f));
        labelPaint.setTypeface(Typeface.DEFAULT_BOLD);
        canvas.drawText(fpsLabel, w - labelPaint.measureText(fpsLabel) - pad, h - dpToPx(2f), labelPaint);

        if (fpsHistory.size() < 2) return;

        Float[] samples = fpsHistory.toArray(new Float[0]);
        int   count    = samples.length;
        float stepX    = graphW / (MAX_POINTS - 1f);
        int   startIdx = Math.max(0, MAX_POINTS - count);

        // 构建路径
        linePath.reset();
        boolean first = true;
        for (int i = 0; i < count; i++) {
            float fps = Math.min(samples[i], peakFps);
            float x   = pad + (startIdx + i) * stepX;
            float y   = baseY - (fps / peakFps) * graphH;
            if (first) { linePath.moveTo(x, y); first = false; }
            else        { linePath.lineTo(x, y); }
        }

        int lineColor = getFpsColor(currentFps);

        // 发光层
        glowPaint.setColor(lineColor & 0x00FFFFFF | 0x55000000);
        canvas.drawPath(linePath, glowPaint);

        // 主线逐段渐变透明度
        for (int i = 0; i < count - 1; i++) {
            float f1  = Math.min(samples[i],     peakFps);
            float f2  = Math.min(samples[i + 1], peakFps);
            int   idx = startIdx + i;
            float x1  = pad + idx * stepX;
            float y1  = baseY - (f1 / peakFps) * graphH;
            float x2  = pad + (idx + 1) * stepX;
            float y2  = baseY - (f2 / peakFps) * graphH;
            float alpha = 0.3f + 0.7f * ((float) i / count);
            linePaint.setColor(applyAlpha(getFpsColor(f2), alpha));
            canvas.drawLine(x1, y1, x2, y2, linePaint);
        }

        // 心跳点（最新）
        float lastFps = Math.min(samples[count - 1], peakFps);
        float lx = pad + (startIdx + count - 1) * stepX;
        float ly = baseY - (lastFps / peakFps) * graphH;
        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        dot.setColor(lineColor);
        dot.setMaskFilter(new BlurMaskFilter(dpToPx(4f), BlurMaskFilter.Blur.NORMAL));
        canvas.drawCircle(lx, ly, dpToPx(3f), dot);
        dot.setMaskFilter(null);
        dot.setColor(0xFFFFFFFF);
        canvas.drawCircle(lx, ly, dpToPx(1.5f), dot);
    }

    private int getFpsColor(float fps) {
        if (fps >= 55) return ThemeManager.getGradientStart();
        if (fps >= 30) return 0xFFE0DD31;
        return 0xFFFF3246;
    }

    private int applyAlpha(int color, float alpha) {
        int a = (int)(Color.alpha(color) * alpha);
        return (color & 0x00FFFFFF) | (a << 24);
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }
}
