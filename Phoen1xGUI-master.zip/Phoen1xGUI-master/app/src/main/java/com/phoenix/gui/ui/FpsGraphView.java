package com.phoenix.gui.ui;

import android.content.Context;
import android.graphics.*;
import android.os.Choreographer;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import com.phoenix.gui.ui.ThemeManager;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * FPS 心电图可视化 View
 * 实时绘制 FPS 折线，像心电图一样从右向左滚动
 */
public class FpsGraphView extends View {

    private static final int MAX_POINTS  = 120;  // 保留最近 120 帧数据
    private static final int TARGET_FPS  = 60;
    private static final int WARN_FPS    = 30;

    private final Deque<Float> fpsHistory = new ArrayDeque<>();
    private final Paint linePaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gridPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path  linePath    = new Path();

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // FPS 计算
    private int   frameCount  = 0;
    private long  lastTime    = System.nanoTime();
    private float currentFps  = 0f;

    // Choreographer 回调
    private Choreographer.FrameCallback frameCallback;
    private boolean running = false;

    public FpsGraphView(Context context) {
        super(context);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setWillNotDraw(false);

        bgPaint.setColor(0xCC0A0E10);
        bgPaint.setStyle(Paint.Style.FILL);

        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(dpToPx(1.8f));
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        linePaint.setStrokeJoin(Paint.Join.ROUND);

        glowPaint.setStyle(Paint.Style.STROKE);
        glowPaint.setStrokeWidth(dpToPx(4f));
        glowPaint.setStrokeCap(Paint.Cap.ROUND);
        glowPaint.setMaskFilter(new BlurMaskFilter(dpToPx(6f), BlurMaskFilter.Blur.NORMAL));

        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(dpToPx(0.5f));
        gridPaint.setColor(0x22FFFFFF);

        labelPaint.setTextSize(dpToPx(9f));
        labelPaint.setColor(0x88FFFFFF);
        labelPaint.setAntiAlias(true);
        labelPaint.setTypeface(Typeface.MONOSPACE);
    }

    public void startMonitoring() {
        if (running) return;
        running = true;
        frameCallback = new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                if (!running) return;
                frameCount++;
                long elapsed = frameTimeNanos - lastTime;
                if (elapsed >= 500_000_000L) { // 每 0.5 秒更新一次
                    currentFps = frameCount * 1_000_000_000f / elapsed;
                    frameCount = 0;
                    lastTime   = frameTimeNanos;
                    addFpsSample(currentFps);
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        };
        Choreographer.getInstance().postFrameCallback(frameCallback);
    }

    public void stopMonitoring() {
        running = false;
        if (frameCallback != null) {
            Choreographer.getInstance().removeFrameCallback(frameCallback);
        }
    }

    private void addFpsSample(float fps) {
        mainHandler.post(() -> {
            if (fpsHistory.size() >= MAX_POINTS) fpsHistory.pollFirst();
            fpsHistory.addLast(fps);
            invalidate();
        });
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        float pad    = dpToPx(4f);
        float graphW = w - pad * 2;
        float graphH = h - pad * 2 - dpToPx(14f); // 留底部给标签
        float baseY  = pad + graphH;

        // 背景
        RectF bgRect = new RectF(0, 0, w, h);
        canvas.drawRoundRect(bgRect, dpToPx(6f), dpToPx(6f), bgPaint);

        // 网格线（60fps 和 30fps 参考线）
        float y60 = baseY - (60f / TARGET_FPS) * graphH * 0.85f;
        float y30 = baseY - (30f / TARGET_FPS) * graphH * 0.85f;
        canvas.drawLine(pad, y60, w - pad, y60, gridPaint);
        canvas.drawLine(pad, y30, w - pad, y30, gridPaint);
        canvas.drawText("60", pad + dpToPx(2f), y60 - dpToPx(1f), labelPaint);
        canvas.drawText("30", pad + dpToPx(2f), y30 - dpToPx(1f), labelPaint);

        // 当前 FPS 标签
        String fpsLabel = String.format("%.0f FPS", currentFps);
        labelPaint.setColor(getFpsColor(currentFps));
        labelPaint.setTextSize(dpToPx(10f));
        labelPaint.setTypeface(Typeface.DEFAULT_BOLD);
        canvas.drawText(fpsLabel, w - labelPaint.measureText(fpsLabel) - pad, h - dpToPx(2f), labelPaint);
        labelPaint.setColor(0x88FFFFFF);
        labelPaint.setTextSize(dpToPx(9f));
        labelPaint.setTypeface(Typeface.MONOSPACE);

        if (fpsHistory.size() < 2) return;

        Float[] samples = fpsHistory.toArray(new Float[0]);
        int count = samples.length;
        float stepX = graphW / (MAX_POINTS - 1f);
        float maxFps = 70f;

        // 构建路径
        linePath.reset();
        boolean first = true;
        int startIdx = Math.max(0, MAX_POINTS - count);

        for (int i = 0; i < count; i++) {
            float fps = Math.min(samples[i], maxFps);
            float x = pad + (startIdx + i) * stepX;
            float y = baseY - (fps / maxFps) * graphH * 0.85f;
            if (first) { linePath.moveTo(x, y); first = false; }
            else        { linePath.lineTo(x, y); }
        }

        // 心电图末端颜色基于当前 FPS
        int lineColor = getFpsColor(currentFps);

        // 发光层
        glowPaint.setColor(lineColor & 0x00FFFFFF | 0x55000000);
        canvas.drawPath(linePath, glowPaint);

        // 主线（渐变：左侧老数据偏暗，右侧新数据亮）
        if (count > 1) {
            Float[] arr = samples;
            for (int i = 0; i < count - 1; i++) {
                float f1 = Math.min(arr[i],     maxFps);
                float f2 = Math.min(arr[i + 1], maxFps);
                int   idx = startIdx + i;
                float x1 = pad + idx * stepX;
                float y1 = baseY - (f1 / maxFps) * graphH * 0.85f;
                float x2 = pad + (idx + 1) * stepX;
                float y2 = baseY - (f2 / maxFps) * graphH * 0.85f;
                float alpha = 0.3f + 0.7f * ((float) i / count);
                int segColor = applyAlpha(getFpsColor(f2), alpha);
                linePaint.setColor(segColor);
                canvas.drawLine(x1, y1, x2, y2, linePaint);
            }
        }

        // 心跳点（最新一点）
        if (count > 0) {
            float lastFps = Math.min(samples[count - 1], maxFps);
            float lx = pad + (startIdx + count - 1) * stepX;
            float ly = baseY - (lastFps / maxFps) * graphH * 0.85f;
            Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
            dot.setColor(lineColor);
            dot.setMaskFilter(new BlurMaskFilter(dpToPx(4f), BlurMaskFilter.Blur.NORMAL));
            canvas.drawCircle(lx, ly, dpToPx(3f), dot);
            dot.setMaskFilter(null);
            dot.setColor(0xFFFFFFFF);
            canvas.drawCircle(lx, ly, dpToPx(1.5f), dot);
        }
    }

    private int getFpsColor(float fps) {
        if (fps >= 55) return ThemeManager.getGradientStart(); // 绿
        if (fps >= 30) return 0xFFE0DD31;                      // 黄
        return 0xFFFF3246;                                      // 红
    }

    private int applyAlpha(int color, float alpha) {
        int a = (int)(Color.alpha(color) * alpha);
        return (color & 0x00FFFFFF) | (a << 24);
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }
}
