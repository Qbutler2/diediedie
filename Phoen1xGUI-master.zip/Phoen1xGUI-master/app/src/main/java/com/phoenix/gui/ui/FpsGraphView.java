package com.phoenix.gui.ui;

import android.content.Context;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * FPS 心电图可视化 View
 * 实时绘制 FPS 折线，像心电图一样从右向左滚动
 * 使用 View.postOnAnimation() 挂钩真实帧回调，FPS 精准
 */
public class FpsGraphView extends View {

    private static final int MAX_POINTS = 120;
    private static final int TARGET_FPS = 60;

    private final Deque<Float> fpsHistory = new ArrayDeque<>();
    private final Paint linePaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gridPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path  linePath   = new Path();

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // FPS 计算 - 用真实时间差
    private long  lastSampleTime = 0;
    private int   frameCount     = 0;
    private float currentFps     = 0f;
    private boolean running      = false;

    // 挂钩真实 vsync 的 Runnable
    private final Runnable frameCallback = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            frameCount++;
            long now = System.nanoTime();
            if (lastSampleTime == 0) lastSampleTime = now;
            long elapsed = now - lastSampleTime;
            if (elapsed >= 500_000_000L) { // 每 0.5 秒采样一次
                currentFps = frameCount * 1_000_000_000f / elapsed;
                frameCount = 0;
                lastSampleTime = now;
                if (fpsHistory.size() >= MAX_POINTS) fpsHistory.pollFirst();
                fpsHistory.addLast(currentFps);
                invalidate();
            }
            // postOnAnimation 挂钩系统 vsync，比 postDelayed(16) 精准得多
            postOnAnimation(this);
        }
    };

    public FpsGraphView(Context context) {
        super(context);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setWillNotDraw(false);

        bgPaint.setColor(0xCC0A0E10);
        bgPaint.setStyle(Paint.Style.FILL);

        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(dpToPx(1.8f));
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        linePaint.setStrokeJoin(Paint.Join.ROUND);

        glowPaint.setStyle(Paint.Style.STROKE);
        glowPaint.setStrokeWidth(dpToPx(4f));
        glowPaint.setStrokeCap(Paint.Cap.ROUND);
        glowPaint.setMaskFilter(new BlurMaskFilter(dpToPx(6f), BlurMaskFilter.Blur.NORMAL));

        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(dpToPx(0.5f));
        gridPaint.setColor(0x22FFFFFF);

        labelPaint.setTextSize(dpToPx(9f));
        labelPaint.setColor(0x88FFFFFF);
        labelPaint.setAntiAlias(true);
        labelPaint.setTypeface(Typeface.MONOSPACE);
    }

    public void startMonitoring() {
        if (running) return;
        running = true;
        frameCount = 0;
        lastSampleTime = 0;
        fpsHistory.clear();
        setVisibility(VISIBLE);
        postOnAnimation(frameCallback);
    }

    public void stopMonitoring() {
        running = false;
        removeCallbacks(frameCallback);
        setVisibility(GONE);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        float pad    = dpToPx(4f);
        float graphW = w - pad * 2;
        float graphH = h - pad * 2 - dpToPx(14f);
        float baseY  = pad + graphH;

        // 背景
        canvas.drawRoundRect(new RectF(0, 0, w, h), dpToPx(6f), dpToPx(6f), bgPaint);

        // 网格参考线
        float y60 = baseY - (60f / 70f) * graphH * 0.85f;
        float y30 = baseY - (30f / 70f) * graphH * 0.85f;
        canvas.drawLine(pad, y60, w - pad, y60, gridPaint);
        canvas.drawLine(pad, y30, w - pad, y30, gridPaint);

        labelPaint.setColor(0x88FFFFFF);
        labelPaint.setTextSize(dpToPx(9f));
        labelPaint.setTypeface(Typeface.MONOSPACE);
        canvas.drawText("60", pad + dpToPx(2f), y60 - dpToPx(1f), labelPaint);
        canvas.drawText("30", pad + dpToPx(2f), y30 - dpToPx(1f), labelPaint);

        // 当前 FPS 标签
        String fpsLabel = String.format("%.0f FPS", currentFps);
        labelPaint.setColor(getFpsColor(currentFps));
        labelPaint.setTextSize(dpToPx(10f));
        labelPaint.setTypeface(Typeface.DEFAULT_BOLD);
        canvas.drawText(fpsLabel, w - labelPaint.measureText(fpsLabel) - pad, h - dpToPx(2f), labelPaint);

        if (fpsHistory.size() < 2) return;

        Float[] samples = fpsHistory.toArray(new Float[0]);
        int count = samples.length;
        float stepX  = graphW / (MAX_POINTS - 1f);
        float maxFps = 70f;
        int startIdx = Math.max(0, MAX_POINTS - count);

        // 构建路径
        linePath.reset();
        boolean first = true;
        for (int i = 0; i < count; i++) {
            float fps = Math.min(samples[i], maxFps);
            float x = pad + (startIdx + i) * stepX;
            float y = baseY - (fps / maxFps) * graphH * 0.85f;
            if (first) { linePath.moveTo(x, y); first = false; }
            else        { linePath.lineTo(x, y); }
        }

        int lineColor = getFpsColor(currentFps);

        // 发光层
        glowPaint.setColor(lineColor & 0x00FFFFFF | 0x55000000);
        canvas.drawPath(linePath, glowPaint);

        // 主线（逐段渐变透明度）
        for (int i = 0; i < count - 1; i++) {
            float f1 = Math.min(samples[i],     maxFps);
            float f2 = Math.min(samples[i + 1], maxFps);
            int   idx = startIdx + i;
            float x1 = pad + idx * stepX;
            float y1 = baseY - (f1 / maxFps) * graphH * 0.85f;
            float x2 = pad + (idx + 1) * stepX;
            float y2 = baseY - (f2 / maxFps) * graphH * 0.85f;
            float alpha = 0.3f + 0.7f * ((float) i / count);
            linePaint.setColor(applyAlpha(getFpsColor(f2), alpha));
            canvas.drawLine(x1, y1, x2, y2, linePaint);
        }

        // 心跳点（最新一点）
        float lastFps = Math.min(samples[count - 1], maxFps);
        float lx = pad + (startIdx + count - 1) * stepX;
        float ly = baseY - (lastFps / maxFps) * graphH * 0.85f;
        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        dot.setColor(lineColor);
        dot.setMaskFilter(new BlurMaskFilter(dpToPx(4f), BlurMaskFilter.Blur.NORMAL));
        canvas.drawCircle(lx, ly, dpToPx(3f), dot);
        dot.setMaskFilter(null);
        dot.setColor(0xFFFFFFFF);
        canvas.drawCircle(lx, ly, dpToPx(1.5f), dot);
    }

    private int getFpsColor(float fps) {
        if (fps >= 55) return ThemeManager.getGradientStart();
        if (fps >= 30) return 0xFFE0DD31;
        return 0xFFFF3246;
    }

    private int applyAlpha(int color, float alpha) {
        int a = (int)(Color.alpha(color) * alpha);
        return (color & 0x00FFFFFF) | (a << 24);
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }
}
