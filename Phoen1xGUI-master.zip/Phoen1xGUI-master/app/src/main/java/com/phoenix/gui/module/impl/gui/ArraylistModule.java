package com.phoenix.gui.module.impl.gui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.ui.ArraylistView;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

/** Arraylist: WRAP_CONTENT 右上角，NOT_TOUCHABLE */
public class ArraylistModule extends Module {
    private WindowManager wm;
    private ArraylistView view;

    public ArraylistModule() { super("Arraylist", ModuleCategory.VISUAL, "Shows enabled modules list"); }
    @Override protected void onEnable()  { show(); }
    @Override protected void onDisable() { hide(); }

    private void show() {
        Context ctx = UI.getContext();
        if (ctx == null) return;
        wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams wlp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.END;

        view = new ArraylistView(ctx);
        for (Module m : ModuleManager.getAllModules()) {
            if (m.isEnabled() && !(m instanceof ArraylistModule))
                try { view.addModule(m.getName()); } catch (Exception ignored) {}
        }
        try {
            wm.addView(view, wlp);
            view.show();
            UI.setArraylistView(view);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void hide() {
        UI.setArraylistView(null);
        if (view != null) { view.clearModules(); try { wm.removeView(view); } catch (Exception ignored) {} view = null; }
        wm = null;
    }
}
