package com.phoenix.gui.module.impl.gui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.ui.ArraylistView;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

public class ArraylistModule extends Module {

    private WindowManager wm;
    private ArraylistView arraylistView;

    public ArraylistModule() {
        super("Arraylist", ModuleCategory.VISUAL, "Shows enabled modules list");
    }

    @Override protected void onEnable()  { show(); }
    @Override protected void onDisable() { hide(); }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addText("Displays active modules on screen.");
    }

    private void show() {
        Context ctx = UI.getContext();
        if (ctx == null) return;
        wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams wlp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.START;

        arraylistView = new ArraylistView(ctx);
        for (Module m : ModuleManager.getAllModules()) {
            if (m.isEnabled() && !(m instanceof ArraylistModule)) {
                try { arraylistView.addModule(m.getName()); } catch (Exception ignored) {}
            }
        }

        try {
            wm.addView(arraylistView, wlp);
            arraylistView.show();
            UI.setArraylistView(arraylistView);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void hide() {
        UI.setArraylistView(null);
        if (arraylistView != null && wm != null) {
            arraylistView.clearModules();
            try { wm.removeView(arraylistView); } catch (Exception ignored) {}
            arraylistView = null;
        }
        wm = null;
    }
}
