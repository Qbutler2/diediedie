package com.phoenix.gui.module.impl.gui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.module.impl.visual.NotificationsModule;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

public class NotificationsOverlayModule extends Module implements ModuleToggleListener {

    private WindowManager wm;
    private FrameLayout container;
    private static boolean showOnToggle = true;

    public NotificationsOverlayModule() {
        super("Notifications", ModuleCategory.VISUAL, "Solstice-style notifications");
    }

    @Override
    protected void onEnable() {
        Context ctx = UI.getContext();
        if (ctx == null) return;
        wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams wlp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.START;

        container = new FrameLayout(ctx);
        try {
            wm.addView(container, wlp);
            NotificationsModule.init(container, ctx);
            ModuleManager.addToggleListener(this);
            NotificationsModule.notify("Notifications enabled", NotificationsModule.Type.SUCCESS, 2000);
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    protected void onDisable() {
        ModuleManager.removeToggleListener(this);
        if (container != null && wm != null) {
            try { wm.removeView(container); } catch (Exception ignored) {}
            container = null;
        }
        wm = null;
    }

    @Override
    public void onModuleToggled(Module module) {
        if (!showOnToggle || module == this) return;
        NotificationsModule.notify(
                module.getName() + (module.isEnabled() ? " enabled" : " disabled"),
                module.isEnabled() ? NotificationsModule.Type.SUCCESS : NotificationsModule.Type.INFO,
                2500);
    }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSwitch("Show on toggle", showOnToggle, v -> showOnToggle = v);
    }
}
