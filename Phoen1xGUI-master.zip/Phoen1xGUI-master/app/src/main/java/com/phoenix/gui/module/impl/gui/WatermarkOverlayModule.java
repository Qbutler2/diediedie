package com.phoenix.gui.module.impl.gui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.WatermarkView;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

public class WatermarkOverlayModule extends Module {

    private WindowManager wm;
    private WatermarkView watermarkView;
    private boolean watermarkAtTop = true;

    public WatermarkOverlayModule() {
        super("Watermark", ModuleCategory.VISUAL, "Show Wufan Client watermark on screen.");
    }

    @Override protected void onEnable()  { show(); }
    @Override protected void onDisable() { hide(); }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addText("Displays 'Wufan Client' watermark.");
    }

    private void show() {
        Context ctx = UI.getContext();
        if (ctx == null) return;
        wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams wlp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.START;
        wlp.x = 0;
        wlp.y = 0;

        watermarkView = new WatermarkView(ctx);
        try {
            wm.addView(watermarkView, wlp);
            watermarkView.setAlpha(0f);
            watermarkView.animate().alpha(1f).setDuration(400).start();
            startBounceAnimation(wlp);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void startBounceAnimation(WindowManager.LayoutParams wlp) {
        watermarkView.postDelayed(new Runnable() {
            @Override public void run() {
                if (watermarkView == null || wm == null) return;
                int screenH = watermarkView.getResources().getDisplayMetrics().heightPixels;
                int viewH = watermarkView.getHeight();
                if (viewH == 0) { watermarkView.postDelayed(this, 500); return; }
                int targetY = watermarkAtTop ? (screenH - viewH) : 0;
                watermarkAtTop = !watermarkAtTop;
                watermarkView.animate()
                        .translationY(targetY)
                        .setDuration(1200)
                        .setInterpolator(new OvershootInterpolator(0.5f))
                        .withEndAction(() -> { if (watermarkView != null) watermarkView.postDelayed(this, 3000); })
                        .start();
            }
        }, 2000);
    }

    private void hide() {
        if (watermarkView != null && wm != null) {
            try { wm.removeView(watermarkView); } catch (Exception ignored) {}
            watermarkView = null;
        }
        wm = null;
    }
}
