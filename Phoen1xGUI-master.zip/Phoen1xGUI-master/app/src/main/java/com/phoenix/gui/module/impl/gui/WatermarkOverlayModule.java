package com.phoenix.gui.module.impl.gui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.WatermarkView;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

/** Watermark: WRAP_CONTENT 左上角，NOT_TOUCHABLE，上下弹跳动画 */
public class WatermarkOverlayModule extends Module {
    private WindowManager wm;
    private WatermarkView view;
    private WindowManager.LayoutParams wlp;
    private boolean atTop = true;

    public WatermarkOverlayModule() { super("Watermark", ModuleCategory.VISUAL, "Show Wufan Client watermark"); }
    @Override protected void onEnable()  { show(); }
    @Override protected void onDisable() { hide(); }
    @Override public boolean supportsShortcut() { return true; }

    private void show() {
        Context ctx = UI.getContext();
        if (ctx == null) return;
        wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        wlp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.START;
        wlp.x = 0; wlp.y = 0;

        view = new WatermarkView(ctx);
        try {
            wm.addView(view, wlp);
            view.setAlpha(0f);
            view.animate().alpha(1f).setDuration(400).start();
            startBounce();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void startBounce() {
        if (view == null) return;
        Runnable[] selfRef = new Runnable[1];
        selfRef[0] = new Runnable() {
            @Override public void run() {
                if (view == null || wm == null) return;
                int screenH = view.getResources().getDisplayMetrics().heightPixels;
                int viewH = view.getHeight();
                if (viewH == 0) { view.postDelayed(selfRef[0], 500); return; }
                int targetY = atTop ? (screenH - viewH) : 0;
                atTop = !atTop;
                // 通过 wlp.y + updateViewLayout 移动（不用 translationY，避免和 wlp 冲突）
                final int startY = wlp.y;
                final int endY = targetY;
                android.animation.ValueAnimator anim = android.animation.ValueAnimator.ofInt(startY, endY);
                anim.setDuration(1200);
                anim.setInterpolator(new android.view.animation.OvershootInterpolator(0.5f));
                anim.addUpdateListener(a -> {
                    if (wm == null || view == null) { anim.cancel(); return; }
                    wlp.y = (int) a.getAnimatedValue();
                    try { wm.updateViewLayout(view, wlp); } catch (Exception ignored) { anim.cancel(); }
                });
                anim.addListener(new android.animation.AnimatorListenerAdapter() {
                    @Override public void onAnimationEnd(android.animation.Animator a) {
                        if (view != null) view.postDelayed(selfRef[0], 3000);
                    }
                });
                anim.start();
            }
        };
        view.postDelayed(selfRef[0], 2000);
    }

    private void hide() {
        if (view != null) { try { wm.removeView(view); } catch (Exception ignored) {} view = null; }
        wm = null;
    }
}
