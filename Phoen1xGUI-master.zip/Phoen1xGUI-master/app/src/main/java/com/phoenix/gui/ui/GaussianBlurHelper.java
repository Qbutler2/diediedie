package com.phoenix.gui.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.view.View;

/**
 * GaussianBlurHelper
 *
 * 仿照 Prax D2D 高斯模糊实现：
 *  1. 截取 rootView 当前帧（等同 D2D 的 CopyFromBitmap sourceBitmap）
 *  2. 裁剪到目标 View 区域
 *  3. 用 RenderScript ScriptIntrinsicBlur 做真正的高斯模糊
 *     （等同 D2D 的 blurEffect SetValue D2D1_GAUSSIANBLUR_PROP_STANDARD_DEVIATION）
 *  4. 返回 Bitmap，由调用方绘制到 canvas（等同 D2D 的 FillGeometry）
 *
 * 只对比自身 elevation 低的内容做模糊（通过临时隐藏高图层 View 实现）
 */
public class GaussianBlurHelper {

    // 模糊半径（等同 Prax 的 strength，RenderScript 上限 25f）
    private static final float BLUR_RADIUS = 18f;

    // 降采样倍率（先缩小再模糊再放大，提升性能同时增强模糊效果）
    private static final int DOWNSAMPLE = 4;

    private static RenderScript rs;

    /**
     * 初始化 RenderScript（在 Application 或 Activity.onCreate 里调用一次）
     */
    public static void init(Context ctx) {
        if (rs == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            rs = RenderScript.create(ctx.getApplicationContext());
        }
    }

    /**
     * 为 targetView 生成高斯模糊背景 Bitmap。
     * 只模糊比 targetView.getElevation() 低的内容。
     *
     * @param targetView 需要模糊背景的 View
     * @return 模糊后的 Bitmap（尺寸与 targetView 一致），失败返回 null
     */
    public static Bitmap blur(View targetView) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN_MR1) return null;
        if (rs == null) return null;

        try {
            View root = targetView.getRootView();
            if (root == null || targetView.getWidth() <= 0 || targetView.getHeight() <= 0) return null;

            // ── 1. 隐藏比自身 elevation 高或相等的兄弟 View（图层感知）──
            float selfElevation = targetView.getElevation();
            java.util.List<View> hidden = new java.util.ArrayList<>();
            if (targetView.getParent() instanceof android.view.ViewGroup) {
                android.view.ViewGroup parent = (android.view.ViewGroup) targetView.getParent();
                for (int i = 0; i < parent.getChildCount(); i++) {
                    View child = parent.getChildAt(i);
                    if (child != targetView
                            && child.getVisibility() == View.VISIBLE
                            && child.getElevation() >= selfElevation) {
                        child.setVisibility(View.INVISIBLE);
                        hidden.add(child);
                    }
                }
            }

            // ── 2. 截取 rootView 全图 ──
            root.setDrawingCacheEnabled(true);
            Bitmap fullScreen = root.getDrawingCache(true);
            Bitmap result = null;

            if (fullScreen != null && !fullScreen.isRecycled()) {
                int[] loc = new int[2];
                targetView.getLocationOnScreen(loc);

                int x = loc[0];
                int y = loc[1];
                int w = targetView.getWidth();
                int h = targetView.getHeight();

                // 边界检查
                if (x >= 0 && y >= 0
                        && x + w <= fullScreen.getWidth()
                        && y + h <= fullScreen.getHeight()
                        && w > 0 && h > 0) {

                    // ── 3. 裁剪到 targetView 区域 ──
                    Bitmap cropped = Bitmap.createBitmap(fullScreen, x, y, w, h);

                    // ── 4. 降采样 ──
                    int sw = Math.max(1, w / DOWNSAMPLE);
                    int sh = Math.max(1, h / DOWNSAMPLE);
                    Bitmap small = Bitmap.createScaledBitmap(cropped, sw, sh, true);
                    cropped.recycle();

                    // ── 5. RenderScript 高斯模糊（等同 D2D ScriptIntrinsicBlur）──
                    Bitmap blurred = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
                    Allocation input  = Allocation.createFromBitmap(rs, small,
                            Allocation.MipmapControl.MIPMAP_NONE, Allocation.USAGE_SCRIPT);
                    Allocation output = Allocation.createTyped(rs, input.getType());

                    ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
                    script.setRadius(Math.min(BLUR_RADIUS, 25f));
                    script.setInput(input);
                    script.forEach(output);
                    output.copyTo(blurred);

                    input.destroy();
                    output.destroy();
                    script.destroy();
                    small.recycle();

                    // ── 6. 放大回原尺寸（等同 D2D FillGeometry 拉伸填充）──
                    result = Bitmap.createScaledBitmap(blurred, w, h, true);
                    blurred.recycle();
                }
            }

            // ── 7. 还原被隐藏的 View ──
            for (View v : hidden) {
                v.setVisibility(View.VISIBLE);
            }

            return result;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 便捷方法：直接将模糊后的 Bitmap 绘制到 canvas 的指定区域
     *
     * @param blurBitmap blur() 返回的 Bitmap
     * @param canvas     目标 canvas
     * @param destRect   绘制区域（通常是 View 的 backgroundRect）
     * @param alpha      透明度 0-255
     */
    public static void drawBlur(Bitmap blurBitmap, Canvas canvas, android.graphics.RectF destRect, int alpha) {
        if (blurBitmap == null || blurBitmap.isRecycled()) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        p.setAlpha(alpha);
        canvas.drawBitmap(blurBitmap, null,
                new Rect((int)destRect.left, (int)destRect.top, (int)destRect.right, (int)destRect.bottom), p);
    }

    public static void release() {
        if (rs != null) {
            rs.destroy();
            rs = null;
        }
    }
}
