package com.phoenix.gui.module.impl.misc;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.ui.ThemeManager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * NotificationsModule - 仿 Solstice 风格通知系统
 *
 * 通知条从屏幕右侧滑入，带进度条，3秒后自动消失。
 * 模块开/关时自动触发。
 *
 * 使用方法：
 *   NotificationsModule.notify(context, container, "消息", NotificationsModule.Type.INFO, 3000);
 */
public class NotificationsModule extends Module implements ModuleToggleListener {

    // ===== 通知类型（对应 Solstice 的 Info/Warning/Error）=====
    public enum Type {
        INFO,    // 蓝色
        SUCCESS, // 绿色
        WARNING, // 黄色
        ERROR    // 红色
    }

    // ===== 单条通知数据 =====
    public static class Notification {
        public final String message;
        public final Type type;
        public final long duration; // ms
        public long startTime;
        public NotificationView view;

        public Notification(String message, Type type, long duration) {
            this.message   = message;
            this.type      = type;
            this.duration  = duration;
            this.startTime = System.currentTimeMillis();
        }

        public float getProgress() {
            long elapsed = System.currentTimeMillis() - startTime;
            return 1f - Math.min(1f, (float) elapsed / duration);
        }

        public boolean isExpired() {
            return System.currentTimeMillis() - startTime > duration + 400;
        }
    }

    // ===== 通知 View =====
    public static class NotificationView extends View {
        private static final int HEIGHT_DP    = 52;
        private static final int WIDTH_DP     = 240;
        private static final int CORNER_DP    = 10;
        private static final int BAR_HEIGHT_DP= 3;

        private final Notification notification;
        private final Paint bgPaint       = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barPaint      = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barBgPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accentPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint borderPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF bgRect        = new RectF();
        private final RectF barRect       = new RectF();
        private final RectF barBgRect     = new RectF();
        private final RectF accentRect    = new RectF();

        public NotificationView(Context context, Notification notification) {
            super(context);
            this.notification = notification;
            setLayerType(LAYER_TYPE_SOFTWARE, null);

            // 背景
            bgPaint.setColor(0xF0111414);

            // 进度条（主题色）
            barPaint.setColor(getTypeColor());

            // 进度条背景
            barBgPaint.setColor(0x33FFFFFF);

            // 文字
            textPaint.setTextSize(dpToPx(13));
            textPaint.setColor(0xFFFFFFFF);
            textPaint.setAntiAlias(true);
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);

            // 左侧accent条
            accentPaint.setColor(getTypeColor());

            // 边框
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(1f);
            borderPaint.setColor(0x22FFFFFF);
        }

        private int getTypeColor() {
            switch (notification.type) {
                case SUCCESS: return ThemeManager.COLOR_SUCCESS;
                case WARNING: return ThemeManager.COLOR_WARNING;
                case ERROR:   return ThemeManager.COLOR_WARNING; // 复用红色
                default:      return ThemeManager.COLOR_INFO;
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight();
            float r = dpToPx(CORNER_DP);
            float barH = dpToPx(BAR_HEIGHT_DP);
            float accentW = dpToPx(3);

            // 1. 背景
            bgRect.set(0, 0, w, h - barH);
            canvas.drawRoundRect(bgRect, r, r, bgPaint);

            // 2. 边框
            canvas.drawRoundRect(bgRect, r, r, borderPaint);

            // 3. 左侧accent条
            accentRect.set(0, dpToPx(8), accentW, h - barH - dpToPx(8));
            canvas.drawRoundRect(accentRect, accentW / 2, accentW / 2, accentPaint);

            // 4. 标题（类型标签）
            String typeLabel;
            switch (notification.type) {
                case SUCCESS: typeLabel = "✓ "; break;
                case WARNING: typeLabel = "⚠ "; break;
                case ERROR:   typeLabel = "✗ "; break;
                default:      typeLabel = "ℹ "; break;
            }

            // 画类型标签（颜色）
            Paint labelPaint = new Paint(textPaint);
            labelPaint.setColor(getTypeColor());
            canvas.drawText(typeLabel, dpToPx(10), h / 2 - barH / 2 + dpToPx(5), labelPaint);

            // 5. 消息文字
            float labelW = labelPaint.measureText(typeLabel);
            Paint msgPaint = new Paint(textPaint);
            msgPaint.setTypeface(Typeface.DEFAULT);
            msgPaint.setTextSize(dpToPx(12));
            // 截断过长文字
            String msg = notification.message;
            float maxW = w - dpToPx(14) - labelW;
            if (msgPaint.measureText(msg) > maxW) {
                while (msg.length() > 0 && msgPaint.measureText(msg + "...") > maxW) {
                    msg = msg.substring(0, msg.length() - 1);
                }
                msg += "...";
            }
            canvas.drawText(msg, dpToPx(10) + labelW, h / 2 - barH / 2 + dpToPx(5), msgPaint);

            // 6. 进度条背景
            barBgRect.set(0, h - barH, w, h);
            canvas.drawRect(barBgRect, barBgPaint);

            // 7. 进度条（从右向左缩短，类似 Solstice）
            float progress = notification.getProgress();
            barRect.set(0, h - barH, w * progress, h);
            canvas.drawRect(barRect, barPaint);

            // 持续重绘（更新进度条）
            invalidate();
        }

        private float dpToPx(float dp) {
            return dp * getResources().getDisplayMetrics().density;
        }
    }

    // ===== 静态通知管理器 =====

    private static final List<Notification> activeNotifications = new ArrayList<>();
    private static FrameLayout notifContainer;
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());
    private static final Runnable cleanupRunnable = new Runnable() {
        @Override
        public void run() {
            cleanup();
            mainHandler.postDelayed(this, 500);
        }
    };

    /**
     * 初始化通知容器（在 UI.show() 里调用）
     */
    public static void init(FrameLayout container) {
        notifContainer = container;
        mainHandler.post(cleanupRunnable);
    }

    /**
     * 发送通知
     */
    public static void notify(Context context, String message, Type type, long durationMs) {
        mainHandler.post(() -> {
            if (notifContainer == null) return;

            Notification notif = new Notification(message, type, durationMs);
            NotificationView view = new NotificationView(context, notif);
            notif.view = view;

            int heightPx = (int) (NotificationView.HEIGHT_DP * context.getResources().getDisplayMetrics().density);
            int widthPx  = (int) (NotificationView.WIDTH_DP  * context.getResources().getDisplayMetrics().density);
            int margin   = (int) (8 * context.getResources().getDisplayMetrics().density);

            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(widthPx, heightPx);
            params.gravity = Gravity.BOTTOM | Gravity.END;

            // 根据已有通知数量计算 Y 偏移（从下往上堆叠）
            int stackIndex = activeNotifications.size();
            params.bottomMargin = margin + stackIndex * (heightPx + margin);
            params.rightMargin  = margin;

            notifContainer.addView(view, params);
            activeNotifications.add(notif);

            // 滑入动画
            view.setTranslationX(widthPx + margin);
            view.animate()
                    .translationX(0f)
                    .setDuration(350)
                    .setInterpolator(new OvershootInterpolator(0.8f))
                    .start();

            // 定时消失
            mainHandler.postDelayed(() -> dismiss(notif), durationMs);
        });
    }

    private static void dismiss(Notification notif) {
        if (notif.view == null) return;
        NotificationView view = notif.view;

        view.animate()
                .translationX(view.getWidth() + 20)
                .alpha(0f)
                .setDuration(300)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    if (notifContainer != null) notifContainer.removeView(view);
                    activeNotifications.remove(notif);
                    reshufflePositions(view.getContext());
                })
                .start();
    }

    private static void reshufflePositions(Context context) {
        float density = context.getResources().getDisplayMetrics().density;
        int heightPx = (int) (NotificationView.HEIGHT_DP * density);
        int margin   = (int) (8 * density);

        for (int i = 0; i < activeNotifications.size(); i++) {
            Notification n = activeNotifications.get(i);
            if (n.view == null) continue;
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) n.view.getLayoutParams();
            int targetBottom = margin + i * (heightPx + margin);
            if (lp.bottomMargin != targetBottom) {
                lp.bottomMargin = targetBottom;
                n.view.setLayoutParams(lp);
            }
        }
    }

    private static void cleanup() {
        Iterator<Notification> it = activeNotifications.iterator();
        while (it.hasNext()) {
            Notification n = it.next();
            if (n.isExpired() && n.view != null) {
                if (notifContainer != null) notifContainer.removeView(n.view);
                it.remove();
            }
        }
    }

    // ===== Module 实现 =====

    public NotificationsModule() {
        super("Notifications", ModuleCategory.MISC, "Show notifications on module toggle");
    }

    @Override
    public void onEnable() {
        ModuleManager.addToggleListener(this);
        if (notifContainer != null) {
            notify(notifContainer.getContext(), "Notifications enabled", Type.SUCCESS, 2500);
        }
    }

    @Override
    public void onDisable() {
        ModuleManager.removeToggleListener(this);
    }

    @Override
    public void onModuleToggled(Module module) {
        // 自己切换不通知（避免循环）
        if (module == this) return;
        if (notifContainer == null) return;

        String msg = module.getName() + (module.isEnabled() ? " enabled" : " disabled");
        Type type  = module.isEnabled() ? Type.SUCCESS : Type.INFO;
        notify(notifContainer.getContext(), msg, type, 2500);
    }
}
