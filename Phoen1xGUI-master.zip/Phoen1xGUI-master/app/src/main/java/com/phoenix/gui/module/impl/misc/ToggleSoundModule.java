package com.phoenix.gui.module.impl.misc;

import android.content.Context;
import android.media.MediaPlayer;
import com.phoenix.gui.R;
import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;

/**
 * ToggleSound - 模块开关时播放音效
 * 支持 Celestial / Smooth / Nursultan 三种音效，和音量调节
 */
public class ToggleSoundModule extends Module {

    public enum SoundType {
        CELESTIAL,
        SMOOTH,
        NURSULTAN
    }

    // 当前音效选择（默认 Celestial）
    private static SoundType currentSound = SoundType.CELESTIAL;
    // 音量 0.0 ~ 1.0
    private static float volume = 0.8f;

    private static Context appContext;

    public ToggleSoundModule() {
        super("ToggleSound", ModuleCategory.MISC, "Play a sound when toggling modules");
    }

    /** 在 UI.init() 里调用，注入 Context */
    public static void init(Context ctx) {
        appContext = ctx.getApplicationContext();
    }

    public static SoundType getCurrentSound() { return currentSound; }
    public static void setCurrentSound(SoundType s) { currentSound = s; }
    public static float getVolume() { return volume; }
    public static void setVolume(float v) { volume = Math.max(0f, Math.min(1f, v)); }

    /**
     * 静态方法，供 ModuleManager 在模块切换时调用
     */
    public static void playToggleSound(boolean enabled) {
        if (appContext == null) return;
        try {
            int resId;
            switch (currentSound) {
                case SMOOTH:
                    resId = enabled ? R.raw.smooth_on : R.raw.smooth_off;
                    break;
                case NURSULTAN:
                    resId = enabled ? R.raw.nursultan_on : R.raw.nursultan_off;
                    break;
                default: // CELESTIAL
                    resId = enabled ? R.raw.celestial_on : R.raw.celestial_off;
                    break;
            }
            MediaPlayer mp = MediaPlayer.create(appContext, resId);
            if (mp != null) {
                mp.setVolume(volume, volume);
                mp.start();
                mp.setOnCompletionListener(MediaPlayer::release);
            }
        } catch (Exception e) {
            // ignore
        }
    }

    @Override
    public void onEnable() {
        playToggleSound(true);
    }

    @Override
    public void onDisable() {
        playToggleSound(false);
    }

    @Override
    public void configureSubMenu(com.phoenix.gui.ui.widgets.SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);

        // 音效选择按钮
        subMenu.addButton("Sound: " + currentSound.name(), () -> {
            // 循环切换
            SoundType[] vals = SoundType.values();
            int next = (currentSound.ordinal() + 1) % vals.length;
            currentSound = vals[next];
            // 按钮文字无法动态刷新，关闭子菜单再打开即可看到
        });

        // 音量调节（用两个按钮 +/- ）
        subMenu.addButton("Vol+", () -> setVolume(volume + 0.1f));
        subMenu.addButton("Vol-", () -> setVolume(volume - 0.1f));
    }
}
