package com.phoenix.gui.module.impl.misc;

import android.content.Context;
import android.media.MediaPlayer;

import com.wufan.client.R;
import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

import java.util.Arrays;

/**
 * ToggleSound — 模块开关时播放音效
 * Celestial / Smooth / Nursultan 三种（来自 Solstice）
 * 样式切换用 addMode（同 KillAura 的 Signal/Multi）
 */
public class ToggleSoundModule extends Module {

    // 0=Celestial 1=Smooth 2=Nursultan
    private static int soundIndex = 0;
    private static int volumePercent = 80;
    private static Context appContext;

    private static final String[] SOUND_NAMES = {"Celestial", "Smooth", "Nursultan"};

    public ToggleSoundModule() {
        super("ToggleSound", ModuleCategory.MISC, "Play a sound when toggling modules");
    }

    public static void init(Context ctx) {
        appContext = ctx.getApplicationContext();
    }

    public static void playToggleSound(boolean enabled) {
        if (appContext == null) return;
        try {
            int resId;
            switch (soundIndex) {
                case 1:
                    resId = enabled ? R.raw.smooth_on : R.raw.smooth_off;
                    break;
                case 2:
                    resId = enabled ? R.raw.nursultan_on : R.raw.nursultan_off;
                    break;
                default: // 0 = Celestial
                    resId = enabled ? R.raw.celestial_on : R.raw.celestial_off;
                    break;
            }
            float vol = volumePercent / 100f;
            MediaPlayer mp = MediaPlayer.create(appContext, resId);
            if (mp != null) {
                mp.setVolume(vol, vol);
                mp.start();
                mp.setOnCompletionListener(MediaPlayer::release);
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onEnable() { playToggleSound(true); }

    @Override
    public void onDisable() { playToggleSound(false); }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);

        // 用 addMode 切换音效（和 KillAura Target 的 Single/Multi 一样）
        subMenu.addMode("Sound", Arrays.asList(SOUND_NAMES), soundIndex, (index, name) -> {
            soundIndex = index;
            playToggleSound(true); // 预览
        });

        subMenu.addSlider("Volume", 0, 100, volumePercent, "%d", v -> volumePercent = v);
    }
}
