package com.phoenix.gui.module.impl.misc;

import android.content.Context;
import android.media.MediaPlayer;

import com.phoenix.gui.R;
import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

/**
 * ToggleSound — 模块开关时播放音效
 * 支持 Celestial / Smooth / Nursultan 三种音效（来自 Solstice）
 * 支持音量滑块
 */
public class ToggleSoundModule extends Module {

    public enum SoundType {
        CELESTIAL("Celestial"),
        SMOOTH("Smooth"),
        NURSULTAN("Nursultan");

        public final String label;
        SoundType(String label) { this.label = label; }
    }

    private static SoundType currentSound = SoundType.CELESTIAL;
    private static int volumePercent = 80; // 0~100
    private static Context appContext;

    public ToggleSoundModule() {
        super("ToggleSound", ModuleCategory.MISC, "Play a sound when toggling modules");
    }

    public static void init(Context ctx) {
        appContext = ctx.getApplicationContext();
    }

    public static void playToggleSound(boolean enabled) {
        if (appContext == null) return;
        try {
            int resId;
            switch (currentSound) {
                case SMOOTH:
                    resId = enabled ? R.raw.smooth_on : R.raw.smooth_off;
                    break;
                case NURSULTAN:
                    resId = enabled ? R.raw.nursultan_on : R.raw.nursultan_off;
                    break;
                default: // CELESTIAL
                    resId = enabled ? R.raw.celestial_on : R.raw.celestial_off;
                    break;
            }
            float vol = volumePercent / 100f;
            MediaPlayer mp = MediaPlayer.create(appContext, resId);
            if (mp != null) {
                mp.setVolume(vol, vol);
                mp.start();
                mp.setOnCompletionListener(MediaPlayer::release);
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onEnable() {
        playToggleSound(true);
    }

    @Override
    public void onDisable() {
        playToggleSound(false);
    }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);

        // 音效选择（三个按钮，点亮当前选中）
        subMenu.addText("Sound type:");
        for (SoundType s : SoundType.values()) {
            subMenu.addButton(
                (s == currentSound ? "► " : "  ") + s.label,
                () -> {
                    currentSound = s;
                    // 选完立刻播一下预览
                    playToggleSound(true);
                }
            );
        }

        // 音量滑块 0~100
        subMenu.addSlider("Volume", 0, 100, volumePercent, "%d", v -> volumePercent = v);
    }
}
