package com.phoenix.gui.module.impl.misc;

import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;

/**
 * ToggleSound - 模块开关时播放音效
 * 开启时播放高音提示，关闭时播放低音提示
 */
public class ToggleSoundModule extends Module {

    private static ToneGenerator toneGenerator;

    public ToggleSoundModule() {
        super("ToggleSound", ModuleCategory.MISC, "Play a sound when toggling modules");
    }

    @Override
    public void onEnable() {
        playSound(true);
    }

    @Override
    public void onDisable() {
        playSound(false);
    }

    /**
     * 静态方法，供其他模块切换时调用
     * 在 Module.enable() / Module.disable() 里调用
     */
    public static void playToggleSound(boolean enabled) {
        try {
            if (toneGenerator == null) {
                toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 60);
            }
            if (enabled) {
                // 开启：DTMF_9 高频音
                toneGenerator.startTone(ToneGenerator.TONE_DTMF_9, 80);
            } else {
                // 关闭：DTMF_1 低频音
                toneGenerator.startTone(ToneGenerator.TONE_DTMF_1, 80);
            }
        } catch (Exception e) {
            // ignore
        }
    }

    private void playSound(boolean enabled) {
        playToggleSound(enabled);
    }

    @Override
    public boolean supportsShortcut() {
        return true;
    }
}
