package com.phoenix.gui.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.module.ModuleManager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MenuView extends LinearLayout implements ThemeManager.OnThemeColorChangeListener {

    private static final String PREF_NAME        = "menu_view_settings";
    private static final String KEY_SCALE_FACTOR = "scale_factor";

    // 模糊更新间隔
    private static final int BLUR_INTERVAL = 80;

    private final Context context;
    private final ModuleCategory category;
    private final MenuPosition position;
    private final SharedPreferences preferences;

    private boolean isExpanded = false;

    private final LinearLayout titleBar;
    private final ScrollView scrollView;
    private final LinearLayout contentLayout;

    private final Map<Module, ModuleItemView> moduleItems = new HashMap<>();
    private ValueAnimator expandAnimator;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private float touchStartX = 0f;
    private float touchStartY = 0f;
    private boolean isDragging = false;
    private final int touchSlop;

    private float scaleFactor = 1.0f;
    private final float baseScaleFactor;

    private static final long ANIMATION_DURATION = 300L;
    private static final float CORNER_RADIUS_DP  = 14f; // 更大圆角匹配MC风格

    private static int globalMaxWidth = 0;

    // ===== 高斯模糊 =====
    private Bitmap blurredBackground;
    private final Paint blurPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Handler blurHandler = new Handler(Looper.getMainLooper());
    private final Runnable blurRunnable = new Runnable() {
        @Override
        public void run() {
            if (getVisibility() == View.VISIBLE) {
                captureAndBlurBackground();
            }
            blurHandler.postDelayed(this, BLUR_INTERVAL);
        }
    };

    private final Runnable statusChecker = new Runnable() {
        @Override
        public void run() {
            if (getVisibility() == View.VISIBLE && isExpanded) {
                refreshAllModuleStates();
                handler.postDelayed(this, 500);
            }
        }
    };

    public enum MenuPosition {
        POSITION_1, POSITION_2, POSITION_3, POSITION_4, POSITION_5, POSITION_6
    }

    public MenuView(Context context, ModuleCategory category, MenuPosition position) {
        super(context);
        this.context      = context;
        this.category     = category;
        this.position     = position;
        this.preferences  = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        this.touchSlop    = ViewConfiguration.get(context).getScaledTouchSlop();
        this.baseScaleFactor = calculateBaseScaleFactor() * 0.75f;
        this.scaleFactor  = 1.0f;

        blurPaint.setAlpha(255);
        setWillNotDraw(false); // 允许自绘模糊背景
        setLayerType(LAYER_TYPE_HARDWARE, null);
        setOrientation(VERTICAL);

        // 设置半透明黑底（匹配MC客户端风格）
        applyBackground();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setClipToOutline(true);
            setElevation(scaled(8));
        }

        setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        int titleHeight = scaled(36);
        int spacing     = scaled(12);
        setTranslationY(position.ordinal() * (titleHeight + spacing));

        titleBar = createTitleBar();
        addView(titleBar);

        scrollView = new ScrollView(context);
        scrollView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, 0));
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setVisibility(View.GONE);
        scrollView.setBackgroundColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            scrollView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }

        contentLayout = new LinearLayout(context);
        contentLayout.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        contentLayout.setOrientation(VERTICAL);
        contentLayout.setBackgroundColor(Color.TRANSPARENT);

        List<Module> modules = ModuleManager.getModulesByCategory(category);
        for (Module module : modules) {
            ModuleItemView item = new ModuleItemView(context, module, this, baseScaleFactor * scaleFactor);
            moduleItems.put(module, item);
            contentLayout.addView(item);

            // 添加模块之间的细分割线
            View divider = new View(context);
            divider.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, 1));
            divider.setBackgroundColor(0x1AFFFFFF);
            contentLayout.addView(divider);
        }

        scrollView.addView(contentLayout);
        addView(scrollView);

        setupTouchListeners();
        ThemeManager.addListener(this);
    }

    // ===== 背景绘制（无模糊）=====

    @Override
    protected void dispatchDraw(Canvas canvas) {
        float r = scaled(CORNER_RADIUS_DP);
        RectF rect = new RectF(0, 0, getWidth(), getHeight());

        // 1. 半透明深色背景
        Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(0xD0101414);
        canvas.drawRoundRect(rect, r, r, bgPaint);

        // 2. 细边框
        Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1f);
        borderPaint.setColor(0x33FFFFFF);
        canvas.drawRoundRect(rect, r, r, borderPaint);

        // 3. 顶部渐变高光线
        drawTopHighlight(canvas);

        // 4. 子View
        super.dispatchDraw(canvas);
    }

    private void drawTopHighlight(Canvas canvas) {
        float r = scaled(CORNER_RADIUS_DP);
        LinearGradient grad = new LinearGradient(
                r, 0, getWidth() - r, 0,
                new int[]{0x00FFFFFF, ThemeManager.getGradientStart(), ThemeManager.getGradientEnd(), 0x00FFFFFF},
                new float[]{0f, 0.3f, 0.7f, 1f},
                Shader.TileMode.CLAMP);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(grad);
        p.setAlpha(160);
        canvas.drawRect(r, 0, getWidth() - r, dpToPx(1f), p);
    }

    private void captureAndBlurBackground() {
        try {
            View root = getRootView();
            if (root == null || getWidth() <= 0 || getHeight() <= 0) return;

            int w = getWidth(), h = getHeight();

            // 截图前隐藏自己，避免把自己模糊进去（真正的毛玻璃）
            setVisibility(INVISIBLE);

            Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bitmap);
            int[] loc = new int[2];
            getLocationInWindow(loc);
            c.translate(-loc[0], -loc[1]);
            root.draw(c);

            setVisibility(VISIBLE);

            if (blurredBackground != null && !blurredBackground.isRecycled()) {
                blurredBackground.recycle();
            }
            blurredBackground = multiPassBlur(bitmap, w, h, 6);
            bitmap.recycle();

            postInvalidate();
        } catch (Exception e) {
            try { setVisibility(VISIBLE); } catch (Exception ignored) {}
        }
    }

    private Bitmap multiPassBlur(Bitmap src, int targetW, int targetH, int passes) {
        // 先缩小到 1/8 再放大，模拟高斯模糊（顺滑且性能好）
        // 每次缩小用双线性插值（createScaledBitmap 第四参数 true）
        Bitmap result = src;
        for (int i = 0; i < passes; i++) {
            int nw = Math.max(1, result.getWidth()  / 2);
            int nh = Math.max(1, result.getHeight() / 2);
            Bitmap small = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888);
            android.graphics.Canvas sc = new android.graphics.Canvas(small);
            android.graphics.Paint sp = new android.graphics.Paint(
                    android.graphics.Paint.FILTER_BITMAP_FLAG | android.graphics.Paint.ANTI_ALIAS_FLAG);
            sc.drawBitmap(result, null,
                    new android.graphics.Rect(0, 0, nw, nh), sp);
            if (result != src) result.recycle();
            result = small;
        }
        // 最终放大回原尺寸，用 FILTER_BITMAP 双线性插值产生模糊
        Bitmap blurred = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas bc = new android.graphics.Canvas(blurred);
        android.graphics.Paint bp = new android.graphics.Paint(
                android.graphics.Paint.FILTER_BITMAP_FLAG | android.graphics.Paint.ANTI_ALIAS_FLAG);
        bc.drawBitmap(result, null,
                new android.graphics.Rect(0, 0, targetW, targetH), bp);
        if (result != src) result.recycle();
        return blurred;
    }

    // ===== 背景 =====

    private void applyBackground() {
        // 完全透明背景，让dispatchDraw自绘
        setBackgroundColor(Color.TRANSPARENT);
    }

    // ===== TitleBar =====

    private LinearLayout createTitleBar() {
        LinearLayout bar = new LinearLayout(context);
        int height = scaled(36);
        bar.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, height));
        bar.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        bar.setPadding(scaled(14), 0, scaled(14), 0);
        bar.setBackgroundColor(Color.TRANSPARENT);

        // 左侧颜色标记（类似MC客户端的颜色标识）
        View accent = new View(context);
        int accentW = scaled(3);
        int accentH = scaled(16);
        LinearLayout.LayoutParams accentParams = new LinearLayout.LayoutParams(accentW, accentH);
        accentParams.setMargins(0, 0, scaled(8), 0);
        accent.setBackground(createAccentDrawable());
        bar.addView(accent, accentParams);

        TextView textView = new TextView(context);
        textView.setText(category.getDisplayName());
        textView.setTextSize(11.5f * baseScaleFactor * scaleFactor);
        textView.setTextColor(ThemeManager.getTextPrimary());
        textView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        bar.addView(textView);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            bar.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }
        return bar;
    }

    private android.graphics.drawable.Drawable createAccentDrawable() {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        d.setCornerRadius(dpToPx(2f));
        d.setColors(new int[]{ThemeManager.getGradientStart(), ThemeManager.getGradientEnd()});
        d.setGradientType(android.graphics.drawable.GradientDrawable.LINEAR_GRADIENT);
        d.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM);
        return d;
    }

    // ===== 触摸 =====

    private void setupTouchListeners() {
        final float[] lastRaw = new float[2];

        titleBar.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    touchStartX = event.getX();
                    touchStartY = event.getY();
                    lastRaw[0]  = event.getRawX();
                    lastRaw[1]  = event.getRawY();
                    isDragging  = false;
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dX = Math.abs(event.getX() - touchStartX);
                    float dY = Math.abs(event.getY() - touchStartY);
                    if (!isDragging && (dX > touchSlop || dY > touchSlop)) {
                        isDragging = true;
                    }
                    if (isDragging) {
                        setTranslationX(getTranslationX() + event.getRawX() - lastRaw[0]);
                        setTranslationY(getTranslationY() + event.getRawY() - lastRaw[1]);
                        lastRaw[0] = event.getRawX();
                        lastRaw[1] = event.getRawY();
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    if (!isDragging) toggleExpand();
                    isDragging = false;
                    return true;

                case MotionEvent.ACTION_CANCEL:
                    isDragging = false;
                    return true;
            }
            return false;
        });
    }

    // ===== 展开/收起 =====

    private void toggleExpand() {
        if (expandAnimator != null) expandAnimator.cancel();
        if (isExpanded) collapseContent();
        else expandContent();
    }

    private void expandContent() {
        isExpanded = true;
        scrollView.setVisibility(View.VISIBLE);

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);

        contentLayout.measure(
                MeasureSpec.makeMeasureSpec(globalMaxWidth, MeasureSpec.AT_MOST),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
        int maxHeight    = (int) (dm.heightPixels * 0.5);
        int targetHeight = Math.min(contentLayout.getMeasuredHeight(), maxHeight);

        scrollView.setAlpha(0f);
        LayoutParams lp = (LayoutParams) scrollView.getLayoutParams();
        lp.height = 0;
        scrollView.setLayoutParams(lp);

        expandAnimator = ValueAnimator.ofInt(0, targetHeight);
        expandAnimator.setDuration(ANIMATION_DURATION);
        expandAnimator.setInterpolator(new DecelerateInterpolator(1.5f));
        expandAnimator.addUpdateListener(a -> {
            int val = (int) a.getAnimatedValue();
            LayoutParams p = (LayoutParams) scrollView.getLayoutParams();
            p.height = val;
            scrollView.setLayoutParams(p);
            scrollView.setAlpha((float) val / targetHeight);
        });
        expandAnimator.start();
        handler.post(statusChecker);
    }

    private void collapseContent() {
        isExpanded = false;
        int startH = scrollView.getHeight();
        closeAllSubMenus();
        handler.removeCallbacks(statusChecker);

        expandAnimator = ValueAnimator.ofInt(startH, 0);
        expandAnimator.setDuration(ANIMATION_DURATION);
        expandAnimator.setInterpolator(new DecelerateInterpolator());
        expandAnimator.addUpdateListener(a -> {
            int val = (int) a.getAnimatedValue();
            LayoutParams p = (LayoutParams) scrollView.getLayoutParams();
            p.height = val;
            scrollView.setLayoutParams(p);
            if (startH > 0) scrollView.setAlpha((float) val / startH);
        });
        expandAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                scrollView.setVisibility(View.GONE);
            }
        });
        expandAnimator.start();
    }

    // ===== 显示/隐藏 =====

    public void show() {
        setVisibility(View.VISIBLE);
        measureInitialSize();

        setAlpha(0f);
        setScaleX(0.85f);
        setScaleY(0.85f);
        animate()
                .alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(ANIMATION_DURATION)
                .setInterpolator(new DecelerateInterpolator(1.5f))
                .start();

        // blurHandler.post(blurRunnable); // 模糊已禁用
        if (isExpanded) handler.post(statusChecker);
    }

    public void hide() {
        handler.removeCallbacks(statusChecker);
        blurHandler.removeCallbacks(blurRunnable); // 停止模糊

        if (expandAnimator != null) expandAnimator.cancel();
        animate().cancel();

        for (ModuleItemView item : moduleItems.values()) {
            item.cancelAllAnimations();
        }

        animate()
                .alpha(0f).scaleX(0.85f).scaleY(0.85f)
                .setDuration(ANIMATION_DURATION)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> setVisibility(View.GONE))
                .start();
    }

    // ===== 缩放 =====

    public float getScaleFactor() { return scaleFactor; }

    public void setScaleFactor(float factor) {
        factor = Math.max(0.5f, Math.min(2.0f, factor));
        if (Math.abs(this.scaleFactor - factor) < 0.01f) return;
        this.scaleFactor = factor;
        preferences.edit().putFloat(KEY_SCALE_FACTOR, factor).apply();
        rebuildUI();
    }

    public void increaseScale() { setScaleFactor(scaleFactor * 1.1f); }
    public void decreaseScale() { setScaleFactor(scaleFactor * 0.9f); }
    public void resetScale()    { setScaleFactor(1.0f); }

    private void rebuildUI() {
        boolean wasExp = isExpanded;
        if (isExpanded) collapseContent();

        updateTitleBar();

        for (ModuleItemView item : moduleItems.values()) {
            item.updateScale(baseScaleFactor * scaleFactor);
        }

        globalMaxWidth = 0;
        measureInitialSize();

        if (wasExp) handler.postDelayed(this::expandContent, 100);
    }

    private void updateTitleBar() {
        int height = scaled(36);
        titleBar.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, height));
        titleBar.setPadding(scaled(14), 0, scaled(14), 0);

        TextView textView = (TextView) titleBar.getChildAt(1); // index 1 因为 0 是 accent bar
        if (textView instanceof TextView) {
            textView.setTextSize(11.5f * baseScaleFactor * scaleFactor);
        }
    }

    private void measureInitialSize() {
        int maxWidth = globalMaxWidth;

        titleBar.measure(
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
        maxWidth = Math.max(maxWidth, titleBar.getMeasuredWidth());

        for (ModuleItemView item : moduleItems.values()) {
            item.measure(
                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),
                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
            maxWidth = Math.max(maxWidth, item.getMeasuredWidth());
        }

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        int smaller = Math.min(dm.widthPixels, dm.heightPixels);
        int minW    = (int)(smaller * 0.3);
        int maxW    = (int)(smaller * 0.5);
        maxWidth    = Math.max(minW, Math.min(maxWidth, maxW));

        if (maxWidth > globalMaxWidth) globalMaxWidth = maxWidth;

        ViewGroup.LayoutParams lp = getLayoutParams();
        if (lp != null) {
            lp.width = globalMaxWidth;
            setLayoutParams(lp);
        }
    }

    private void refreshAllModuleStates() {
        for (Map.Entry<Module, ModuleItemView> e : moduleItems.entrySet()) {
            e.getValue().syncWithModuleState(e.getKey().isEnabled());
        }
    }

    public void closeAllSubMenus() {
        for (ModuleItemView item : moduleItems.values()) {
            item.closeSubMenuIfOpen();
        }
    }

    public void destroy() {
        ThemeManager.removeListener(this);
        blurHandler.removeCallbacks(blurRunnable);
        if (expandAnimator != null) expandAnimator.cancel();
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onThemeColorChanged(int newColor) {
        // 刷新标题栏左侧accent条
        if (titleBar.getChildCount() > 0) {
            View accent = titleBar.getChildAt(0);
            accent.setBackground(createAccentDrawable());
        }
        for (ModuleItemView item : moduleItems.values()) {
            item.updateThemeColor();
        }
    }

    // ===== 工具 =====

    private float calculateBaseScaleFactor() {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        float dpi = dm.densityDpi;
        if (dpi <= 240) return 0.7f;
        if (dpi <= 320) return 0.85f;
        if (dpi <= 480) return 1.0f;
        if (dpi <= 640) return 1.15f;
        return 1.3f;
    }

    private int scaled(int baseDp) {
        return (int) (dpToPx(baseDp) * baseScaleFactor * scaleFactor);
    }

    private float scaled(float baseDp) {
        return dpToPx((int) baseDp) * baseScaleFactor * scaleFactor;
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }

    public String getScaleInfo() {
        return String.format("基础缩放: %.2f, 用户缩放: %.2f, 总缩放: %.2f",
                baseScaleFactor, scaleFactor, baseScaleFactor * scaleFactor);
    }

    // ── 独立悬浮窗支持：根据 POSITION 计算 gravity 和 x/y 偏移 ──

    public int getOverlayGravity() {
        return Gravity.TOP | Gravity.START;
    }

    /**
     * 6个菜单分两列布局（左3右3），围绕屏幕中心区域排列
     * POSITION_1~3 在左侧，POSITION_4~6 在右侧
     */
    public int getOverlayX(int screenW, int screenH) {
        int col = position.ordinal() < 3 ? 0 : 1; // 0=左列, 1=右列
        int menuW = (int)(Math.min(screenW, screenH) * 0.38f);
        int padding = (int)(8 * context.getResources().getDisplayMetrics().density);
        if (col == 0) {
            return padding;
        } else {
            return screenW - menuW - padding;
        }
    }

    public int getOverlayY(int screenW, int screenH) {
        int row = position.ordinal() % 3; // 0,1,2
        int menuH = (int)(screenH * 0.28f);
        int topOffset = (int)(screenH * 0.08f);
        int gap = (int)(6 * context.getResources().getDisplayMetrics().density);
        return topOffset + row * (menuH + gap);
    }
}
