package com.phoenix.gui.module;

import com.phoenix.gui.module.impl.combat.*;
import com.phoenix.gui.module.impl.movement.*;
import com.phoenix.gui.module.impl.player.*;
import com.phoenix.gui.module.impl.visual.*;
import com.phoenix.gui.module.impl.visual.FpsGraphModule;
import com.phoenix.gui.module.impl.world.*;
import com.phoenix.gui.module.impl.misc.*;
import com.phoenix.gui.module.impl.gui.FloatBallModule;
import com.phoenix.gui.module.impl.gui.ArraylistModule;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private static final List<Module> modules = new ArrayList<>();
    private static final List<ModuleToggleListener> listeners = new ArrayList<>();
    private static final List<ShortcutToggleListener> shortcutListeners = new ArrayList<>();

    static {
        registerModules();
    }

    private static void registerModules() {
        // Combat
        register(new HitBoxModule());
        register(new InfiniteAuraModule());
        register(new KillAuraModule());
        register(new FightBotModule());
        register(new RideModule());
        register(new LockBackModule());

        // Movement
        register(new AirJumpModule());
        register(new SpeedModule());
        register(new FastStopModule());
        register(new ScaffoldModule());
        register(new JekBackModule());
        register(new FlyModule());

        // Player
        register(new AntiBotModule());
        register(new BlinkModule());
        register(new NameTagModule());
        register(new PhasesModule());
        register(new TeleportModule());

        // Visual（含 Notifications）
        register(new ThemeModule());
        register(new WatermarkModule());
        register(new FpsGraphModule());
        register(new FloatBallModule());
        register(new ArraylistModule());
        register(new FovModule());
        register(new DisableModule());
        register(new GodModeModule());
        register(new OnPosModule());
        register(new InfiniteYModule());
        register(new NotificationsModule());

        // World
        register(new FuckerModule());
        register(new RemoteStopModule());
        register(new GameModeModule());
        register(new AutoClickModule());
        register(new AimAssetsModule());

        // Misc
        register(new ToggleSoundModule());
    }

    private static void register(Module module) {
        modules.add(module);
    }

    public static List<Module> getAllModules() {
        return new ArrayList<>(modules);
    }

    public static List<Module> getModulesByCategory(ModuleCategory category) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) result.add(m);
        }
        return result;
    }

    public static Module getModuleByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) return m;
        }
        return null;
    }

    public static void addToggleListener(ModuleToggleListener l) {
        if (!listeners.contains(l)) listeners.add(l);
    }

    public static void removeToggleListener(ModuleToggleListener l) {
        listeners.remove(l);
    }

    public static void addShortcutListener(ShortcutToggleListener l) {
        shortcutListeners.add(l);
    }

    public static void removeShortcutListener(ShortcutToggleListener l) {
        shortcutListeners.remove(l);
    }

    public static void notifyModuleToggled(Module module) {
        // ToggleSound 联动
        ToggleSoundModule sound = (ToggleSoundModule) getModuleByName("ToggleSound");
        if (sound != null && sound.isEnabled()) {
            ToggleSoundModule.playToggleSound(module.isEnabled());
        }

        for (ModuleToggleListener l : new ArrayList<>(listeners)) {
            l.onModuleToggled(module);
        }
    }

    public static void notifyShortcutToggled(Module module, boolean enabled) {
        for (ShortcutToggleListener l : shortcutListeners) {
            l.onShortcutToggled(module, enabled);
        }
    }

    public static void disableAll() {
        for (Module m : modules) {
            if (m.isEnabled()) m.disable();
        }
    }

    private ModuleManager() {}
}
