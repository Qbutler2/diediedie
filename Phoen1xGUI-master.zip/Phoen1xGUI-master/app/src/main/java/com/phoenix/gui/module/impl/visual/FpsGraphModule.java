package com.phoenix.gui.module.impl.visual;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.FpsGraphView;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

/**
 * FpsGraphModule - 独立悬浮窗 FPS 折线图
 * 可拖动，叠加在任何应用上方，关闭时完全消失
 */
public class FpsGraphModule extends Module {

    private FpsGraphView graphView;
    private WindowManager windowManager;
    private WindowManager.LayoutParams wlp;

    // 拖动用
    private float dragStartX, dragStartY;
    private int   initWlpX,  initWlpY;

    public FpsGraphModule() {
        super("FpsGraph", ModuleCategory.VISUAL, "Real-time FPS ECG visualization");
    }

    @Override
    protected void onEnable() {
        showGraph();
    }

    @Override
    protected void onDisable() {
        hideGraph();
    }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addText("Displays a real-time FPS graph. Drag to move.");
    }

    private void showGraph() {
        Context ctx = UI.getContext();
        if (ctx == null) return;

        windowManager = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (windowManager == null) return;

        graphView = new FpsGraphView(ctx);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        float density = ctx.getResources().getDisplayMetrics().density;
        int w = (int)(200 * density);
        int h = (int)(80  * density);

        wlp = new WindowManager.LayoutParams(
                w, h, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.START;
        wlp.x = (int)(8 * density);
        wlp.y = (int)(80 * density); // 顶部留出状态栏

        // 拖动支持
        graphView.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragStartX = event.getRawX();
                    dragStartY = event.getRawY();
                    initWlpX   = wlp.x;
                    initWlpY   = wlp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    wlp.x = initWlpX + (int)(event.getRawX() - dragStartX);
                    wlp.y = initWlpY + (int)(event.getRawY() - dragStartY);
                    try { windowManager.updateViewLayout(graphView, wlp); } catch (Exception ignored) {}
                    return true;
            }
            return false;
        });

        try {
            windowManager.addView(graphView, wlp);
            graphView.startMonitoring();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideGraph() {
        if (graphView != null) {
            graphView.stopMonitoring();
            try {
                if (windowManager != null) windowManager.removeView(graphView);
            } catch (Exception ignored) {}
            graphView = null;
        }
        windowManager = null;
    }
}
