package com.phoenix.gui.module.impl.visual;

import android.content.Context;
import android.view.Gravity;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.FpsGraphView;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

public class FpsGraphModule extends Module {

    private FpsGraphView graphView;

    public FpsGraphModule() {
        super("FpsGraph", ModuleCategory.VISUAL, "Real-time FPS ECG visualization");
    }

    @Override
    protected void onEnable() {
        showGraph();
    }

    @Override
    protected void onDisable() {
        hideGraph();
    }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addText("Displays a real-time FPS graph like an ECG.");
    }

    private void showGraph() {
        FrameLayout container = UI.getArraylistContainer();
        if (container == null) return;

        Context ctx = container.getContext();
        container.post(() -> {
            try {
                if (graphView != null) {
                    graphView.stopMonitoring();
                    container.removeView(graphView);
                }
                graphView = new FpsGraphView(ctx);
                int w = (int)(ctx.getResources().getDisplayMetrics().density * 200);
                int h = (int)(ctx.getResources().getDisplayMetrics().density * 80);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h);
                lp.gravity = Gravity.BOTTOM | Gravity.START;
                lp.bottomMargin = (int)(ctx.getResources().getDisplayMetrics().density * 8);
                lp.leftMargin   = (int)(ctx.getResources().getDisplayMetrics().density * 8);
                container.addView(graphView, lp);
                graphView.startMonitoring();
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private void hideGraph() {
        if (graphView == null) return;
        graphView.stopMonitoring();
        FrameLayout container = UI.getArraylistContainer();
        if (container != null) container.post(() -> {
            try { container.removeView(graphView); } catch (Exception ignored) {}
        });
        graphView = null;
    }
}
