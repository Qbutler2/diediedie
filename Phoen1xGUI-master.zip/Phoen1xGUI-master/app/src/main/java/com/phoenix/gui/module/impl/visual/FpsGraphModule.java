package com.phoenix.gui.module.impl.visual;

import android.content.Context;
import android.view.Gravity;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.FpsGraphView;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

/**
 * FpsGraphModule - 应用内浮动 FPS 折线图
 * 显示在 arraylistContainer 内，可拖动，不影响其他控件
 */
public class FpsGraphModule extends Module {

    private FpsGraphView graphView;

    public FpsGraphModule() {
        super("FpsGraph", ModuleCategory.VISUAL, "Real-time FPS ECG visualization");
    }

    @Override
    protected void onEnable() {
        showGraph();
    }

    @Override
    protected void onDisable() {
        hideGraph();
    }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addText("Real-time FPS graph. Drag to move.");
    }

    private void showGraph() {
        FrameLayout container = UI.getArraylistContainer();
        if (container == null) return;

        Context ctx = container.getContext();
        container.post(() -> {
            try {
                if (graphView != null) {
                    graphView.stopMonitoring();
                    container.removeView(graphView);
                }

                graphView = new FpsGraphView(ctx);
                float density = ctx.getResources().getDisplayMetrics().density;
                int w = (int)(200 * density);
                int h = (int)(80  * density);

                // WRAP_CONTENT + 绝对位置，靠左下角，不占布局空间
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h);
                lp.gravity = Gravity.BOTTOM | Gravity.START;
                lp.bottomMargin = (int)(8 * density);
                lp.leftMargin   = (int)(8 * density);

                container.addView(graphView, lp);
                graphView.startMonitoring();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void hideGraph() {
        FrameLayout container = UI.getArraylistContainer();
        if (graphView == null) return;
        graphView.stopMonitoring(); // 内部已调用 setVisibility(GONE)
        if (container != null) {
            container.post(() -> {
                try { container.removeView(graphView); } catch (Exception ignored) {}
            });
        }
        graphView = null;
    }
}
