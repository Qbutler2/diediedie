package com.phoenix.gui.ui.dynamic;

import android.content.Context;
import android.graphics.Typeface;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.OvershootInterpolator;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import com.phoenix.gui.ui.ThemeManager;

public class CollapsedContentView extends LinearLayout implements ThemeManager.OnThemeColorChangeListener {

    private ImageView brandIcon;
    private TextView brandText;
    private ImageView userIcon;
    private TextView userText;
    private ImageView fpsIcon;
    private TextView fpsText; // 合并成一个 TextView，避免宽度动画 bug

    private DynamicIslandManager manager;
    private float scale = 0.7f;
    private int currentFps = -1; // -1 表示尚未初始化

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public CollapsedContentView(@NonNull Context context) {
        super(context);
        init(context);
    }

    private void init(Context context) {
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER);
        setPadding((int) dp(12 * scale), 0, (int) dp(12 * scale), 0);

        createBrandModule(context);
        addSeparator(context);
        createUserModule(context);
        addSeparator(context);
        createFpsModule(context);
    }

    private void createBrandModule(Context context) {
        LinearLayout mod = new LinearLayout(context);
        mod.setOrientation(HORIZONTAL);
        mod.setGravity(Gravity.CENTER_VERTICAL);

        brandIcon = new ImageView(context);
        try {
            int id = context.getResources().getIdentifier("icon", "drawable", context.getPackageName());
            brandIcon.setImageResource(id != 0 ? id : android.R.drawable.ic_menu_info_details);
        } catch (Exception e) {
            brandIcon.setImageResource(android.R.drawable.ic_menu_info_details);
        }
        brandIcon.setColorFilter(ThemeManager.getThemeColor());
        int sz = (int) dp(16 * scale);
        mod.addView(brandIcon, new LayoutParams(sz, sz));

        View spacer = new View(context);
        mod.addView(spacer, new LayoutParams((int) dp(4 * scale), 0));

        brandText = makeText(context, "Wufan Client", ThemeManager.getThemeColor(), true);
        mod.addView(brandText);
        addView(mod);
    }

    private void createUserModule(Context context) {
        LinearLayout mod = new LinearLayout(context);
        mod.setOrientation(HORIZONTAL);
        mod.setGravity(Gravity.CENTER_VERTICAL);

        userIcon = new ImageView(context);
        userIcon.setImageResource(android.R.drawable.ic_menu_myplaces);
        userIcon.setColorFilter(ThemeManager.getTextSecondary());
        int sz = (int) dp(16 * scale);
        mod.addView(userIcon, new LayoutParams(sz, sz));

        View spacer = new View(context);
        mod.addView(spacer, new LayoutParams((int) dp(4 * scale), 0));

        userText = makeText(context, "User", ThemeManager.getTextSecondary(), false);
        mod.addView(userText);
        addView(mod);
    }

    private void createFpsModule(Context context) {
        LinearLayout mod = new LinearLayout(context);
        mod.setOrientation(HORIZONTAL);
        mod.setGravity(Gravity.CENTER_VERTICAL);

        fpsIcon = new ImageView(context);
        fpsIcon.setImageResource(android.R.drawable.ic_menu_manage);
        fpsIcon.setColorFilter(ThemeManager.getTextSecondary());
        int sz = (int) dp(16 * scale);
        mod.addView(fpsIcon, new LayoutParams(sz, sz));

        View spacer = new View(context);
        mod.addView(spacer, new LayoutParams((int) dp(4 * scale), 0));

        // FPS 用单个 TextView 直接显示 "XX FPS"，避免双 View 宽度竞争
        fpsText = makeText(context, "-- FPS", ThemeManager.getTextSecondary(), false);
        mod.addView(fpsText);
        addView(mod);
    }

    // ── 公开接口 ──

    public void setManager(DynamicIslandManager manager) {
        this.manager = manager;
        updateContent();
    }

    public void updateContent() {
        if (manager == null) return;
        if (userText != null) userText.setText(manager.getPersistentText());
        // 从 manager 取最新 FPS 刷新一次
        int fps = manager.getCurrentFps();
        if (fps != currentFps) {
            currentFps = fps;
            updateFpsText(fps);
        }
    }

    /**
     * 由 DynamicIslandView 的 Choreographer 每秒调用一次
     * 带翻转动画（上飞出 → 下飞入），类似原版效果
     */
    public void updateFps(int fps) {
        if (currentFps == fps) return;
        currentFps = fps;
        mainHandler.post(() -> animateFpsUpdate(fps));
    }

    private void animateFpsUpdate(int fps) {
        if (fpsText == null) return;
        int color;
        if (fps >= 55)      color = ThemeManager.getGradientStart();
        else if (fps >= 30) color = 0xFFE0DD31;
        else                color = 0xFFFF3246;

        final int finalColor = color;
        final String newText = fps + " FPS";

        // 阶段1：向上飞出 + 淡出
        fpsText.animate()
            .translationY(-dpAsFloat(16))
            .alpha(0f)
            .scaleX(0.85f).scaleY(0.85f)
            .setDuration(120)
            .withEndAction(() -> {
                // 切换文字和颜色
                fpsText.setTextColor(finalColor);
                fpsText.setText(newText);
                // 从下方准备飞入
                fpsText.setTranslationY(dpAsFloat(16));
                fpsText.setScaleX(1.15f);
                fpsText.setScaleY(1.15f);
                // 阶段2：从下飞入 + 淡入
                fpsText.animate()
                    .translationY(0f)
                    .alpha(1f)
                    .scaleX(1f).scaleY(1f)
                    .setDuration(320)
                    .setInterpolator(new OvershootInterpolator(2.2f))
                    .start();
            }).start();
    }

    private float dpAsFloat(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }

    public void updateConfig(float scale, String text) {
        this.scale = scale;
        if (userText != null) userText.setText(text);

        float sz = 13 * scale;
        if (brandText != null) brandText.setTextSize(sz);
        if (userText  != null) userText.setTextSize(sz);
        if (fpsText   != null) fpsText.setTextSize(sz);

        int iconSz = (int) dp(16 * scale);
        sizeIcon(brandIcon, iconSz);
        sizeIcon(userIcon,  iconSz);
        sizeIcon(fpsIcon,   iconSz);

        setPadding((int) dp(12 * scale), 0, (int) dp(12 * scale), 0);
        requestLayout();
    }

    // ── Helpers ──

    private TextView makeText(Context ctx, String text, int color, boolean bold) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(color);
        tv.setTextSize(13 * scale);
        tv.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        tv.setSingleLine(true);
        tv.setIncludeFontPadding(false);
        return tv;
    }

    private TextView makeSeparator(Context ctx) {
        TextView sep = new TextView(ctx);
        sep.setText(" • ");
        int c = (ThemeManager.getTextSecondary() & 0x00FFFFFF) | 0x55000000;
        sep.setTextColor(c);
        sep.setTextSize(13 * scale);
        sep.setIncludeFontPadding(false);
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.setMargins((int) dp(4 * scale), 0, (int) dp(4 * scale), 0);
        sep.setLayoutParams(lp);
        return sep;
    }

    private void addSeparator(Context ctx) {
        addView(makeSeparator(ctx));
    }

    private void sizeIcon(ImageView iv, int sz) {
        if (iv == null) return;
        LayoutParams lp = (LayoutParams) iv.getLayoutParams();
        if (lp != null) { lp.width = sz; lp.height = sz; iv.setLayoutParams(lp); }
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    // ── Theme ──

    @Override
    public void onThemeColorChanged(int newColor) {
        if (brandIcon != null) brandIcon.setColorFilter(newColor);
        if (brandText != null) brandText.setTextColor(newColor);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ThemeManager.addListener(this);
        onThemeColorChanged(ThemeManager.getThemeColor());
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ThemeManager.removeListener(this);
    }
}
