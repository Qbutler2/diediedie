package com.phoenix.gui.ui.widgets;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.phoenix.gui.ui.ThemeManager;

/**
 * 渐变动画设置面板
 * 包含：启用开关、颜色A、颜色B、间距(ms)、每次重复时长
 */
public class GradientAnimPickerView extends LinearLayout {

    public GradientAnimPickerView(Context context) {
        super(context);
        setOrientation(VERTICAL);
        build();
    }

    private void build() {
        int scaledPad = dpToPx(4);
        setPadding(0, scaledPad, 0, scaledPad);

        // ── 标题 ──
        addLabel("Gradient Animation", 11f, ThemeManager.getTextPrimary(), true);

        // ── 启用开关 ──
        addSwitchRow("Enable", ThemeManager.isGradientAnimEnabled(), enabled -> {
            ThemeManager.setGradientAnimEnabled(enabled);
        });

        // ── 颜色A ──
        addLabel("Color A", 10f, ThemeManager.getTextSecondary(), false);
        ColorPickerView pickerA = new ColorPickerView(getContext(), ThemeManager.getGradientAnimColorA(),
                color -> ThemeManager.setGradientAnimColorA(color));
        addView(pickerA);

        // ── 颜色B ──
        addLabel("Color B", 10f, ThemeManager.getTextSecondary(), false);
        ColorPickerView pickerB = new ColorPickerView(getContext(), ThemeManager.getGradientAnimColorB(),
                color -> ThemeManager.setGradientAnimColorB(color));
        addView(pickerB);

        // ── 间距滑块（100ms ~ 5000ms）──
        addSlider("Duration (ms)", 200, 5000, ThemeManager.getGradientAnimIntervalMs(), value -> {
            ThemeManager.setGradientAnimIntervalMs(value);
        });
    }

    private void addLabel(String text, float size, int color, boolean bold) {
        TextView tv = new TextView(getContext());
        tv.setText(text);
        tv.setTextSize(size);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(null, Typeface.BOLD);
        LayoutParams p = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dpToPx(4), 0, dpToPx(2));
        tv.setLayoutParams(p);
        addView(tv);
    }

    private void addSwitchRow(String label, boolean defaultVal, CustomSwitch.OnStateChangedListener listener) {
        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LayoutParams rowP = new LayoutParams(LayoutParams.MATCH_PARENT, dpToPx(28));
        rowP.setMargins(0, dpToPx(2), 0, dpToPx(2));
        row.setLayoutParams(rowP);

        TextView lbl = new TextView(getContext());
        lbl.setText(label);
        lbl.setTextSize(11f);
        lbl.setTextColor(ThemeManager.getTextSecondary());
        row.addView(lbl, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));

        CustomSwitch sw = new CustomSwitch(getContext(), "GradientAnim", label.toLowerCase(), defaultVal, listener);
        row.addView(sw, new LayoutParams(dpToPx(32), dpToPx(18)));
        addView(row);
    }

    private void addSlider(String label, int min, int max, int defaultVal, OnIntValueListener listener) {
        LinearLayout col = new LinearLayout(getContext());
        col.setOrientation(VERTICAL);
        LayoutParams colP = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        colP.setMargins(0, dpToPx(2), 0, dpToPx(4));
        col.setLayoutParams(colP);

        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(HORIZONTAL);
        TextView lbl = new TextView(getContext());
        lbl.setText(label);
        lbl.setTextSize(10f);
        lbl.setTextColor(ThemeManager.getTextSecondary());
        row.addView(lbl, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        TextView val = new TextView(getContext());
        val.setTextSize(10f);
        val.setTextColor(ThemeManager.getTextSecondary());
        val.setText(String.valueOf(defaultVal));
        row.addView(val);
        col.addView(row);

        CustomSlider slider = new CustomSlider(getContext(), "GradientAnim", label, min, max, defaultVal, v -> {
            val.setText(String.valueOf(v));
            listener.onValue(v);
        });
        LayoutParams sp = new LayoutParams(LayoutParams.MATCH_PARENT, dpToPx(20));
        sp.setMargins(0, dpToPx(2), 0, 0);
        col.addView(slider, sp);
        addView(col);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    public interface OnIntValueListener {
        void onValue(int value);
    }


}
