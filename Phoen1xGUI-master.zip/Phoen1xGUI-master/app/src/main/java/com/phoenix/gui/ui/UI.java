package com.phoenix.gui.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import com.wufan.client.R;
import com.phoenix.gui.config.ConfigManager;
import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.module.ShortcutToggleListener;
import com.phoenix.gui.module.impl.misc.ToggleSoundModule;
import com.phoenix.gui.module.impl.visual.NotificationsModule;
import com.phoenix.gui.module.impl.visual.WatermarkModule;
import com.phoenix.gui.ui.dynamic.DynamicIslandWindow;

public class UI {
    private static DynamicColorExtractor dynamicColorExtractor;
    private static boolean initialized = false;
    private static boolean isShowing   = false;

    private static FloatBallView   floatBall;
    private static DynamicIslandWindow dynamicIsland;
    private static ArraylistView   arraylistView;
    private static WatermarkView   watermarkView;

    // Activity 模式容器（watermark/notif/island 还保留在 Activity 布局里）
    private static FrameLayout guiContainer;
    private static FrameLayout watermarkContainer;
    private static FrameLayout dynamicIslandContainer;
    private static FrameLayout notifContainer;
    private static FrameLayout shortcutsContainer;

    private static Activity currentActivity;
    private static Context  serviceContext;

    private static boolean watermarkAtTop = true;

    // ── 公共初始化 ──────────────────────────────────────────────────────

    public static void init(Context ctx) {
        if (initialized) return;
        ConfigManager.init(ctx);
        dynamicColorExtractor = new DynamicColorExtractor(ctx);
        dynamicColorExtractor.init();
        ToggleSoundModule.init(ctx);
        initialized = true;
    }

    // ── Activity 模式 ───────────────────────────────────────────────────

    public static void show(Activity activity) {
        if (isShowing) return;
        try {
            currentActivity = activity;
            serviceContext  = null;
            if (!initialized) init(activity);
            bindContainers(activity);

            if (guiContainer != null) guiContainer.setVisibility(View.VISIBLE);

            initFloatBall(activity);
            initDynamicIsland(activity);
            initArraylist(activity);
            initNotifications(activity);
            initWatermark();

            if (activity instanceof ModuleToggleListener)
                ModuleManager.addToggleListener((ModuleToggleListener) activity);
            if (activity instanceof ShortcutToggleListener)
                ModuleManager.addShortcutListener((ShortcutToggleListener) activity);

            isShowing = true;
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ── 悬浮窗模式 ──────────────────────────────────────────────────────

    public static void initFromService(Context ctx, FrameLayout root,
                                        FrameLayout islandContainer,
                                        FrameLayout floatBallCont,
                                        FrameLayout menusCont,
                                        FrameLayout watermarkCont,
                                        FrameLayout arraylistCont) {
        if (isShowing) return;
        try {
            serviceContext         = ctx;
            currentActivity        = null;
            guiContainer           = root;
            dynamicIslandContainer = islandContainer;
            watermarkContainer     = watermarkCont;
            initialized            = true;
            shortcutsContainer     = root.findViewById(R.id.shortcuts_container);

            notifContainer = new FrameLayout(ctx);
            notifContainer.setElevation(100f);
            root.addView(notifContainer, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));

            initFloatBall(ctx);
            initDynamicIsland(ctx);
            initArraylist(ctx);
            initNotifications(ctx);
            initWatermark();

            isShowing = true;
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ── 隐藏 ────────────────────────────────────────────────────────────

    public static void hide() {
        if (!isShowing) return;
        try {
            if (currentActivity instanceof ModuleToggleListener)
                ModuleManager.removeToggleListener((ModuleToggleListener) currentActivity);
            if (currentActivity instanceof ShortcutToggleListener)
                ModuleManager.removeShortcutListener((ShortcutToggleListener) currentActivity);

            // FloatBall：独立窗口，destroy() 内部自行 removeView
            if (floatBall != null) { floatBall.hide(); floatBall.destroy(); floatBall = null; }

            // Arraylist：独立窗口
            if (arraylistView != null) {
                arraylistView.clearModules();
                arraylistView.hide();
                Context ctx = resolveContext(null);
                if (ctx != null) OverlayWindowHelper.removeView(ctx, arraylistView);
                arraylistView = null;
            }

            // Watermark
            hideWatermark();

            // DynamicIsland
            if (dynamicIsland != null) { dynamicIsland.hide(); dynamicIsland = null; }

            if (notifContainer != null) notifContainer.removeAllViews();
            if (guiContainer   != null) guiContainer.setVisibility(View.GONE);

            isShowing = false;
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ── 初始化子模块 ─────────────────────────────────────────────────────

    private static void bindContainers(Activity activity) {
        guiContainer           = activity.findViewById(R.id.gui_container);
        dynamicIslandContainer = activity.findViewById(R.id.dynamic_island_container);
        watermarkContainer     = activity.findViewById(R.id.watermark_container);
        shortcutsContainer     = activity.findViewById(R.id.shortcuts_container);

        if (guiContainer != null) {
            notifContainer = new FrameLayout(activity);
            notifContainer.setElevation(100f);
            guiContainer.addView(notifContainer, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }

    /** FloatBall 作为独立 WRAP_CONTENT 悬浮窗添加到 WindowManager */
    private static void initFloatBall(Context ctx) {
        try {
            if (floatBall != null) { floatBall.destroy(); floatBall = null; }

            floatBall = new FloatBallView(ctx);

            WindowManager.LayoutParams wlp = OverlayWindowHelper.makeWrapParams(Gravity.CENTER);
            floatBall.setSelfWlp(wlp);

            WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) wm.addView(floatBall, wlp);

            floatBall.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    /** ArraylistView 作为独立 WRAP_CONTENT 悬浮窗（右上角），不拦截触摸 */
    private static void initArraylist(Context ctx) {
        try {
            if (arraylistView != null) {
                OverlayWindowHelper.removeView(ctx, arraylistView);
                arraylistView = null;
            }

            arraylistView = new ArraylistView(ctx);

            WindowManager.LayoutParams wlp = OverlayWindowHelper.makeWrapParams(
                    Gravity.TOP | Gravity.END);
            // ArraylistView 只显示，不接收触摸
            wlp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;

            WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) wm.addView(arraylistView, wlp);

            arraylistView.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void initDynamicIsland(Context ctx) {
        if (!ConfigManager.getDynamicIslandEnabled()) return;
        try {
            if (dynamicIsland != null) { dynamicIsland.hide(); dynamicIsland = null; }
            if (dynamicIslandContainer != null) {
                dynamicIslandContainer.removeAllViews();
                dynamicIsland = new DynamicIslandWindow(ctx, dynamicIslandContainer);
                dynamicIsland.show();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void initNotifications(Context ctx) {
        if (notifContainer != null) NotificationsModule.init(notifContainer, ctx);
    }

    private static void initWatermark() {
        try {
            if (watermarkContainer == null) return;
            watermarkContainer.removeAllViews();
            Module wm = ModuleManager.getModuleByName("Watermark");
            if (wm != null && wm.isEnabled()) showWatermark();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ── Watermark 动态显隐 ───────────────────────────────────────────────

    public static void onModuleToggled(Module module) {
        if (module instanceof WatermarkModule) {
            if (module.isEnabled()) showWatermark(); else hideWatermark();
        }
    }

    private static void showWatermark() {
        if (watermarkContainer == null) return;
        Context ctx = resolveContext(null);
        if (ctx == null) return;
        Runnable run = () -> {
            try {
                if (watermarkView == null) {
                    watermarkView = new WatermarkView(ctx);
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.gravity = Gravity.TOP | Gravity.START;
                    watermarkContainer.addView(watermarkView, lp);
                }
                watermarkContainer.setVisibility(View.VISIBLE);
                watermarkView.setAlpha(0f);
                watermarkView.animate().alpha(1f).setDuration(400)
                        .setInterpolator(new DecelerateInterpolator()).start();
                startWatermarkAnimation();
            } catch (Exception e) { e.printStackTrace(); }
        };
        if (currentActivity != null) currentActivity.runOnUiThread(run);
        else watermarkContainer.post(run);
    }

    private static void hideWatermark() {
        if (watermarkContainer == null || watermarkView == null) return;
        final WatermarkView v  = watermarkView;
        final FrameLayout   c  = watermarkContainer;
        watermarkView = null;
        Runnable run = () -> {
            try {
                v.animate().cancel();
                v.animate().alpha(0f).setDuration(280).withEndAction(() -> {
                    try { c.removeView(v); c.setVisibility(View.GONE); }
                    catch (Exception ignored) {}
                }).start();
            } catch (Exception e) { e.printStackTrace(); }
        };
        if (currentActivity != null) currentActivity.runOnUiThread(run);
        else c.post(run);
    }

    private static void startWatermarkAnimation() {
        if (watermarkView == null || watermarkContainer == null) return;
        watermarkView.postDelayed(new Runnable() {
            @Override public void run() {
                final WatermarkView view = watermarkView;
                final FrameLayout   cont = watermarkContainer;
                if (view == null || cont == null) return;
                int cH = cont.getHeight(), vH = view.getHeight();
                if (cH <= 0 || vH <= 0) { view.postDelayed(this, 500); return; }
                float targetY = watermarkAtTop ? (cH - vH) : 0f;
                watermarkAtTop = !watermarkAtTop;
                view.animate().translationY(targetY).setDuration(1200)
                        .setInterpolator(new OvershootInterpolator(0.5f))
                        .withEndAction(() -> { if (watermarkView != null) watermarkView.postDelayed(this, 3000); })
                        .start();
            }
        }, 2000);
    }

    // ── 清理 ─────────────────────────────────────────────────────────────

    public static void cleanup() {
        hide();
        if (dynamicColorExtractor != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            dynamicColorExtractor.stopListening();
            dynamicColorExtractor = null;
        }
        currentActivity = null;
        serviceContext  = null;
        initialized     = false;
    }

    // ── 工具 ─────────────────────────────────────────────────────────────

    private static Context resolveContext(Context fallback) {
        if (currentActivity != null) return currentActivity;
        if (serviceContext  != null) return serviceContext;
        return fallback;
    }

    public static Context getContext()                             { return resolveContext(null); }
    public static DynamicColorExtractor getDynamicColorExtractor() { return dynamicColorExtractor; }
    public static DynamicIslandWindow getDynamicIsland()           { return dynamicIsland; }
    public static ArraylistView getArraylistView()                 { return arraylistView; }
    public static FrameLayout getShortcutsContainer()              { return shortcutsContainer; }
    public static FrameLayout getArraylistContainer()              { return null; } // 已无容器概念
    public static boolean isShowing()                             { return isShowing; }

    private UI() {}
}
