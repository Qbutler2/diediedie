package com.phoenix.gui.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import com.wufan.client.R;
import com.phoenix.gui.config.ConfigManager;
import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.module.ShortcutToggleListener;
import com.phoenix.gui.module.impl.misc.ToggleSoundModule;
import com.phoenix.gui.module.impl.visual.NotificationsModule;
import com.phoenix.gui.module.impl.visual.WatermarkModule;
import com.phoenix.gui.ui.dynamic.DynamicIslandWindow;

public class UI {
    private static DynamicColorExtractor dynamicColorExtractor;
    private static boolean initialized = false;
    private static boolean isShowing   = false;

    private static FloatBallView floatBall;
    private static DynamicIslandWindow dynamicIsland;
    private static ArraylistView arraylistView;

    // 独立悬浮窗 WindowManager（ArraylistView 和 FloatBall 各自持有）
    private static WindowManager wmArraylist;
    private static WindowManager wmFloatBall;
    private static FrameLayout   floatBallOverlayRoot; // FloatBall+Menus 的根容器

    private static FrameLayout guiContainer;
    private static FrameLayout watermarkContainer;
    private static WatermarkView watermarkView;
    private static FrameLayout floatBallContainer;
    private static FrameLayout menusContainer;
    private static FrameLayout dynamicIslandContainer;
    private static FrameLayout arraylistContainer;
    private static FrameLayout notifContainer;
    private static FrameLayout shortcutsContainer;

    private static Activity currentActivity;
    private static Context serviceContext; // 悬浮窗模式下的 Context

    private static boolean watermarkAtTop = true;

    // ── 工具：创建全屏穿透 WindowManager.LayoutParams ──
    private static WindowManager.LayoutParams makeOverlayParams() {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }

    public static void init(Context ctx) {
        if (initialized) return;
        ConfigManager.init(ctx);
        dynamicColorExtractor = new DynamicColorExtractor(ctx);
        dynamicColorExtractor.init();
        ToggleSoundModule.init(ctx);
        initialized = true;
    }

    public static void show(Activity activity) {
        if (isShowing) return;
        try {
            currentActivity = activity;
            serviceContext  = null;
            bindContainers(activity);

            if (guiContainer != null) guiContainer.setVisibility(View.VISIBLE);

            initFloatBall(activity);
            initDynamicIsland(activity);
            initArraylist(activity);
            initNotifications(activity);
            initWatermark();

            if (activity instanceof ModuleToggleListener) {
                ModuleManager.addToggleListener((ModuleToggleListener) activity);
            }
            if (activity instanceof ShortcutToggleListener) {
                ModuleManager.addShortcutListener((ShortcutToggleListener) activity);
            }

            isShowing = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 悬浮窗模式入口（由 OverlayService 调用）
     */
    public static void initFromService(Context ctx, FrameLayout root,
                                        FrameLayout islandContainer,
                                        FrameLayout floatBallCont,
                                        FrameLayout menusCont,
                                        FrameLayout watermarkCont,
                                        FrameLayout arraylistCont) {
        if (isShowing) return;
        try {
            serviceContext        = ctx;
            currentActivity       = null;
            guiContainer          = root;
            dynamicIslandContainer= islandContainer;
            // FloatBall 和 Arraylist 现在用独立 WindowManager，忽略传入容器
            watermarkContainer    = watermarkCont;
            initialized           = true;
            shortcutsContainer    = root.findViewById(com.wufan.client.R.id.shortcuts_container);

            notifContainer = new FrameLayout(ctx);
            notifContainer.setElevation(100f);
            root.addView(notifContainer, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));

            initFloatBall(ctx);
            initDynamicIsland(ctx);
            initArraylist(ctx);
            initNotifications(ctx);
            initWatermark();

            isShowing = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void hide() {
        if (!isShowing) return;
        try {
            if (currentActivity instanceof ModuleToggleListener) {
                ModuleManager.removeToggleListener((ModuleToggleListener) currentActivity);
            }
            if (currentActivity instanceof ShortcutToggleListener) {
                ModuleManager.removeShortcutListener((ShortcutToggleListener) currentActivity);
            }

            if (watermarkView != null) {
                if (watermarkContainer != null) watermarkContainer.removeAllViews();
                if (watermarkContainer != null) watermarkContainer.setVisibility(View.GONE);
                watermarkView = null;
            }

            if (arraylistView != null) {
                arraylistView.clearModules();
                arraylistView.hide();
                arraylistView = null;
            }
            if (wmArraylist != null) {
                try { if (arraylistContainer != null) wmArraylist.removeView(arraylistContainer); } catch (Exception ignored) {}
                wmArraylist = null;
                arraylistContainer = null;
            }

            if (dynamicIsland != null) {
                dynamicIsland.hide();
                dynamicIsland = null;
            }

            if (floatBall != null) {
                floatBall.hide();
                floatBall.destroy();
                floatBall = null;
            }
            if (wmFloatBall != null) {
                try { if (floatBallOverlayRoot != null) wmFloatBall.removeView(floatBallOverlayRoot); } catch (Exception ignored) {}
                wmFloatBall = null;
                floatBallOverlayRoot = null;
                menusContainer = null;
            }

            if (notifContainer != null) notifContainer.removeAllViews();

            if (guiContainer != null) guiContainer.setVisibility(View.GONE);

            isShowing = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void bindContainers(Activity activity) {
        guiContainer          = activity.findViewById(R.id.gui_container);
        floatBallContainer    = activity.findViewById(R.id.float_ball_container);
        menusContainer        = activity.findViewById(R.id.menus_container);
        dynamicIslandContainer= activity.findViewById(R.id.dynamic_island_container);
        arraylistContainer    = activity.findViewById(R.id.arraylist_container);
        watermarkContainer    = activity.findViewById(R.id.watermark_container);
        shortcutsContainer    = activity.findViewById(R.id.shortcuts_container);

        if (guiContainer != null) {
            notifContainer = new FrameLayout(activity);
            notifContainer.setElevation(100f);
            guiContainer.addView(notifContainer, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }

    private static Context resolveContext(Context fallback) {
        if (currentActivity != null) return currentActivity;
        if (serviceContext != null) return serviceContext;
        return fallback;
    }

    private static void initFloatBall(Context ctx) {
        try {
            // 销毁旧的
            if (floatBall != null) { floatBall.destroy(); floatBall = null; }
            if (floatBallOverlayRoot != null) {
                try { if (wmFloatBall != null) wmFloatBall.removeView(floatBallOverlayRoot); } catch (Exception ignored) {}
                floatBallOverlayRoot = null;
            }
            wmFloatBall = null;

            wmFloatBall = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            if (wmFloatBall == null) return;

            // 根容器：FloatBall + Menus 共用一个全屏穿透窗口
            floatBallOverlayRoot = new PassthroughFrameLayout(ctx);

            // Menus 子容器
            menusContainer = new PassthroughFrameLayout(ctx);
            menusContainer.setVisibility(View.GONE);
            floatBallOverlayRoot.addView(menusContainer, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));

            // 装饰图
            android.widget.ImageView decorView = new android.widget.ImageView(ctx);
            decorView.setId(R.id.clickgui_decoration);
            try { decorView.setImageResource(R.drawable.clickgui_decoration); } catch (Exception ignored) {}
            decorView.setScaleType(android.widget.ImageView.ScaleType.FIT_END);
            decorView.setAlpha(0.88f);
            decorView.setVisibility(View.GONE);
            float density = ctx.getResources().getDisplayMetrics().density;
            FrameLayout.LayoutParams decorLp = new FrameLayout.LayoutParams(
                    (int)(150 * density), (int)(190 * density), Gravity.BOTTOM | Gravity.START);
            decorLp.bottomMargin = (int)(-5 * density);
            decorLp.leftMargin   = (int)(-20 * density);
            floatBallOverlayRoot.addView(decorView, 0, decorLp);

            floatBall = new FloatBallView(ctx, menusContainer);
            FrameLayout.LayoutParams ballLp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER);
            floatBallOverlayRoot.addView(floatBall, ballLp);

            wmFloatBall.addView(floatBallOverlayRoot, makeOverlayParams());
            floatBall.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void initDynamicIsland(Context ctx) {
        if (!ConfigManager.getDynamicIslandEnabled()) return;
        try {
            if (dynamicIsland != null) { dynamicIsland.hide(); dynamicIsland = null; }
            if (dynamicIslandContainer != null) {
                dynamicIslandContainer.removeAllViews();
                dynamicIsland = new DynamicIslandWindow(ctx, dynamicIslandContainer);
                dynamicIsland.show();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void initArraylist(Context ctx) {
        try {
            if (arraylistView != null) { arraylistView.clearModules(); arraylistView = null; }
            if (wmArraylist != null) {
                try { wmArraylist.removeView(arraylistContainer); } catch (Exception ignored) {}
                wmArraylist = null;
                arraylistContainer = null;
            }

            wmArraylist = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            if (wmArraylist == null) return;

            arraylistContainer = new PassthroughFrameLayout(ctx);
            arraylistView = new ArraylistView(ctx);
            arraylistContainer.addView(arraylistView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));

            wmArraylist.addView(arraylistContainer, makeOverlayParams());
            arraylistView.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void initNotifications(Context ctx) {
        if (notifContainer != null) {
            NotificationsModule.init(notifContainer, ctx);
        }
    }

    private static void initWatermark() {
        try {
            if (watermarkContainer == null) return;
            watermarkContainer.removeAllViews();
            Module wm = ModuleManager.getModuleByName("Watermark");
            if (wm != null && wm.isEnabled()) showWatermark();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void onModuleToggled(Module module) {
        if (module instanceof WatermarkModule) {
            if (module.isEnabled()) showWatermark();
            else hideWatermark();
        }
    }

    private static void showWatermark() {
        if (watermarkContainer == null) return;
        Context ctx = currentActivity != null ? currentActivity : serviceContext;
        if (ctx == null) return;

        Runnable run = () -> {
            try {
                if (watermarkView == null) {
                    watermarkView = new WatermarkView(ctx);
                    FrameLayout.LayoutParams wlp = new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
                    wlp.gravity = Gravity.TOP | Gravity.START;
                    watermarkContainer.addView(watermarkView, wlp);
                }
                watermarkContainer.setVisibility(View.VISIBLE);
                watermarkView.setAlpha(0f);
                watermarkView.setTranslationY(0f);
                watermarkView.animate().alpha(1f).setDuration(400)
                        .setInterpolator(new DecelerateInterpolator()).start();
                startWatermarkAnimation();
            } catch (Exception e) { e.printStackTrace(); }
        };

        if (currentActivity != null) currentActivity.runOnUiThread(run);
        else watermarkContainer.post(run);
    }

    private static void hideWatermark() {
        if (watermarkContainer == null || watermarkView == null) return;
        final WatermarkView viewToHide    = watermarkView;
        final FrameLayout   containerRef  = watermarkContainer;
        watermarkView = null; // 立即置 null，防止动画回调里二次访问
        Runnable run = () -> {
            try {
                viewToHide.animate().cancel(); // 先取消所有动画（防止 withEndAction 互相竞争）
                viewToHide.animate()
                    .alpha(0f)
                    .setDuration(280)
                    .withEndAction(() -> {
                        try {
                            containerRef.removeView(viewToHide);
                            containerRef.setVisibility(View.GONE);
                        } catch (Exception ignored) {}
                    }).start();
            } catch (Exception e) { e.printStackTrace(); }
        };
        if (currentActivity != null) currentActivity.runOnUiThread(run);
        else containerRef.post(run);
    }

    private static void startWatermarkAnimation() {
        if (watermarkView == null || watermarkContainer == null) return;
        watermarkView.postDelayed(new Runnable() {
            @Override
            public void run() {
                // 安全检查，防止关闭时崩溃
                final WatermarkView view = watermarkView;
                final FrameLayout container = watermarkContainer;
                if (view == null || container == null) return;

                int containerH = container.getHeight();
                int viewH      = view.getHeight();
                if (containerH <= 0 || viewH <= 0) {
                    // 容器还没测量完，延迟重试
                    view.postDelayed(this, 500);
                    return;
                }

                // 目标 Y：顶部=0，底部=containerH-viewH
                float targetY = watermarkAtTop ? (containerH - viewH) : 0f;
                watermarkAtTop = !watermarkAtTop;

                view.animate()
                    .translationY(targetY)
                    .setDuration(1200)
                    .setInterpolator(new OvershootInterpolator(0.5f))
                    .withEndAction(() -> {
                        if (watermarkView != null) {
                            watermarkView.postDelayed(this, 3000);
                        }
                    }).start();
            }
        }, 2000);
    }

    public static void cleanup() {
        hide();
        if (dynamicColorExtractor != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            dynamicColorExtractor.stopListening();
            dynamicColorExtractor = null;
        }
        currentActivity = null;
        serviceContext  = null;
        initialized     = false;
    }

    public static Context getContext() {
        if (currentActivity != null) return currentActivity;
        return serviceContext;
    }
    public static DynamicColorExtractor getDynamicColorExtractor() { return dynamicColorExtractor; }
    public static DynamicIslandWindow getDynamicIsland()           { return dynamicIsland; }
    public static ArraylistView getArraylistView()                 { return arraylistView; }
    public static FrameLayout getShortcutsContainer()              { return shortcutsContainer; }
    public static FrameLayout getArraylistContainer()              { return arraylistContainer; }
    public static boolean isShowing()                             { return isShowing; }

    /** 空白区域触摸穿透的 FrameLayout */
    private static class PassthroughFrameLayout extends FrameLayout {
        public PassthroughFrameLayout(Context context) { super(context); }
        @Override public boolean onInterceptTouchEvent(android.view.MotionEvent ev) { return false; }
        @Override public boolean onTouchEvent(android.view.MotionEvent event) { return false; }
    }

    private UI() {}
}
