package com.phoenix.gui.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import com.phoenix.gui.R;
import com.phoenix.gui.config.ConfigManager;
import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.module.ShortcutToggleListener;
import com.phoenix.gui.module.impl.misc.ToggleSoundModule;
import com.phoenix.gui.module.impl.visual.NotificationsModule;
import com.phoenix.gui.module.impl.visual.WatermarkModule;
import com.phoenix.gui.ui.dynamic.DynamicIslandWindow;

public class UI {
    private static DynamicColorExtractor dynamicColorExtractor;
    private static boolean initialized = false;
    private static boolean isShowing   = false;

    private static FloatBallView floatBall;
    private static DynamicIslandWindow dynamicIsland;
    private static ArraylistView arraylistView;

    private static FrameLayout guiContainer;
    private static FrameLayout watermarkContainer;
    private static WatermarkView watermarkView;
    private static FrameLayout floatBallContainer;
    private static FrameLayout menusContainer;
    private static FrameLayout dynamicIslandContainer;
    private static FrameLayout arraylistContainer;

    // 通知容器（复用 arraylistContainer 之上，独立 FrameLayout）
    private static FrameLayout notifContainer;

    private static Activity currentActivity;

    // ===== 水印动画状态 =====
    // true = 左上角，false = 左下角
    private static boolean watermarkAtTop = true;

    public static void init(Context ctx) {
        if (initialized) return;
        ConfigManager.init(ctx);
        dynamicColorExtractor = new DynamicColorExtractor(ctx);
        dynamicColorExtractor.init();

        // 初始化 ToggleSound context
        ToggleSoundModule.init(ctx);

        initialized = true;
    }

    public static void show(Activity activity) {
        if (isShowing) return;
        try {
            currentActivity = activity;
            bindContainers(activity);

            if (guiContainer != null) guiContainer.setVisibility(View.VISIBLE);

            initFloatBall();
            initDynamicIsland();
            initArraylist();
            initNotifications();
            initWatermark();

            if (activity instanceof ModuleToggleListener) {
                ModuleManager.addToggleListener((ModuleToggleListener) activity);
            }
            if (activity instanceof ShortcutToggleListener) {
                ModuleManager.addShortcutListener((ShortcutToggleListener) activity);
            }

            isShowing = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void hide() {
        if (!isShowing) return;
        try {
            if (currentActivity instanceof ModuleToggleListener) {
                ModuleManager.removeToggleListener((ModuleToggleListener) currentActivity);
            }
            if (currentActivity instanceof ShortcutToggleListener) {
                ModuleManager.removeShortcutListener((ShortcutToggleListener) currentActivity);
            }

            if (watermarkView != null) {
                if (watermarkContainer != null) watermarkContainer.removeAllViews();
                if (watermarkContainer != null) watermarkContainer.setVisibility(View.GONE);
                watermarkView = null;
            }

            if (arraylistView != null) {
                arraylistView.clearModules();
                arraylistView.hide();
                arraylistView = null;
            }

            if (dynamicIsland != null) {
                dynamicIsland.hide();
                dynamicIsland = null;
            }

            if (floatBall != null) {
                floatBall.hide();
                floatBall.destroy();
                floatBall = null;
            }

            if (floatBallContainer != null) floatBallContainer.removeAllViews();
            if (menusContainer != null) menusContainer.removeAllViews();
            if (arraylistContainer != null) arraylistContainer.removeAllViews();
            if (notifContainer != null) notifContainer.removeAllViews();

            if (guiContainer != null) guiContainer.setVisibility(View.GONE);

            isShowing = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void bindContainers(Activity activity) {
        guiContainer          = activity.findViewById(R.id.gui_container);
        floatBallContainer    = activity.findViewById(R.id.float_ball_container);
        menusContainer        = activity.findViewById(R.id.menus_container);
        dynamicIslandContainer= activity.findViewById(R.id.dynamic_island_container);
        arraylistContainer    = activity.findViewById(R.id.arraylist_container);
        watermarkContainer    = activity.findViewById(R.id.watermark_container);

        // 动态创建通知容器（覆盖在所有内容之上）
        if (guiContainer != null) {
            notifContainer = new FrameLayout(activity);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
            notifContainer.setElevation(100f); // 最高图层
            guiContainer.addView(notifContainer, lp);
        }
    }

    private static void initFloatBall() {
        try {
            if (floatBall != null) { floatBall.destroy(); floatBall = null; }
            if (floatBallContainer != null) {
                floatBallContainer.removeAllViews();
                floatBall = new FloatBallView(currentActivity, menusContainer);
                floatBallContainer.addView(floatBall);
                floatBall.show();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void initDynamicIsland() {
        if (!ConfigManager.getDynamicIslandEnabled()) return;
        try {
            if (dynamicIsland != null) { dynamicIsland.hide(); dynamicIsland = null; }
            if (dynamicIslandContainer != null) {
                dynamicIslandContainer.removeAllViews();
                dynamicIsland = new DynamicIslandWindow(currentActivity, dynamicIslandContainer);
                dynamicIsland.show();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void initArraylist() {
        try {
            if (arraylistView != null) { arraylistView.clearModules(); arraylistView = null; }
            if (arraylistContainer != null) {
                arraylistContainer.removeAllViews();
                arraylistView = new ArraylistView(currentActivity);
                arraylistContainer.addView(arraylistView, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                arraylistView.show();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void initNotifications() {
        if (notifContainer != null && currentActivity != null) {
            NotificationsModule.init(notifContainer, currentActivity);
        }
    }

    private static void initWatermark() {
        try {
            if (watermarkContainer == null) return;
            watermarkContainer.removeAllViews();
            Module wm = ModuleManager.getModuleByName("Watermark");
            if (wm != null && wm.isEnabled()) showWatermark();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void onModuleToggled(Module module) {
        if (module instanceof WatermarkModule) {
            if (module.isEnabled()) showWatermark();
            else hideWatermark();
        }
    }

    // ===== 水印显示（左上角，带动画）=====
    private static void showWatermark() {
        if (watermarkContainer == null || currentActivity == null) return;
        currentActivity.runOnUiThread(() -> {
            try {
                if (watermarkView == null) {
                    watermarkView = new WatermarkView(currentActivity);
                    FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
                    watermarkContainer.addView(watermarkView, p);
                }
                // 初始位置：左上角
                setWatermarkGravity(true);
                watermarkAtTop = true;

                watermarkContainer.setVisibility(View.VISIBLE);
                watermarkView.setAlpha(0f);
                watermarkView.animate().alpha(1f).setDuration(400)
                        .setInterpolator(new DecelerateInterpolator()).start();

                // 启动左上→左下的循环动画
                startWatermarkAnimation();
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private static void hideWatermark() {
        if (watermarkContainer == null || watermarkView == null) return;
        currentActivity.runOnUiThread(() -> {
            try {
                // 先取出引用，防止 withEndAction 执行时 watermarkView 已被置 null
                final WatermarkView viewToHide = watermarkView;
                final FrameLayout containerRef = watermarkContainer;
                watermarkView = null; // 立刻置 null 防止重复调用
                viewToHide.animate().cancel();
                viewToHide.animate()
                    .alpha(0f)
                    .setDuration(280)
                    .withEndAction(() -> {
                        try {
                            containerRef.removeView(viewToHide);
                            containerRef.setVisibility(View.GONE);
                        } catch (Exception ignored) {}
                    }).start();
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    /**
     * 水印动画：在左上角和左下角之间来回切换
     * 用属性动画 translationY 平滑移动
     */
    private static void startWatermarkAnimation() {
        if (watermarkView == null || watermarkContainer == null) return;

        // 延迟 2 秒后开始第一次移动
        watermarkView.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (watermarkView == null || watermarkContainer == null) return;

                // 计算目标位置
                int containerH = watermarkContainer.getHeight();
                int viewH      = watermarkView.getHeight();

                float fromY = watermarkAtTop ? 0 : (containerH - viewH);
                float toY   = watermarkAtTop ? (containerH - viewH) : 0;

                watermarkView.animate()
                        .translationY(toY - fromY)
                        .setDuration(1200)
                        .setInterpolator(new OvershootInterpolator(0.6f))
                        .withEndAction(() -> {
                            watermarkAtTop = !watermarkAtTop;
                            setWatermarkGravity(watermarkAtTop);
                            watermarkView.setTranslationY(0f);
                            // 停留 3 秒再动
                            if (watermarkView != null) {
                                watermarkView.postDelayed(this, 3000);
                            }
                        })
                        .start();
            }
        }, 2000);
    }

    private static void setWatermarkGravity(boolean top) {
        if (watermarkView == null) return;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) watermarkView.getLayoutParams();
        if (lp == null) return;
        lp.gravity = top ? (Gravity.TOP | Gravity.START) : (Gravity.BOTTOM | Gravity.START);
        watermarkView.setLayoutParams(lp);
    }

    public static void cleanup() {
        hide();
        if (dynamicColorExtractor != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            dynamicColorExtractor.stopListening();
            dynamicColorExtractor = null;
        }
        currentActivity = null;
        initialized = false;
    }

    public static DynamicColorExtractor getDynamicColorExtractor() { return dynamicColorExtractor; }
    public static DynamicIslandWindow getDynamicIsland() { return dynamicIsland; }
    public static ArraylistView getArraylistView() { return arraylistView; }
    public static boolean isShowing() { return isShowing; }

    private UI() {}
}
