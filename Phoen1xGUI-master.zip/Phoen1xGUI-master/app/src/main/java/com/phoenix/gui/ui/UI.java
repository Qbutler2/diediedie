package com.phoenix.gui.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import com.wufan.client.R;
import com.phoenix.gui.config.ConfigManager;
import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.module.ShortcutToggleListener;
import com.phoenix.gui.module.impl.misc.ToggleSoundModule;
import com.phoenix.gui.module.impl.visual.NotificationsModule;
import com.phoenix.gui.module.impl.visual.WatermarkModule;
import com.phoenix.gui.ui.dynamic.DynamicIslandWindow;

public class UI {
    private static DynamicColorExtractor dynamicColorExtractor;
    private static boolean initialized = false;
    private static boolean isShowing   = false;

    private static FloatBallView floatBall;
    private static DynamicIslandWindow dynamicIsland;
    private static ArraylistView arraylistView;

    private static FrameLayout guiContainer;
    private static FrameLayout watermarkContainer;
    private static WatermarkView watermarkView;
    private static FrameLayout floatBallContainer;
    private static FrameLayout menusContainer;
    private static FrameLayout dynamicIslandContainer;
    private static FrameLayout arraylistContainer;
    private static FrameLayout notifContainer;
    private static FrameLayout shortcutsContainer;

    private static Activity currentActivity;
    private static Context serviceContext; // 悬浮窗模式下的 Context

    private static boolean watermarkAtTop = true;

    public static void init(Context ctx) {
        if (initialized) return;
        ConfigManager.init(ctx);
        dynamicColorExtractor = new DynamicColorExtractor(ctx);
        dynamicColorExtractor.init();
        ToggleSoundModule.init(ctx);
        initialized = true;
    }

    public static void show(Activity activity) {
        if (isShowing) return;
        try {
            currentActivity = activity;
            serviceContext  = null;

            guiContainer          = activity.findViewById(R.id.gui_container);
            floatBallContainer    = activity.findViewById(R.id.float_ball_container);
            menusContainer        = activity.findViewById(R.id.menus_container);
            dynamicIslandContainer= activity.findViewById(R.id.dynamic_island_container);
            arraylistContainer    = activity.findViewById(R.id.arraylist_container);
            watermarkContainer    = activity.findViewById(R.id.watermark_container);
            shortcutsContainer    = activity.findViewById(R.id.shortcuts_container);

            if (guiContainer != null) {
                notifContainer = new FrameLayout(activity);
                notifContainer.setElevation(100f);
                guiContainer.addView(notifContainer, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                guiContainer.setVisibility(View.VISIBLE);
            }

            initFloatBall(activity);
            initDynamicIsland(activity);
            initArraylist(activity);
            initNotifications(activity);
            initWatermark();

            isShowing = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 悬浮窗模式入口（由 OverlayService 调用）
     * 不需要 Activity，直接传入各容器引用
     */
    public static void initFromService(Context ctx, FrameLayout root,
                                        FrameLayout islandContainer,
                                        FrameLayout floatBallCont,
                                        FrameLayout menusCont,
                                        FrameLayout watermarkCont,
                                        FrameLayout arraylistCont) {
        if (isShowing) return;
        try {
            serviceContext        = ctx;
            currentActivity       = null;
            guiContainer          = root;
            dynamicIslandContainer= islandContainer;
            floatBallContainer    = floatBallCont;
            menusContainer        = menusCont;
            watermarkContainer    = watermarkCont;
            arraylistContainer    = arraylistCont;
            // Service 模式下也初始化 initialized 标志
            initialized           = true;
            // shortcuts 容器（从 root 里找）
            shortcutsContainer    = root.findViewById(com.wufan.client.R.id.shortcuts_container);

            // 通知容器放在最高层
            notifContainer = new FrameLayout(ctx);
            notifContainer.setElevation(100f);
            root.addView(notifContainer, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));

            if (!initialized) init(ctx);

            initFloatBall(ctx);
            initDynamicIsland(ctx);
            initArraylist(ctx);
            initNotifications(ctx);
            initWatermark();

            isShowing = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void hide() {
        if (!isShowing) return;
        try {
            if (currentActivity instanceof ModuleToggleListener) {
                ModuleManager.removeToggleListener((ModuleToggleListener) currentActivity);
            }
            if (currentActivity instanceof ShortcutToggleListener) {
                ModuleManager.removeShortcutListener((ShortcutToggleListener) currentActivity);
            }

            if (watermarkView != null) {
                if (watermarkContainer != null) watermarkContainer.removeAllViews();
                if (watermarkContainer != null) watermarkContainer.setVisibility(View.GONE);
                watermarkView = null;
            }

            if (arraylistView != null) {
                arraylistView.clearModules();
                arraylistView.hide();
                arraylistView = null;
            }

            if (dynamicIsland != null) {
                dynamicIsland.hide();
                dynamicIsland = null;
            }

            if (floatBall != null) {
                floatBall.hide();
                floatBall.destroy();
                floatBall = null;
            }

            if (floatBallContainer != null) floatBallContainer.removeAllViews();
            if (menusContainer != null) menusContainer.removeAllViews();
            if (arraylistContainer != null) arraylistContainer.removeAllViews();
            if (notifContainer != null) notifContainer.removeAllViews();

            if (guiContainer != null) guiContainer.setVisibility(View.GONE);

            isShowing = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Context resolveContext(Context fallback) {
        if (currentActivity != null) return currentActivity;
        if (serviceContext != null) return serviceContext;
        return fallback;
    }

    private static void initFloatBall(Context ctx) {
        try {
            if (floatBall != null) { floatBall.destroy(); floatBall = null; }
            if (floatBallContainer != null) {
                floatBallContainer.removeAllViews();
                floatBall = new FloatBallView(ctx, menusContainer);
                floatBallContainer.addView(floatBall);
                floatBall.show();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void initDynamicIsland(Context ctx) {
        if (!ConfigManager.getDynamicIslandEnabled()) return;
        try {
            if (dynamicIsland != null) { dynamicIsland.hide(); dynamicIsland = null; }
            if (dynamicIslandContainer != null) {
                dynamicIslandContainer.removeAllViews();
                dynamicIsland = new DynamicIslandWindow(ctx, dynamicIslandContainer);
                dynamicIsland.show();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void initArraylist(Context ctx) {
        try {
            if (arraylistView != null) { arraylistView.clearModules(); arraylistView = null; }
            if (arraylistContainer != null) {
                arraylistContainer.removeAllViews();
                arraylistView = new ArraylistView(ctx);
                arraylistContainer.addView(arraylistView, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                arraylistView.show();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void initNotifications(Context ctx) {
        if (notifContainer != null) {
            NotificationsModule.init(notifContainer, ctx);
        }
    }

    private static void initWatermark() {
        try {
            if (watermarkContainer == null) return;
            watermarkContainer.removeAllViews();
            Module wm = ModuleManager.getModuleByName("Watermark");
            if (wm != null && wm.isEnabled()) showWatermark();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void onModuleToggled(Module module) {
        if (module instanceof WatermarkModule) {
            if (module.isEnabled()) showWatermark();
            else hideWatermark();
        }
    }

    private static void showWatermark() {
        if (watermarkContainer == null) return;
        Context ctx = currentActivity != null ? currentActivity : serviceContext;
        if (ctx == null) return;

        Runnable run = () -> {
            try {
                if (watermarkView == null) {
                    watermarkView = new WatermarkView(ctx);
                    FrameLayout.LayoutParams wlp = new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
                    wlp.gravity = Gravity.TOP | Gravity.START;
                    watermarkContainer.addView(watermarkView, wlp);
                }
                watermarkContainer.setVisibility(View.VISIBLE);
                watermarkView.setAlpha(0f);
                watermarkView.setTranslationY(0f);
                watermarkView.animate().alpha(1f).setDuration(400)
                        .setInterpolator(new DecelerateInterpolator()).start();
                startWatermarkAnimation();
            } catch (Exception e) { e.printStackTrace(); }
        };

        if (currentActivity != null) currentActivity.runOnUiThread(run);
        else watermarkContainer.post(run);
    }

    private static void hideWatermark() {
        if (watermarkContainer == null || watermarkView == null) return;
        final WatermarkView viewToHide    = watermarkView;
        final FrameLayout   containerRef  = watermarkContainer;
        watermarkView = null; // 立即置 null，防止动画回调里二次访问
        Runnable run = () -> {
            try {
                viewToHide.animate().cancel(); // 先取消所有动画（防止 withEndAction 互相竞争）
                viewToHide.animate()
                    .alpha(0f)
                    .setDuration(280)
                    .withEndAction(() -> {
                        try {
                            containerRef.removeView(viewToHide);
                            containerRef.setVisibility(View.GONE);
                        } catch (Exception ignored) {}
                    }).start();
            } catch (Exception e) { e.printStackTrace(); }
        };
        if (currentActivity != null) currentActivity.runOnUiThread(run);
        else containerRef.post(run);
    }

    private static void startWatermarkAnimation() {
        if (watermarkView == null || watermarkContainer == null) return;
        watermarkView.postDelayed(new Runnable() {
            @Override
            public void run() {
                // 安全检查，防止关闭时崩溃
                final WatermarkView view = watermarkView;
                final FrameLayout container = watermarkContainer;
                if (view == null || container == null) return;

                int containerH = container.getHeight();
                int viewH      = view.getHeight();
                if (containerH <= 0 || viewH <= 0) {
                    // 容器还没测量完，延迟重试
                    view.postDelayed(this, 500);
                    return;
                }

                // 目标 Y：顶部=0，底部=containerH-viewH
                float targetY = watermarkAtTop ? (containerH - viewH) : 0f;
                watermarkAtTop = !watermarkAtTop;

                view.animate()
                    .translationY(targetY)
                    .setDuration(1200)
                    .setInterpolator(new OvershootInterpolator(0.5f))
                    .withEndAction(() -> {
                        if (watermarkView != null) {
                            watermarkView.postDelayed(this, 3000);
                        }
                    }).start();
            }
        }, 2000);
    }

    public static void cleanup() {
        hide();
        if (dynamicColorExtractor != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            dynamicColorExtractor.stopListening();
            dynamicColorExtractor = null;
        }
        currentActivity = null;
        serviceContext  = null;
        initialized     = false;
    }

    public static Context getContext() {
        if (currentActivity != null) return currentActivity;
        return serviceContext;
    }
    public static DynamicColorExtractor getDynamicColorExtractor() { return dynamicColorExtractor; }
    public static DynamicIslandWindow getDynamicIsland()           { return dynamicIsland; }
    public static ArraylistView getArraylistView()                 { return arraylistView; }
    public static FrameLayout getShortcutsContainer()              { return shortcutsContainer; }
    public static FrameLayout getArraylistContainer()              { return arraylistContainer; }
    public static boolean isShowing()                             { return isShowing; }

    private UI() {}
}
