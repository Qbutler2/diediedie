package com.phoenix.gui.module.impl.gui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.dynamic.DynamicIslandWindow;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

/** DynamicIsland: WRAP_CONTENT 顶部居中，NOT_TOUCHABLE */
public class DynamicIslandModule extends Module {
    private WindowManager wm;
    private FrameLayout container;
    private DynamicIslandWindow island;

    public DynamicIslandModule() { super("DynamicIsland", ModuleCategory.VISUAL, "Dynamic Island widget"); }
    @Override protected void onEnable()  { show(); }
    @Override protected void onDisable() { hide(); }

    private void show() {
        Context ctx = UI.getContext();
        if (ctx == null) return;
        wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        float dp = ctx.getResources().getDisplayMetrics().density;

        // WRAP_CONTENT 宽高，顶部水平居中
        WindowManager.LayoutParams wlp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        wlp.y = (int)(8 * dp); // 状态栏下方 8dp

        container = new FrameLayout(ctx);
        try {
            wm.addView(container, wlp);
            island = new DynamicIslandWindow(ctx, container);
            island.show();
            UI.setDynamicIsland(island);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void hide() {
        UI.setDynamicIsland(null);
        if (island != null) { island.hide(); island = null; }
        if (container != null) { try { wm.removeView(container); } catch (Exception ignored) {} container = null; }
        wm = null;
    }
}
