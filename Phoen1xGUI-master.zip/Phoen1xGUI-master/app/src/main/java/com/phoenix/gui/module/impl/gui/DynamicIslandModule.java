package com.phoenix.gui.module.impl.gui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.dynamic.DynamicIslandWindow;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

public class DynamicIslandModule extends Module {

    private WindowManager wm;
    private FrameLayout container;
    private DynamicIslandWindow islandWindow;

    public DynamicIslandModule() {
        super("DynamicIsland", ModuleCategory.VISUAL, "Dynamic Island status bar widget");
    }

    @Override protected void onEnable()  { show(); }
    @Override protected void onDisable() { hide(); }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addText("Shows Wufan Client info in a Dynamic Island widget.");
    }

    private void show() {
        Context ctx = UI.getContext();
        if (ctx == null) return;
        wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        float dp = ctx.getResources().getDisplayMetrics().density;

        WindowManager.LayoutParams wlp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.START;
        wlp.y = (int)(24 * dp);

        container = new FrameLayout(ctx);
        try {
            wm.addView(container, wlp);
            islandWindow = new DynamicIslandWindow(ctx, container);
            islandWindow.show();
            UI.setDynamicIsland(islandWindow);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void hide() {
        UI.setDynamicIsland(null);
        if (islandWindow != null) { islandWindow.hide(); islandWindow = null; }
        if (container != null && wm != null) {
            try { wm.removeView(container); } catch (Exception ignored) {}
            container = null;
        }
        wm = null;
    }
}
