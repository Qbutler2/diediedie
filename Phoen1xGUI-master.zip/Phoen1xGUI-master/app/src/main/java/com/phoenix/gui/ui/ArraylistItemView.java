package com.phoenix.gui.ui;

import android.content.Context;
import android.graphics.*;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;

/**
 * Solstice 风格 Arraylist 单项：
 * - 右对齐文字
 * - 右侧主题色竖条（Bar）
 * - 文字带阴影
 * - 无背景框（透明）
 */
public class ArraylistItemView extends FrameLayout implements ThemeManager.OnThemeColorChangeListener {

    public enum PositionType { SINGLE, FIRST, MIDDLE, LAST }

    private TextView textView;
    private Paint barPaint;
    private Paint shadowPaint;
    private float measuredTextWidth = 0f;
    private int customTextColor = -1;
    private PositionType positionType = PositionType.MIDDLE;

    // 每个 item 自己的色调偏移（由 ArraylistView 设置，基于 Y 位置）
    private float colorHueOffset = 0f;

    public ArraylistItemView(Context context) { super(context); init(); }
    public ArraylistItemView(Context context, AttributeSet a) { super(context, a); init(); }
    public ArraylistItemView(Context context, AttributeSet a, int d) { super(context, a, d); init(); }

    private void init() {
        setWillNotDraw(false);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setClipChildren(false);
        setClipToPadding(false);

        int pad = dpToPx(8);
        setPadding(0, dpToPx(1), dpToPx(6) + dpToPx(4), dpToPx(1));

        textView = new TextView(getContext());
        textView.setTextColor(ThemeManager.getThemeColor());
        textView.setTextSize(10.5f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        textView.setPadding(dpToPx(6), dpToPx(3), dpToPx(10), dpToPx(3));
        // 文字阴影（Solstice 用细黑阴影）
        textView.setShadowLayer(dpToPx(1f), dpToPx(0.8f), dpToPx(0.8f), 0xBB000000);

        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        p.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        addView(textView, p);

        // 右侧竖条（Bar 模式，Solstice 风格）
        barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        barPaint.setStyle(Paint.Style.FILL);

        ThemeManager.addListener(this);
    }

    public void setColorHueOffset(float offset) {
        colorHueOffset = offset;
        updateColors();
    }

    private void updateColors() {
        int base = ThemeManager.getThemeColor();
        int color = shiftHue(base, colorHueOffset);
        if (customTextColor == -1) textView.setTextColor(color);
        barPaint.setColor(color);
        invalidate();
    }

    /**
     * 根据 Y 位置产生微微色相偏移，模拟 Solstice 的 getThemedColor(y*2)
     */
    private int shiftHue(int color, float shift) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[0] = (hsv[0] + shift) % 360f;
        if (hsv[0] < 0) hsv[0] += 360f;
        return Color.HSVToColor(Color.alpha(color), hsv);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        // 右侧竖条（Solstice Bar 模式）
        int base = ThemeManager.getThemeColor();
        int barColor = shiftHue(base, colorHueOffset);
        barPaint.setColor(barColor);
        // 发光
        barPaint.setMaskFilter(new BlurMaskFilter(dpToPx(3f), BlurMaskFilter.Blur.NORMAL));
        float barW = dpToPx(3.5f);
        float barX = w - dpToPx(2f);
        float barTop    = dpToPx(3f);
        float barBottom = h - dpToPx(3f);
        RectF barRect = new RectF(barX - barW, barTop, barX, barBottom);
        canvas.drawRoundRect(barRect, dpToPx(1.5f), dpToPx(1.5f), barPaint);
    }

    @Override
    public void onThemeColorChanged(int newColor) {
        updateColors();
    }

    public void cleanup() {
        ThemeManager.removeListener(this);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ThemeManager.addListener(this);
        updateColors();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ThemeManager.removeListener(this);
    }

    public void setPositionType(PositionType type) {
        if (this.positionType != type) { this.positionType = type; invalidate(); }
    }

    public void setText(String text) {
        textView.setText(text);
        TextPaint paint = textView.getPaint();
        measuredTextWidth = paint.measureText(text)
                + textView.getPaddingLeft() + textView.getPaddingRight();
    }

    public float getMeasuredTextWidth() { return measuredTextWidth; }

    public void setTextColor(int color) {
        customTextColor = color;
        textView.setTextColor(color);
    }

    public void setGlowEnabled(boolean enabled) {
        if (enabled) {
            textView.getPaint().setMaskFilter(
                    new BlurMaskFilter(dpToPx(5f), BlurMaskFilter.Blur.NORMAL));
        } else {
            textView.getPaint().setMaskFilter(null);
        }
        textView.invalidate();
    }

    private int dpToPx(float dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}
