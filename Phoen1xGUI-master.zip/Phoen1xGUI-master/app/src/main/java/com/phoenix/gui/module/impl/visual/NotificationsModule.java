package com.phoenix.gui.module.impl.visual;

import android.content.Context;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.ui.ThemeManager;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

import java.util.ArrayList;
import java.util.List;

public class NotificationsModule extends Module implements ModuleToggleListener {

    public enum Type { INFO, SUCCESS, WARNING }

    private static boolean showOnToggle = true;
    private static boolean colorGradient = false;
    private static boolean limitNotifs = false;
    private static int maxNotifs = 6;

    // ── 单条通知 ──
    public static class Notification {
        public final String message;
        public final Type type;
        public final long duration;
        public long startTime;
        public NotificationView view;

        public Notification(String msg, Type type, long duration) {
            this.message   = msg;
            this.type      = type;
            this.duration  = duration;
            this.startTime = System.currentTimeMillis();
        }

        public float getProgress() {
            return 1f - Math.min(1f, (float)(System.currentTimeMillis() - startTime) / duration);
        }
    }

    // ── 通知 View（小尺寸，Solstice 风格）──
    public static class NotificationView extends View {
        // 更小的尺寸
        static final int H_DP = 36;
        static final int W_DP = 190;
        private static final int R_DP  = 5;
        private static final float BAR_H_DP = 2.5f;

        final Notification notif;
        private final Paint bgPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barBgPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF bgRect  = new RectF();
        private final RectF barRect = new RectF();
        private final RectF barBgR  = new RectF();
        private final RectF accRect = new RectF();

        public NotificationView(Context ctx, Notification n) {
            super(ctx);
            this.notif = n;
            setLayerType(LAYER_TYPE_SOFTWARE, null);

            bgPaint.setColor(0xED0D1111);

            int color = typeColor();
            barPaint.setColor(color);
            accentPaint.setColor(color);
            barBgPaint.setColor(0x15FFFFFF);

            // 统一用一个 paint，图标+消息一行显示
            textPaint.setTextSize(dp(10.5f));
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textPaint.setColor(0xFFEEEEEE);
            textPaint.setAntiAlias(true);
            textPaint.setShadowLayer(dp(1f), dp(0.7f), dp(0.7f), 0xAA000000);

            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(dp(0.7f));
            borderPaint.setColor(0x20FFFFFF);
        }

        private int typeColor() {
            switch (notif.type) {
                case SUCCESS: return ThemeManager.COLOR_SUCCESS;
                case WARNING: return ThemeManager.COLOR_WARNING;
                default:      return ThemeManager.getThemeColor();
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w   = getWidth();
            float h   = getHeight();
            float r   = dp(R_DP);
            float barH= dp(BAR_H_DP);
            float accW= dp(2.5f);
            float progress = notif.getProgress();

            // 背景
            bgRect.set(0, 0, w, h - barH);
            canvas.drawRoundRect(bgRect, r, r, bgPaint);

            // 右侧暗化（进度条区域，Solstice 风格）
            RectF darkR = new RectF(w * progress, 0, w, h - barH);
            canvas.save();
            Path clip = new Path();
            clip.addRoundRect(bgRect, r, r, Path.Direction.CW);
            canvas.clipPath(clip);
            canvas.drawRect(darkR, barBgPaint);
            canvas.restore();

            // 边框
            canvas.drawRoundRect(bgRect, r, r, borderPaint);

            // 左侧 accent 条
            accentPaint.setColor(typeColor());
            accRect.set(0, dp(4f), accW, h - barH - dp(4f));
            canvas.drawRoundRect(accRect, accW / 2, accW / 2, accentPaint);

            // 图标 + 消息（一行）
            String icon;
            switch (notif.type) {
                case SUCCESS: icon = "✓ "; break;
                case WARNING: icon = "⚠ "; break;
                default:      icon = "● "; break;
            }
            // 图标用主题色
            Paint iconPaint = new Paint(textPaint);
            iconPaint.setColor(typeColor());
            float cy = (h - barH) / 2f + dp(4f);
            canvas.drawText(icon, dp(8f), cy, iconPaint);
            float iconW = iconPaint.measureText(icon);

            // 消息截断
            float maxW = w - dp(10f) - iconW;
            String msg = notif.message;
            while (msg.length() > 1 && textPaint.measureText(msg) > maxW) {
                msg = msg.substring(0, msg.length() - 1);
            }
            if (!msg.equals(notif.message)) msg += "…";
            canvas.drawText(msg, dp(8f) + iconW, cy, textPaint);

            // 底部进度条
            barBgR.set(0, h - barH, w, h);
            canvas.drawRect(barBgR, barBgPaint);

            if (colorGradient) {
                LinearGradient grad = new LinearGradient(0, 0, w * progress, 0,
                        typeColor(), ThemeManager.getGradientEnd(), Shader.TileMode.CLAMP);
                barPaint.setShader(grad);
            } else {
                barPaint.setShader(null);
                barPaint.setColor(typeColor());
            }
            barRect.set(0, h - barH, w * progress, h);
            canvas.drawRect(barRect, barPaint);

            invalidate();
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension((int) dp(W_DP), (int) dp(H_DP));
        }

        private float dp(float v) {
            return v * getResources().getDisplayMetrics().density;
        }
    }

    // ── 静态管理器 ──
    private static final List<Notification> active = new ArrayList<>();
    private static FrameLayout container;
    private static Context ctx;
    private static final Handler handler = new Handler(Looper.getMainLooper());

    public static void init(FrameLayout notifContainer, Context context) {
        container = notifContainer;
        ctx       = context.getApplicationContext();
    }

    public static void notify(String message, Type type, long durationMs) {
        handler.post(() -> {
            if (container == null || ctx == null) return;
            if (limitNotifs && active.size() >= maxNotifs) return;

            Notification n = new Notification(message, type, durationMs);
            NotificationView view = new NotificationView(ctx, n);
            n.view = view;

            float density = ctx.getResources().getDisplayMetrics().density;
            int hPx   = (int)(NotificationView.H_DP * density);
            int wPx   = (int)(NotificationView.W_DP * density);
            int margin= (int)(8 * density);

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(wPx, hPx);
            lp.gravity      = Gravity.BOTTOM | Gravity.END;
            lp.bottomMargin = margin + active.size() * (hPx + margin);
            lp.rightMargin  = margin;
            container.addView(view, lp);
            active.add(n);

            // 从右侧滑入
            view.setTranslationX(wPx + margin * 2);
            view.animate()
                    .translationX(0f)
                    .setDuration(320)
                    .setInterpolator(new OvershootInterpolator(0.5f))
                    .start();

            handler.postDelayed(() -> dismiss(n), durationMs);
        });
    }

    private static void dismiss(Notification n) {
        if (n.view == null) return;
        NotificationView view = n.view;
        view.animate()
                .translationX(view.getWidth() + 16)
                .alpha(0f)
                .setDuration(280)
                .setInterpolator(new DecelerateInterpolator(1.5f))
                .withEndAction(() -> {
                    if (container != null) container.removeView(view);
                    active.remove(n);
                    reshufflePositions();
                }).start();
    }

    private static void reshufflePositions() {
        if (ctx == null) return;
        float density = ctx.getResources().getDisplayMetrics().density;
        int hPx   = (int)(NotificationView.H_DP * density);
        int margin= (int)(8 * density);
        for (int i = 0; i < active.size(); i++) {
            Notification n = active.get(i);
            if (n.view == null) continue;
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) n.view.getLayoutParams();
            lp.bottomMargin = margin + i * (hPx + margin);
            n.view.setLayoutParams(lp);
        }
    }

    // ── Module ──
    public NotificationsModule() {
        super("Notifications", ModuleCategory.VISUAL, "Solstice-style notifications");
    }

    @Override public void onEnable() {
        ModuleManager.addToggleListener(this);
        notify("Notifications enabled", Type.SUCCESS, 2000);
    }

    @Override public void onDisable() {
        ModuleManager.removeToggleListener(this);
    }

    @Override public void onModuleToggled(Module module) {
        if (!showOnToggle || module == this) return;
        notify(module.getName() + (module.isEnabled() ? " enabled" : " disabled"),
                module.isEnabled() ? Type.SUCCESS : Type.INFO, 2500);
    }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSwitch("Show on toggle", showOnToggle, v -> showOnToggle = v);
        subMenu.addSwitch("Color gradient",  colorGradient, v -> colorGradient = v);
        subMenu.addSwitch("Limit count",     limitNotifs,   v -> limitNotifs = v);
        subMenu.addSlider("Max", 1, 20, maxNotifs, "%d", v -> maxNotifs = v);
    }
}
