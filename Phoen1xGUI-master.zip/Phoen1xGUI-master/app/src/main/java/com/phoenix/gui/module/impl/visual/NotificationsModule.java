package com.phoenix.gui.module.impl.visual;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.ui.GaussianBlurHelper;
import com.phoenix.gui.ui.ThemeManager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * NotificationsModule (Visual) - 完整仿照 Prax Notifications 实现
 *
 * Prax 风格：
 *  - 右侧从屏幕外滑入（lerp endX → beginX）
 *  - 黑色半透明背景 + 圆角
 *  - 顶部彩色进度条（从满到空）
 *  - Info/Warning/Error/Enable/Disable 五种类型颜色
 *  - 下方从上往上堆叠（yOff lerp）
 *  - 持续时间默认 2.5 秒
 */
public class NotificationsModule extends Module implements ModuleToggleListener {

    // ===== 通知类型（完整对应 Prax NotificationType）=====
    public enum Type {
        INFO,    // 白色
        WARNING, // 黄色
        ERROR,   // 红色
        ENABLE,  // 绿色
        DISABLE  // 红色
    }

    // ===== 单条通知数据（对应 Prax struct Notification）=====
    public static class Notification {
        public final String title;
        public final String message;
        public final Type type;
        public final long durationMs;
        public long startTime;
        public float currentDuration = 0f; // 0~1，lerp动画进度（对应 Prax CurrentDuration）
        public boolean isTimeUp = false;
        public NotifView view;

        public Notification(String title, String message, Type type, long durationMs) {
            this.title     = title;
            this.message   = message;
            this.type      = type;
            this.durationMs= durationMs;
            this.startTime = System.currentTimeMillis();
        }

        /** 已过时间占比 0~1（对应 Prax percentDone）*/
        public float percentDone() {
            return Math.min(1f, (float)(System.currentTimeMillis() - startTime) / durationMs);
        }

        /** 完全消失后可以移除（对应 Prax isTimeUp && TimeShown > Duration + 10）*/
        public boolean canRemove() {
            return System.currentTimeMillis() - startTime > durationMs + 800;
        }
    }

    // ===== 通知 View（对应 Prax case 1: Aether 风格）=====
    public static class NotifView extends View {

        // 尺寸（仿照 Prax boxSize = ImVec2(fmax(200, 50+textWidth), 50)）
        private static final int BOX_W_DP      = 260;
        private static final int BOX_H_DP      = 52;
        private static final int CORNER_DP     = 6;
        private static final int PROGRESS_H_DP = 3;
        private static final int ICON_W_DP     = 32;

        final Notification notif;

        private final Paint bgPaint      = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint progressPaint= new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint progressBgP  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint titlePaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint msgPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint iconPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint borderPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint blurOverlay  = new Paint(Paint.ANTI_ALIAS_FLAG);

        // 模糊背景
        private Bitmap blurBitmap;
        private long lastBlurTime = 0;
        private static final long BLUR_INTERVAL = 200; // ms

        public NotifView(Context ctx, Notification n) {
            super(ctx);
            this.notif = n;
            setLayerType(LAYER_TYPE_SOFTWARE, null);

            bgPaint.setColor(0xD0000000); // 对应 Prax ImColor(0,0,0,200)

            int color = typeColor();
            progressPaint.setColor(color);
            progressBgP.setColor(0x22FFFFFF);

            titlePaint.setTextSize(dp(14));
            titlePaint.setTypeface(Typeface.DEFAULT_BOLD);
            titlePaint.setColor(0xFFFFFFFF);
            titlePaint.setAntiAlias(true);

            msgPaint.setTextSize(dp(12));
            msgPaint.setColor(0xFFDDDDDD);
            msgPaint.setAntiAlias(true);

            iconPaint.setTextSize(dp(18));
            iconPaint.setColor(color);
            iconPaint.setTypeface(Typeface.DEFAULT_BOLD);
            iconPaint.setAntiAlias(true);

            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(1f);
            borderPaint.setColor(0x30FFFFFF);

            blurOverlay.setAlpha(180);
        }

        private int typeColor() {
            switch (notif.type) {
                case WARNING: return 0xFFE0DD31; // Prax: ImColor(224,221,49)
                case ERROR:   return 0xFFFF3246; // Prax: ImColor(255,50,70)
                case ENABLE:  return 0xFF3CFF32; // Prax: ImColor(60,255,50)
                case DISABLE: return 0xFFFF3246;
                default:      return 0xFFFFFFFF; // Info: 白色
            }
        }

        private String typeIcon() {
            switch (notif.type) {
                case WARNING: return "⚑";
                case ERROR:   return "⚑";
                case ENABLE:  return "✓";
                case DISABLE: return "✗";
                default:      return "ℹ";
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w    = getWidth();
            float h    = getHeight();
            float r    = dp(CORNER_DP);
            float barH = dp(PROGRESS_H_DP);
            float iconW= dp(ICON_W_DP);

            RectF bgRect = new RectF(0, 0, w, h - barH);

            // ── 1. 高斯模糊背景（仿照 Prax D2D AddBlur）──
            long now = System.currentTimeMillis();
            if (now - lastBlurTime > BLUR_INTERVAL) {
                Bitmap newBlur = GaussianBlurHelper.blur(this);
                if (newBlur != null) {
                    if (blurBitmap != null && !blurBitmap.isRecycled()) blurBitmap.recycle();
                    blurBitmap = newBlur;
                }
                lastBlurTime = now;
            }

            if (blurBitmap != null && !blurBitmap.isRecycled()) {
                canvas.save();
                Path clip = new Path();
                clip.addRoundRect(bgRect, r, r, Path.Direction.CW);
                canvas.clipPath(clip);
                GaussianBlurHelper.drawBlur(blurBitmap, canvas, bgRect, 255);
                canvas.restore();
            }

            // ── 2. 半透明黑色叠加（对应 Prax AddRectFilled ImColor(0,0,0,200)）──
            canvas.drawRoundRect(bgRect, r, r, bgPaint);

            // ── 3. 边框 ──
            canvas.drawRoundRect(bgRect, r, r, borderPaint);

            // ── 4. 图标（对应 Prax DRAW_LIST AddText icons）──
            String icon = typeIcon();
            float iconX = dp(10);
            float iconY = (h - barH) / 2f + dp(6);
            canvas.drawText(icon, iconX, iconY, iconPaint);

            // ── 5. 标题（对应 Prax greycliff_bold AddText Title）──
            float textX = iconX + iconW;
            float maxTextW = w - textX - dp(8);

            // 消息合并（对应 Prax: message.contains(title) ? message : title+" - "+message）
            String combined = notif.message.contains(notif.title)
                    ? notif.message
                    : notif.title + " — " + notif.message;

            // 截断过长文字（对应 Prax wrapWidth boxSize.x-20）
            while (combined.length() > 0 && msgPaint.measureText(combined) > maxTextW) {
                combined = combined.substring(0, combined.length() - 1);
            }
            if (!combined.equals(
                    notif.message.contains(notif.title) ? notif.message : notif.title + " — " + notif.message)) {
                combined += "…";
            }

            canvas.drawText(combined, textX, iconY, msgPaint);

            // ── 6. 进度条背景 ──
            RectF barBgRect = new RectF(0, h - barH, w, h);
            canvas.drawRect(barBgRect, progressBgP);

            // ── 7. 进度条（对应 Prax percentDone * boxSize.x，从满到空）──
            float prog = 1f - notif.percentDone(); // 反向：从满→空
            RectF barRect = new RectF(0, h - barH, w * prog, h);
            canvas.drawRect(barRect, progressPaint);

            invalidate(); // 持续重绘进度条动画
        }

        @Override
        protected void onMeasure(int ws, int hs) {
            setMeasuredDimension((int) dp(BOX_W_DP), (int) dp(BOX_H_DP + PROGRESS_H_DP));
        }

        private float dp(float v) {
            return v * getResources().getDisplayMetrics().density;
        }
    }

    // ===== 静态通知管理器（对应 Prax Notifications::List + Render）=====

    private static final List<Notification> list = new ArrayList<>();
    private static FrameLayout container;
    private static Context appCtx;
    private static final Handler handler = new Handler(Looper.getMainLooper());

    // 更新计时器（对应 Prax Render 里每帧执行）
    private static final Runnable updateRunnable = new Runnable() {
        @Override
        public void run() {
            updateNotifications();
            handler.postDelayed(this, 16); // ~60fps
        }
    };

    public static void init(FrameLayout notifContainer, Context ctx) {
        container = notifContainer;
        appCtx = ctx.getApplicationContext();
        GaussianBlurHelper.init(appCtx);
        handler.post(updateRunnable);
    }

    /**
     * 发送通知（对应 Prax Notifications::Notify）
     */
    public static void notify(String title, String message, Type type, long durationMs) {
        handler.post(() -> {
            if (container == null || appCtx == null) return;

            Notification n = new Notification(title, message, type, durationMs);
            NotifView view = new NotifView(appCtx, n);
            n.view = view;

            float density = appCtx.getResources().getDisplayMetrics().density;
            int hPx = (int)((NotifView.BOX_H_DP + NotifView.PROGRESS_H_DP) * density);
            int wPx = (int)(NotifView.BOX_W_DP * density);
            int margin = (int)(8 * density);

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(wPx, hPx);
            lp.gravity = Gravity.BOTTOM | Gravity.END;
            lp.rightMargin  = margin;
            lp.bottomMargin = margin + list.size() * (hPx + margin);

            container.addView(view, lp);
            list.add(n);

            // 从右侧滑入（对应 Prax x = Lerp(endX, beginX, currentDuration)）
            view.setTranslationX(wPx + margin * 2);
            view.animate()
                    .translationX(0f)
                    .setDuration(350)
                    .setInterpolator(new OvershootInterpolator(0.6f))
                    .start();
        });
    }

    /**
     * 便捷方法
     */
    public static void notify(String message, Type type) {
        notify(message, message, type, 2500);
    }

    /**
     * 更新所有通知状态（对应 Prax Render 里的 for loop）
     */
    private static void updateNotifications() {
        if (container == null) return;

        // 移除已彻底结束的通知（对应 Prax: isTimeUp && TimeShown > Duration+10）
        Iterator<Notification> it = list.iterator();
        while (it.hasNext()) {
            Notification n = it.next();
            if (n.canRemove()) {
                if (n.view != null && container != null) {
                    container.removeView(n.view);
                }
                it.remove();
            }
        }

        // 更新 currentDuration（对应 Prax Lerp(currentDuration, isTimeUp?0:1, SPEED*delta)）
        long now = System.currentTimeMillis();
        for (Notification n : list) {
            boolean isTimeUp = now - n.startTime >= n.durationMs;
            n.isTimeUp = isTimeUp;
            float target = isTimeUp ? 0f : 1f;
            n.currentDuration += (target - n.currentDuration) * 0.08f; // lerp

            // 当 isTimeUp 且动画接近 0，触发滑出
            if (isTimeUp && n.currentDuration < 0.05f && n.view != null && n.view.getTranslationX() == 0f) {
                slidOut(n);
            }
        }

        // 重新排列位置（从下往上堆叠）
        repositionAll();
    }

    private static void slidOut(Notification n) {
        if (n.view == null) return;
        float wPx = n.view.getWidth();
        float margin = 16f;
        n.view.animate()
                .translationX(wPx + margin)
                .alpha(0f)
                .setDuration(300)
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }

    private static void repositionAll() {
        if (appCtx == null) return;
        float density = appCtx.getResources().getDisplayMetrics().density;
        int hPx   = (int)((NotifView.BOX_H_DP + NotifView.PROGRESS_H_DP) * density);
        int margin= (int)(8 * density);

        int idx = 0;
        for (Notification n : list) {
            if (n.view == null) continue;
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) n.view.getLayoutParams();
            if (lp == null) continue;
            int target = margin + idx * (hPx + margin);
            if (lp.bottomMargin != target) {
                lp.bottomMargin = target;
                n.view.setLayoutParams(lp);
            }
            idx++;
        }
    }

    // ===== Module 实现 =====

    public NotificationsModule() {
        super("Notifications", ModuleCategory.VISUAL,
                "Show notifications on module toggle (Prax style)");
    }

    @Override
    public void onEnable() {
        ModuleManager.addToggleListener(this);
        notify("Notifications", "Enabled", Type.ENABLE, 2500);
    }

    @Override
    public void onDisable() {
        ModuleManager.removeToggleListener(this);
    }

    @Override
    public void onModuleToggled(Module module) {
        if (module == this) return;
        Type type = module.isEnabled() ? Type.ENABLE : Type.DISABLE;
        notify(module.getName(),
               module.isEnabled() ? "Enabled" : "Disabled",
               type, 2500);
    }
}
