package com.phoenix.gui.module.impl.visual;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.ui.ThemeManager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * NotificationsModule (Visual) - 仿 Solstice 风格通知
 *
 * 右下角滑入通知条，带进度条，模块开关时自动触发。
 * NotificationsModule.init(container) 在 UI.show() 里调用。
 */
public class NotificationsModule extends Module implements ModuleToggleListener {

    public enum Type { INFO, SUCCESS, WARNING }

    // ===== 单条通知 =====
    public static class Notification {
        public final String message;
        public final Type type;
        public final long duration;
        public long startTime;
        public NotificationView view;

        public Notification(String msg, Type type, long duration) {
            this.message   = msg;
            this.type      = type;
            this.duration  = duration;
            this.startTime = System.currentTimeMillis();
        }

        public float getProgress() {
            return 1f - Math.min(1f, (float)(System.currentTimeMillis() - startTime) / duration);
        }

        public boolean isExpired() {
            return System.currentTimeMillis() - startTime > duration + 500;
        }
    }

    // ===== 通知 View =====
    public static class NotificationView extends View {
        private static final int H_DP  = 48;
        private static final int W_DP  = 220;
        private static final int R_DP  = 8;
        private static final int BAR_H = 3;

        final Notification notif;
        private final Paint bgPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barBgPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint msgPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF bgRect   = new RectF();
        private final RectF barRect  = new RectF();
        private final RectF barBgR   = new RectF();
        private final RectF accRect  = new RectF();

        public NotificationView(Context ctx, Notification n) {
            super(ctx);
            this.notif = n;
            setLayerType(LAYER_TYPE_SOFTWARE, null);

            bgPaint.setColor(0xF0111414);

            int color = typeColor();
            barPaint.setColor(color);
            accentPaint.setColor(color);
            barBgPaint.setColor(0x22FFFFFF);

            labelPaint.setTextSize(dp(13));
            labelPaint.setTypeface(Typeface.DEFAULT_BOLD);
            labelPaint.setColor(color);
            labelPaint.setAntiAlias(true);

            msgPaint.setTextSize(dp(12));
            msgPaint.setColor(0xFFEEEEEE);
            msgPaint.setAntiAlias(true);

            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(1f);
            borderPaint.setColor(0x22FFFFFF);
        }

        private int typeColor() {
            switch (notif.type) {
                case SUCCESS: return ThemeManager.COLOR_SUCCESS;
                case WARNING: return ThemeManager.COLOR_WARNING;
                default:      return ThemeManager.COLOR_INFO;
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight();
            float r   = dp(R_DP);
            float barH= dp(BAR_H);
            float accW= dp(3);

            // 背景
            bgRect.set(0, 0, w, h - barH);
            canvas.drawRoundRect(bgRect, r, r, bgPaint);
            canvas.drawRoundRect(bgRect, r, r, borderPaint);

            // 左侧 accent 条
            accRect.set(0, dp(8), accW, h - barH - dp(8));
            canvas.drawRoundRect(accRect, accW/2, accW/2, accentPaint);

            // 类型图标
            String icon;
            switch (notif.type) {
                case SUCCESS: icon = "✓ "; break;
                case WARNING: icon = "⚠ "; break;
                default:      icon = "ℹ "; break;
            }
            float cy = h / 2 - barH / 2 + dp(5);
            canvas.drawText(icon, dp(10), cy, labelPaint);

            // 消息文字（截断过长部分）
            float labelW = labelPaint.measureText(icon);
            float maxMsgW = w - dp(14) - labelW;
            String msg = notif.message;
            while (msg.length() > 0 && msgPaint.measureText(msg) > maxMsgW) {
                msg = msg.substring(0, msg.length() - 1);
            }
            if (!msg.equals(notif.message)) msg += "…";
            canvas.drawText(msg, dp(10) + labelW, cy, msgPaint);

            // 进度条背景
            barBgR.set(0, h - barH, w, h);
            canvas.drawRect(barBgR, barBgPaint);

            // 进度条（Solstice 风格：从右向左消耗）
            float progress = notif.getProgress();
            barRect.set(0, h - barH, w * progress, h);
            canvas.drawRect(barRect, barPaint);

            invalidate(); // 持续重绘进度条
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension((int)dp(W_DP), (int)dp(H_DP));
        }

        private float dp(float v) {
            return v * getResources().getDisplayMetrics().density;
        }
    }

    // ===== 静态管理器 =====

    private static final List<Notification> active = new ArrayList<>();
    private static FrameLayout container;
    private static Context ctx;
    private static final Handler handler = new Handler(Looper.getMainLooper());

    /** UI.show() 里调用 */
    public static void init(FrameLayout notifContainer, Context context) {
        container = notifContainer;
        ctx = context.getApplicationContext();
    }

    /** 发送通知（任何地方都可以调用）*/
    public static void notify(String message, Type type, long durationMs) {
        handler.post(() -> {
            if (container == null || ctx == null) return;

            Notification n = new Notification(message, type, durationMs);
            NotificationView view = new NotificationView(ctx, n);
            n.view = view;

            float density = ctx.getResources().getDisplayMetrics().density;
            int hPx = (int)(NotificationView.H_DP * density);
            int wPx = (int)(NotificationView.W_DP * density);
            int margin = (int)(8 * density);

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(wPx, hPx);
            lp.gravity = Gravity.BOTTOM | Gravity.END;
            lp.bottomMargin = margin + active.size() * (hPx + margin);
            lp.rightMargin  = margin;

            container.addView(view, lp);
            active.add(n);

            // 滑入动画
            view.setTranslationX(wPx + margin);
            view.animate()
                    .translationX(0f)
                    .setDuration(320)
                    .setInterpolator(new OvershootInterpolator(0.7f))
                    .start();

            // 定时消失
            handler.postDelayed(() -> dismiss(n), durationMs);
        });
    }

    private static void dismiss(Notification n) {
        if (n.view == null) return;
        NotificationView view = n.view;
        view.animate()
                .translationX(view.getWidth() + 16)
                .alpha(0f)
                .setDuration(280)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    if (container != null) container.removeView(view);
                    active.remove(n);
                    reshufflePositions();
                })
                .start();
    }

    private static void reshufflePositions() {
        if (ctx == null) return;
        float density = ctx.getResources().getDisplayMetrics().density;
        int hPx   = (int)(NotificationView.H_DP * density);
        int margin= (int)(8 * density);

        for (int i = 0; i < active.size(); i++) {
            Notification n = active.get(i);
            if (n.view == null) continue;
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) n.view.getLayoutParams();
            int target = margin + i * (hPx + margin);
            if (lp.bottomMargin != target) {
                lp.bottomMargin = target;
                n.view.setLayoutParams(lp);
            }
        }
    }

    // ===== Module 实现 =====

    public NotificationsModule() {
        super("Notifications", ModuleCategory.VISUAL,
                "Show notifications on module toggle (Solstice style)");
    }

    @Override
    public void onEnable() {
        ModuleManager.addToggleListener(this);
        notify("Notifications enabled", Type.SUCCESS, 2500);
    }

    @Override
    public void onDisable() {
        ModuleManager.removeToggleListener(this);
    }

    /** 每次有模块切换时触发 */
    @Override
    public void onModuleToggled(Module module) {
        if (module == this) return; // 不通知自身
        String msg  = module.getName() + (module.isEnabled() ? " enabled" : " disabled");
        Type   type = module.isEnabled() ? Type.SUCCESS : Type.INFO;
        notify(msg, type, 2500);
    }
}
