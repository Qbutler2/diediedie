package com.phoenix.gui.module.impl.visual;

import android.content.Context;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.ui.ThemeManager;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

import java.util.ArrayList;
import java.util.List;

/**
 * NotificationsModule — 仿 Solstice 风格
 * 右下角滑入，带进度条 + 渐变色，支持限制数量。
 */
public class NotificationsModule extends Module implements ModuleToggleListener {

    public enum Type { INFO, SUCCESS, WARNING }

    // ── 设置 ──
    private static boolean colorGradient   = false;
    private static boolean limitNotifs     = false;
    private static int     maxNotifs       = 6;
    private static boolean showOnToggle    = true;

    // ── 单条通知 ──
    public static class Notification {
        public final String  message;
        public final Type    type;
        public final long    duration;
        public long          startTime;
        public NotificationView view;

        public Notification(String msg, Type type, long duration) {
            this.message   = msg;
            this.type      = type;
            this.duration  = duration;
            this.startTime = System.currentTimeMillis();
        }

        public float getProgress() {
            return 1f - Math.min(1f, (float)(System.currentTimeMillis() - startTime) / duration);
        }

        public boolean isExpired() {
            return System.currentTimeMillis() - startTime > duration + 600;
        }
    }

    // ── 通知 View（Solstice 风格）──
    public static class NotificationView extends View {
        static final int H_DP = 48;
        static final int W_DP = 230;
        private static final int R_DP  = 6;
        private static final int BAR_H = 3;

        final Notification notif;
        private final Paint bgPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barBgPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint msgPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF bgRect  = new RectF();
        private final RectF barRect = new RectF();
        private final RectF barBgR  = new RectF();
        private final RectF accRect = new RectF();

        public NotificationView(Context ctx, Notification n) {
            super(ctx);
            this.notif = n;
            setLayerType(LAYER_TYPE_SOFTWARE, null);

            bgPaint.setColor(0xF0101414);

            int color = typeColor();
            barPaint.setColor(color);
            accentPaint.setColor(color);
            barBgPaint.setColor(0x1AFFFFFF);

            labelPaint.setTextSize(dp(12));
            labelPaint.setTypeface(Typeface.DEFAULT_BOLD);
            labelPaint.setColor(color);
            labelPaint.setAntiAlias(true);

            msgPaint.setTextSize(dp(11.5f));
            msgPaint.setColor(0xFFDDDDDD);
            msgPaint.setAntiAlias(true);

            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(dp(0.8f));
            borderPaint.setColor(0x28FFFFFF);

            shadowPaint.setColor(0xFF000000);
            shadowPaint.setMaskFilter(new BlurMaskFilter(dp(8), BlurMaskFilter.Blur.NORMAL));
        }

        private int typeColor() {
            switch (notif.type) {
                case SUCCESS: return ThemeManager.COLOR_SUCCESS;
                case WARNING: return ThemeManager.COLOR_WARNING;
                default:      return ThemeManager.getThemeColor();
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w   = getWidth();
            float h   = getHeight();
            float r   = dp(R_DP);
            float barH= dp(BAR_H);
            float accW= dp(3f);
            float progress = notif.getProgress();

            // 阴影
            canvas.drawRoundRect(new RectF(dp(2), dp(2), w - dp(2), h - barH), r, r, shadowPaint);

            // 背景
            bgRect.set(0, 0, w, h - barH);
            canvas.drawRoundRect(bgRect, r, r, bgPaint);

            // 进度条背景（Solstice 风格：右侧变暗）
            barBgR.set(w * progress, 0, w, h - barH);
            canvas.save();
            Path clip = new Path();
            clip.addRoundRect(bgRect, r, r, Path.Direction.CW);
            canvas.clipPath(clip);
            canvas.drawRect(barBgR, barBgPaint);
            canvas.restore();

            // 边框
            canvas.drawRoundRect(bgRect, r, r, borderPaint);

            // 左侧 accent 条
            accRect.set(0, dp(6), accW, h - barH - dp(6));
            canvas.drawRoundRect(accRect, accW / 2, accW / 2, accentPaint);

            // 图标 + 文字
            String icon;
            switch (notif.type) {
                case SUCCESS: icon = "✓ "; break;
                case WARNING: icon = "⚠ "; break;
                default:      icon = "● "; break;
            }
            float cy = (h - barH) / 2f + dp(4.5f);
            float textX = dp(10);
            canvas.drawText(icon, textX, cy, labelPaint);
            float labelW = labelPaint.measureText(icon);

            // 消息截断
            float maxMsgW = w - textX - labelW - dp(8);
            String msg = notif.message;
            while (msg.length() > 1 && msgPaint.measureText(msg + "…") > maxMsgW) {
                msg = msg.substring(0, msg.length() - 1);
            }
            if (!msg.equals(notif.message)) msg += "…";
            canvas.drawText(msg, textX + labelW, cy, msgPaint);

            // 底部进度条（Solstice：从右到左消耗，带渐变）
            barBgR.set(0, h - barH, w, h);
            canvas.drawRect(barBgR, barBgPaint);

            if (colorGradient) {
                // 渐变进度条
                int c1 = typeColor();
                int c2 = ThemeManager.getGradientEnd();
                LinearGradient grad = new LinearGradient(0, 0, w * progress, 0,
                        c1, c2, Shader.TileMode.CLAMP);
                barPaint.setShader(grad);
            } else {
                barPaint.setShader(null);
                barPaint.setColor(typeColor());
            }
            barRect.set(0, h - barH, w * progress, h);
            canvas.drawRect(barRect, barPaint);

            invalidate();
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension((int) dp(W_DP), (int) dp(H_DP));
        }

        private float dp(float v) {
            return v * getResources().getDisplayMetrics().density;
        }
    }

    // ── 静态管理器 ──
    private static final List<Notification> active = new ArrayList<>();
    private static FrameLayout container;
    private static Context     ctx;
    private static final Handler handler = new Handler(Looper.getMainLooper());

    public static void init(FrameLayout notifContainer, Context context) {
        container = notifContainer;
        ctx       = context.getApplicationContext();
    }

    public static void notify(String message, Type type, long durationMs) {
        handler.post(() -> {
            if (container == null || ctx == null) return;
            if (limitNotifs && active.size() >= maxNotifs) return;

            Notification n = new Notification(message, type, durationMs);
            NotificationView view = new NotificationView(ctx, n);
            n.view = view;

            float density = ctx.getResources().getDisplayMetrics().density;
            int hPx   = (int)(NotificationView.H_DP * density);
            int wPx   = (int)(NotificationView.W_DP * density);
            int margin= (int)(10 * density);

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(wPx, hPx);
            lp.gravity     = Gravity.BOTTOM | Gravity.END;
            lp.bottomMargin= margin + active.size() * (hPx + margin);
            lp.rightMargin = margin;
            container.addView(view, lp);
            active.add(n);

            // 从右侧滑入（Solstice 风格）
            view.setTranslationX(wPx + margin * 2);
            view.animate()
                    .translationX(0f)
                    .setDuration(350)
                    .setInterpolator(new OvershootInterpolator(0.6f))
                    .start();

            handler.postDelayed(() -> dismiss(n), durationMs);
        });
    }

    private static void dismiss(Notification n) {
        if (n.view == null) return;
        NotificationView view = n.view;
        view.animate()
                .translationX(view.getWidth() + 20)
                .alpha(0f)
                .setDuration(300)
                .setInterpolator(new DecelerateInterpolator(1.5f))
                .withEndAction(() -> {
                    if (container != null) container.removeView(view);
                    active.remove(n);
                    reshufflePositions();
                }).start();
    }

    private static void reshufflePositions() {
        if (ctx == null) return;
        float density = ctx.getResources().getDisplayMetrics().density;
        int hPx   = (int)(NotificationView.H_DP * density);
        int margin= (int)(10 * density);
        for (int i = 0; i < active.size(); i++) {
            Notification n = active.get(i);
            if (n.view == null) continue;
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) n.view.getLayoutParams();
            lp.bottomMargin = margin + i * (hPx + margin);
            n.view.setLayoutParams(lp);
        }
    }

    // ── Module 实现 ──
    public NotificationsModule() {
        super("Notifications", ModuleCategory.VISUAL,
                "Solstice-style notifications on module toggle");
    }

    @Override
    public void onEnable() {
        ModuleManager.addToggleListener(this);
        notify("Notifications enabled", Type.SUCCESS, 2000);
    }

    @Override
    public void onDisable() {
        ModuleManager.removeToggleListener(this);
    }

    @Override
    public void onModuleToggled(Module module) {
        if (!showOnToggle || module == this) return;
        String msg  = module.getName() + (module.isEnabled() ? " enabled" : " disabled");
        Type   type = module.isEnabled() ? Type.SUCCESS : Type.INFO;
        notify(msg, type, 2500);
    }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSwitch("Show on toggle", showOnToggle, v -> showOnToggle = v);
        subMenu.addSwitch("Color gradient", colorGradient, v -> colorGradient = v);
        subMenu.addSwitch("Limit notifications", limitNotifs, v -> limitNotifs = v);
        subMenu.addSlider("Max notifications", 1, 20, maxNotifs, "%d",
                v -> maxNotifs = v);
    }
}
