package com.phoenix.gui;

import android.os.*;
import android.view.View;
import android.view.Window;
import android.widget.*;
import androidx.activity.ComponentActivity;
import com.wufan.client.R;
import com.phoenix.gui.config.ConfigManager;
import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.module.ShortcutToggleListener;
import com.phoenix.gui.ui.ArraylistView;
import com.phoenix.gui.ui.ShortcutButton;
import com.phoenix.gui.ui.dynamic.DynamicIslandWindow;
import com.phoenix.gui.ui.UI;
import android.view.Gravity;
import android.widget.FrameLayout;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends ComponentActivity implements ModuleToggleListener, ShortcutToggleListener {

    private Button btnStart, btnStop, btnTestProgress, btnTestSwitch, btnHideAll, btnSave, btnToggleDebug;
    private EditText etUsername;
    private SeekBar seekScale;
    private ScrollView debugPanel;
    private FrameLayout shortcutsContainer;

    private final Map<Module, ShortcutButton> shortcutButtons = new HashMap<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        setContentView(R.layout.activity_main);

        UI.init(this);

        bindViews();
        loadConfig();
        setListeners();

        // 启动时自动显示 GUI
        startGUI();
        updateBtnState();
    }

    private void bindViews() {
        btnStart        = findViewById(R.id.btn_start);
        btnStop         = findViewById(R.id.btn_stop);
        btnTestProgress = findViewById(R.id.btn_test_progress);
        btnTestSwitch   = findViewById(R.id.btn_test_switch);
        btnHideAll      = findViewById(R.id.btn_hide_all);
        btnSave         = findViewById(R.id.btn_save);
        btnToggleDebug  = findViewById(R.id.btn_toggle_debug);
        etUsername      = findViewById(R.id.et_username);
        seekScale       = findViewById(R.id.seek_scale);
        debugPanel      = findViewById(R.id.debug_panel);
        shortcutsContainer = findViewById(R.id.shortcuts_container);
    }

    private void loadConfig() {
        etUsername.setText(ConfigManager.getDynamicIslandUsername());
        seekScale.setProgress((int)(ConfigManager.getDynamicIslandScale() * 100));
    }

    private void saveConfig() {
        String name  = etUsername.getText().toString().trim();
        float  scale = seekScale.getProgress() / 100f;
        ConfigManager.setDynamicIslandUsername(name);
        ConfigManager.setDynamicIslandScale(scale);
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island != null && island.isShowing()) island.updateConfig(scale, name);
        toast("saved");
    }

    private void setListeners() {
        btnStart.setOnClickListener(v -> startGUI());
        btnStop.setOnClickListener(v -> stopGUI());
        btnSave.setOnClickListener(v -> saveConfig());
        btnToggleDebug.setOnClickListener(v -> toggleDebugPanel());
        btnTestProgress.setOnClickListener(v -> showProgress());
        btnTestSwitch.setOnClickListener(v -> showSwitch());
        btnHideAll.setOnClickListener(v -> hideAll());
    }

    private void startGUI() {
        if (UI.isShowing()) return;
        try {
            UI.show(this);
            ModuleManager.addToggleListener(this);
            ModuleManager.addShortcutListener(this);
            updateBtnState();
            toast("GUI started");
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void stopGUI() {
        if (!UI.isShowing()) return;
        try {
            for (ShortcutButton btn : shortcutButtons.values()) {
                try { btn.destroy(); } catch (Exception ignored) {}
            }
            shortcutButtons.clear();
            if (shortcutsContainer != null) shortcutsContainer.removeAllViews();
            ModuleManager.removeToggleListener(this);
            ModuleManager.removeShortcutListener(this);
            UI.hide();
            updateBtnState();
            toast("GUI stopped");
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void updateBtnState() {
        boolean running = UI.isShowing();
        btnStart.setEnabled(!running);
        btnStop.setEnabled(running);
        btnTestProgress.setEnabled(running);
        btnTestSwitch.setEnabled(running);
        btnHideAll.setEnabled(running);
    }

    private void showProgress() {
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island == null || !island.isShowing()) return;
        try { island.addOrUpdateProgress("test_progress", "progress", "subtitle", null, 0.65f, null); }
        catch (Exception e) { e.printStackTrace(); }
    }

    private void showSwitch() {
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island == null || !island.isShowing()) return;
        try { island.addSwitch("test_switch", "test function", true); }
        catch (Exception e) { e.printStackTrace(); }
    }

    private void hideAll() {
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island != null && island.isShowing()) {
            try { island.hideAllTasks(); } catch (Exception e) { e.printStackTrace(); }
        }
    }

    private void toggleDebugPanel() {
        debugPanel.setVisibility(debugPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    // ── 关键：按返回键不退出，移到后台，GUI 继续显示 ──
    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    public void onModuleToggled(Module module) {
        UI.onModuleToggled(module);
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island != null && island.isShowing()) {
            try { island.addSwitch("module_" + module.getName(), module.getName(), module.isEnabled()); }
            catch (Exception ignored) {}
        }
        ArraylistView av = UI.getArraylistView();
        if (av != null) {
            try {
                if (module.isEnabled()) av.addModule(module.getName());
                else av.removeModule(module.getName());
            } catch (Exception ignored) {}
        }
    }

    @Override
    public void onShortcutToggled(Module module, boolean enabled) {
        runOnUiThread(() -> {
            if (enabled) createShortcut(module);
            else removeShortcut(module);
        });
    }

    private void createShortcut(Module module) {
        if (shortcutsContainer == null || shortcutButtons.containsKey(module)) return;
        try {
            ShortcutButton btn = new ShortcutButton(this, module);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER);
            btn.setLayoutParams(lp);
            shortcutsContainer.addView(btn);
            btn.show();
            shortcutButtons.put(module, btn);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void removeShortcut(Module module) {
        ShortcutButton btn = shortcutButtons.get(module);
        if (btn == null) return;
        try {
            btn.hide();
            btn.postDelayed(() -> {
                if (shortcutsContainer != null) shortcutsContainer.removeView(btn);
                btn.destroy();
            }, 250);
        } catch (Exception e) { e.printStackTrace(); }
        shortcutButtons.remove(module);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        UI.cleanup();
    }
}
