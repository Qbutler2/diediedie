package com.phoenix.gui;

import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.View;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.*;
import androidx.activity.ComponentActivity;
import com.wufan.client.R;
import com.phoenix.gui.config.ConfigManager;
import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.module.ModuleToggleListener;
import com.phoenix.gui.module.ShortcutToggleListener;
import com.phoenix.gui.ui.ArraylistModule;
import com.phoenix.gui.ui.ArraylistView;
import com.phoenix.gui.ui.DynamicColorExtractor;
import com.phoenix.gui.ui.FloatBallView;
import com.phoenix.gui.ui.ShortcutButton;
import com.phoenix.gui.ui.dynamic.DynamicIslandWindow;
import com.phoenix.gui.ui.ThemeManager;
import com.phoenix.gui.ui.UI;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class MainActivity extends ComponentActivity implements ModuleToggleListener, ShortcutToggleListener {
    
    private boolean wifiState = true;
    private static final int OVERLAY_PERMISSION_REQUEST = 1001;
    
    private Button btnStart, btnStop, btnTestProgress, btnTestSwitch, btnHideAll, btnSave, btnToggleDebug, btnToggleArraylist;
    private Button btnAddRandom, btnRemoveRandom, btnResetArraylist;
    private Button btnOverlay; // 悬浮窗按钮
    private EditText etUsername;
    private SeekBar seekScale;
    private ScrollView debugPanel;
    private FrameLayout shortcutsContainer;
    
    private final Map<Module, ShortcutButton> shortcutButtons = new HashMap<>();
    private final List<String> allTestModules = new ArrayList<>();
    private final Random random = new Random();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        setContentView(R.layout.activity_main);
        
        UI.init(this);

        initAllTestModules();
        bindViews();
        loadConfig();
        setListeners();
        updateBtnState();

        // 启动时自动检查悬浮窗权限
        checkAndRequestPermissions();
    }

    /**
     * 检查悬浮窗权限，并提示用户
     * 如果已有权限直接启动 OverlayService
     */
    private void checkAndRequestPermissions() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                // 弹对话框引导用户授权
                new android.app.AlertDialog.Builder(this)
                    .setTitle("需要权限")
                    .setMessage("Wufan Client 需要「显示在其他应用上层」权限才能将 GUI 显示在最顶层。\n\n请在下一页开启此权限。")
                    .setPositiveButton("去设置", (d, w) -> {
                        Intent intent = new Intent(
                            android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            android.net.Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
                    })
                    .setNegativeButton("跳过", (d, w) -> {
                        toast("跳过权限：GUI 将只在应用内部显示");
                    })
                    .show();
            } else {
                // 已有权限，自动启动 OverlayService
                startOverlayService();
            }
        } else {
            startOverlayService();
        }
    }

    private void initAllTestModules() {}

    private void bindViews() {
        btnStart          = findViewById(R.id.btn_start);
        btnStop           = findViewById(R.id.btn_stop);
        btnTestProgress   = findViewById(R.id.btn_test_progress);
        btnTestSwitch     = findViewById(R.id.btn_test_switch);
        btnHideAll        = findViewById(R.id.btn_hide_all);
        btnSave           = findViewById(R.id.btn_save);
        btnToggleDebug    = findViewById(R.id.btn_toggle_debug);
        btnToggleArraylist= findViewById(R.id.btn_toggle_arraylist);
        btnAddRandom      = findViewById(R.id.btn_add_random_module);
        btnRemoveRandom   = findViewById(R.id.btn_remove_random_module);
        btnResetArraylist = findViewById(R.id.btn_reset_arraylist);
        btnOverlay        = findViewById(R.id.btn_overlay);
        etUsername        = findViewById(R.id.et_username);
        seekScale         = findViewById(R.id.seek_scale);
        debugPanel        = findViewById(R.id.debug_panel);
        shortcutsContainer= findViewById(R.id.shortcuts_container);
    }

    private void loadConfig() {
        etUsername.setText(ConfigManager.getDynamicIslandUsername());
        seekScale.setProgress((int)(ConfigManager.getDynamicIslandScale() * 100));
    }

    private void saveConfig() {
        String name  = etUsername.getText().toString().trim();
        float  scale = seekScale.getProgress() / 100f;
        ConfigManager.setDynamicIslandUsername(name);
        ConfigManager.setDynamicIslandScale(scale);
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island != null && island.isShowing()) island.updateConfig(scale, name);
        toast("saved");
    }

    private void setListeners() {
        btnStart.setOnClickListener(v -> startGUI());
        btnStop.setOnClickListener(v -> stopGUI());
        btnSave.setOnClickListener(v -> saveConfig());
        btnToggleDebug.setOnClickListener(v -> toggleDebugPanel());

        if (btnOverlay != null) btnOverlay.setOnClickListener(v -> launchOverlay());

        if (btnToggleArraylist != null) btnToggleArraylist.setOnClickListener(v -> toggleArraylist());
        if (btnAddRandom    != null) btnAddRandom.setOnClickListener(v -> addRandomModule());
        if (btnRemoveRandom != null) btnRemoveRandom.setOnClickListener(v -> removeRandomModule());
        if (btnResetArraylist != null) btnResetArraylist.setOnClickListener(v -> {
            addDefaultArraylistModules();
            toast("Arraylist reset");
        });

        btnTestProgress.setOnClickListener(v -> { showProgress(); toast("test progress"); });
        btnTestSwitch.setOnClickListener(v -> showSwitch());
        btnHideAll.setOnClickListener(v -> { hideAll(); toast("hide all"); });
    }

    // ── 悬浮窗 ──

    /**
     * 启动悬浮窗：先检查 SYSTEM_ALERT_WINDOW 权限，再启动 OverlayService
     */
    private void launchOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            // 引导用户去设置页授权
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
            toast("请授予「显示在其他应用上层」权限后再点击");
        } else {
            startOverlayService();
        }
    }

    private void startOverlayService() {
        Intent svc = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
        toast("悬浮窗已启动，可切换到其他应用");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQUEST) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                startOverlayService();
            } else {
                toast("权限未授予，无法启动悬浮窗");
            }
        }
    }

    // ── GUI 控制 ──

    private void updateBtnState() {
        boolean running = UI.isShowing();
        btnStart.setEnabled(!running);
        btnStop.setEnabled(running);
        btnTestProgress.setEnabled(running);
        btnTestSwitch.setEnabled(running);
        btnHideAll.setEnabled(running);
        boolean al = running && UI.getArraylistView() != null;
        if (btnToggleArraylist != null) btnToggleArraylist.setEnabled(running);
        if (btnAddRandom    != null) btnAddRandom.setEnabled(al);
        if (btnRemoveRandom != null) btnRemoveRandom.setEnabled(al);
        if (btnResetArraylist != null) btnResetArraylist.setEnabled(al);
    }

    private void startGUI() {
        if (UI.isShowing()) return;
        try { UI.show(this); updateBtnState(); toast("GUI started"); }
        catch (Exception e) { e.printStackTrace(); toast("Failed: " + e.getMessage()); }
    }

    private void stopGUI() {
        if (!UI.isShowing()) return;
        try {
            for (ShortcutButton btn : shortcutButtons.values()) { try { btn.destroy(); } catch (Exception ignored) {} }
            shortcutButtons.clear();
            shortcutsContainer.removeAllViews();
            UI.hide(); updateBtnState(); toast("GUI stopped");
        } catch (Exception e) { e.printStackTrace(); toast("Failed: " + e.getMessage()); }
    }

    private void addDefaultArraylistModules() {
        ArraylistView av = UI.getArraylistView();
        if (av != null) av.clearModules();
    }

    private void addRandomModule() {
        ArraylistView av = UI.getArraylistView();
        if (av == null || allTestModules.isEmpty()) return;
        String name = allTestModules.get(random.nextInt(allTestModules.size()));
        av.addModule(new ArraylistModule(name));
        toast("Added: " + name);
    }

    private void removeRandomModule() {
        ArraylistView av = UI.getArraylistView();
        if (av != null && !av.getModules().isEmpty()) {
            int idx  = random.nextInt(av.getModules().size());
            String n = av.getModules().get(idx).getName();
            av.removeModule(n);
            toast("Removed: " + n);
        } else {
            toast("Arraylist is empty");
        }
    }

    private void toggleArraylist() {
        ArraylistView av = UI.getArraylistView();
        if (av == null) { toast("请先启动 GUI"); return; }
        if (av.getVisibility() == View.VISIBLE) { av.hide(); toast("Arraylist 已隐藏"); }
        else { av.show(); toast("Arraylist 已显示"); }
        updateBtnState();
    }

    private void showProgress() {
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island == null || !island.isShowing()) return;
        try { island.addOrUpdateProgress("test_progress", "progress", "im subtitle", null, 0.65f, null); }
        catch (Exception e) { e.printStackTrace(); }
    }

    private void showSwitch() {
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island == null || !island.isShowing()) return;
        try {
            wifiState = !wifiState;
            island.addSwitch("test_switch", "im a function", wifiState);
            toast("test switch -> " + (wifiState ? "ON" : "OFF"));
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void hideAll() {
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island != null && island.isShowing()) { try { island.hideAllTasks(); } catch (Exception e) { e.printStackTrace(); } }
    }

    private void toggleDebugPanel() {
        debugPanel.setVisibility(debugPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    // ── Listeners ──

    @Override
    public void onModuleToggled(Module module) {
        UI.onModuleToggled(module);

        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island != null && island.isShowing()) {
            try { island.addSwitch("module_" + module.getName(), module.getName(), module.isEnabled()); }
            catch (Exception e) { e.printStackTrace(); }
        }

        ShortcutButton btn = shortcutButtons.get(module);
        if (btn != null) { try { btn.updateStyle(); } catch (Exception e) { e.printStackTrace(); } }

        ArraylistView av = UI.getArraylistView();
        if (av != null) {
            try {
                if (module.isEnabled()) av.addModule(module.getName());
                else av.removeModule(module.getName());
            } catch (Exception e) { e.printStackTrace(); }
        }
    }

    @Override
    public void onShortcutToggled(Module module, boolean enabled) {
        if (enabled) createShortcut(module);
        else removeShortcut(module);
    }

    private void createShortcut(Module module) {
        if (shortcutButtons.containsKey(module)) return;
        try {
            android.view.WindowManager wm = (android.view.WindowManager) getSystemService(android.content.Context.WINDOW_SERVICE);
            ShortcutButton btn = new ShortcutButton(this, module, wm);
            wm.addView(btn, btn.wlp);
            btn.show();
            shortcutButtons.put(module, btn);
        } catch (Exception e) { e.printStackTrace(); toast("创建快捷按钮失败: " + e.getMessage()); }
    }

    private void removeShortcut(Module module) {
        ShortcutButton btn = shortcutButtons.remove(module);
        if (btn == null) return;
        try {
            android.view.WindowManager wm = (android.view.WindowManager) getSystemService(android.content.Context.WINDOW_SERVICE);
            btn.hide(() -> {
                try { wm.removeView(btn); } catch (Exception ignored) {}
                btn.destroy();
            });
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
        android.util.Log.d("PHOENIX", s);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (UI.isShowing()) stopGUI();
        UI.cleanup();
    }

    @Override
    public void onBackPressed() {
        if (UI.isShowing()) stopGUI();
        else super.onBackPressed();
    }
}
