package com.phoenix.gui;

import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.widget.*;
import androidx.activity.ComponentActivity;
import com.wufan.client.R;
import com.phoenix.gui.config.ConfigManager;
import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleManager;
import com.phoenix.gui.ui.dynamic.DynamicIslandWindow;
import com.phoenix.gui.ui.UI;

/**
 * MainActivity - 只做权限检查和设置，GUI 完全由 OverlayService 管理
 */
public class MainActivity extends ComponentActivity {

    private static final int OVERLAY_PERMISSION_REQUEST = 1001;

    private Button btnStart, btnStop, btnTestProgress, btnTestSwitch, btnHideAll, btnSave, btnToggleDebug;
    private EditText etUsername;
    private SeekBar seekScale;
    private ScrollView debugPanel;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        setContentView(R.layout.activity_main);

        // 只初始化 ConfigManager 等，不初始化 GUI
        UI.init(this);

        bindViews();
        loadConfig();
        setListeners();
        updateBtnState();

        checkAndRequestPermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateBtnState();
    }

    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            new android.app.AlertDialog.Builder(this)
                .setTitle("需要权限")
                .setMessage("需要「显示在其他应用上层」权限才能将 GUI 显示在最顶层。\n\n请在下一页开启此权限。")
                .setPositiveButton("去设置", (d, w) -> {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
                })
                .setNegativeButton("跳过", null)
                .show();
        } else {
            startOverlayService();
        }
    }

    private void bindViews() {
        btnStart        = findViewById(R.id.btn_start);
        btnStop         = findViewById(R.id.btn_stop);
        btnTestProgress = findViewById(R.id.btn_test_progress);
        btnTestSwitch   = findViewById(R.id.btn_test_switch);
        btnHideAll      = findViewById(R.id.btn_hide_all);
        btnSave         = findViewById(R.id.btn_save);
        btnToggleDebug  = findViewById(R.id.btn_toggle_debug);
        etUsername      = findViewById(R.id.et_username);
        seekScale       = findViewById(R.id.seek_scale);
        debugPanel      = findViewById(R.id.debug_panel);
    }

    private void loadConfig() {
        etUsername.setText(ConfigManager.getDynamicIslandUsername());
        seekScale.setProgress((int)(ConfigManager.getDynamicIslandScale() * 100));
    }

    private void saveConfig() {
        String name  = etUsername.getText().toString().trim();
        float  scale = seekScale.getProgress() / 100f;
        ConfigManager.setDynamicIslandUsername(name);
        ConfigManager.setDynamicIslandScale(scale);
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island != null && island.isShowing()) island.updateConfig(scale, name);
        toast("saved");
    }

    private void setListeners() {
        btnStart.setOnClickListener(v -> startGUI());
        btnStop.setOnClickListener(v -> stopGUI());
        btnSave.setOnClickListener(v -> saveConfig());
        btnToggleDebug.setOnClickListener(v -> toggleDebugPanel());
        btnTestProgress.setOnClickListener(v -> showProgress());
        btnTestSwitch.setOnClickListener(v -> showSwitch());
        btnHideAll.setOnClickListener(v -> hideAll());
    }

    // ── GUI 控制（全部委托给 OverlayService）──

    private void startGUI() {
        if (isServiceRunning()) { toast("GUI 已在运行"); return; }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            checkAndRequestPermissions();
            return;
        }
        startOverlayService();
        updateBtnState();
    }

    private void stopGUI() {
        stopService(new Intent(this, OverlayService.class));
        updateBtnState();
        toast("GUI 已停止");
    }

    private void startOverlayService() {
        Intent svc = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
        updateBtnState();
        toast("GUI 已启动，可切换到其他应用");
    }

    private boolean isServiceRunning() {
        return OverlayService.instance != null;
    }

    private void updateBtnState() {
        boolean running = isServiceRunning();
        btnStart.setEnabled(!running);
        btnStop.setEnabled(running);
        btnTestProgress.setEnabled(running);
        btnTestSwitch.setEnabled(running);
        btnHideAll.setEnabled(running);
    }

    // ── 测试按钮（对 OverlayService 里的 GUI 操作）──

    private void showProgress() {
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island == null || !island.isShowing()) { toast("GUI 未启动"); return; }
        try { island.addOrUpdateProgress("test_progress", "progress", "subtitle", null, 0.65f, null); }
        catch (Exception e) { e.printStackTrace(); }
    }

    private void showSwitch() {
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island == null || !island.isShowing()) { toast("GUI 未启动"); return; }
        try { island.addSwitch("test_switch", "test function", true); }
        catch (Exception e) { e.printStackTrace(); }
    }

    private void hideAll() {
        DynamicIslandWindow island = UI.getDynamicIsland();
        if (island != null && island.isShowing()) {
            try { island.hideAllTasks(); } catch (Exception e) { e.printStackTrace(); }
        }
    }

    private void toggleDebugPanel() {
        debugPanel.setVisibility(debugPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQUEST) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                startOverlayService();
            } else {
                toast("权限未授予，无法启动 GUI");
            }
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        UI.cleanup();
    }
}
