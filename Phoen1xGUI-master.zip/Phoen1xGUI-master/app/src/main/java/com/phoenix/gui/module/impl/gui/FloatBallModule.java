package com.phoenix.gui.module.impl.gui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.FloatBallView;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

public class FloatBallModule extends Module {

    private WindowManager windowManager;
    private FrameLayout rootView;

    public FloatBallModule() {
        super("FloatBall", ModuleCategory.MISC, "ClickGUI floating ball");
    }

    @Override protected void onEnable()  { show(); }
    @Override protected void onDisable() { hide(); }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addText("Tap to open/close ClickGUI. Drag to move.");
    }

    private void show() {
        Context ctx = UI.getContext();
        if (ctx == null) return;
        windowManager = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (windowManager == null) return;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams wlp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.START;

        FrameLayout menusContainer = new FrameLayout(ctx);
        menusContainer.setVisibility(View.GONE);

        rootView = new FrameLayout(ctx);
        rootView.addView(menusContainer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        FloatBallView floatBall = new FloatBallView(ctx, menusContainer);
        rootView.addView(floatBall, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        try {
            windowManager.addView(rootView, wlp);
            floatBall.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void hide() {
        if (rootView != null && windowManager != null) {
            try { windowManager.removeView(rootView); } catch (Exception ignored) {}
            rootView = null;
        }
        windowManager = null;
    }
}
