package com.phoenix.gui.module.impl.gui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.FloatBallView;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

/**
 * FloatBall 独立悬浮窗 Module。
 * 浮球本身用 WRAP_CONTENT 小窗口，不遮挡底层。
 * 菜单打开时切换为 MATCH_PARENT 接收触摸，关闭后缩回小窗口。
 */
public class FloatBallModule extends Module {

    private WindowManager wm;
    private FrameLayout   rootView;      // 整个悬浮窗根容器
    private FloatBallView floatBallView;
    private FrameLayout   menusContainer;
    private WindowManager.LayoutParams wlp;

    public FloatBallModule() {
        super("FloatBall", ModuleCategory.MISC, "ClickGUI floating ball");
    }

    @Override protected void onEnable()  { show(); }
    @Override protected void onDisable() { hide(); }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addText("Tap to open/close ClickGUI. Drag to move.");
    }

    private void show() {
        Context ctx = UI.getContext();
        if (ctx == null) return;
        wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        // 初始：WRAP_CONTENT，只覆盖浮球本身
        wlp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.CENTER;

        menusContainer = new FrameLayout(ctx);
        menusContainer.setVisibility(View.GONE);

        // rootView 同时含浮球和 menusContainer
        // menusContainer 用 MATCH_PARENT 但此时根窗口是 WRAP_CONTENT 所以不会铺满
        rootView = new FrameLayout(ctx);

        floatBallView = new FloatBallView(ctx, menusContainer);

        // 浮球注册菜单开关回调 → 切换窗口尺寸
        floatBallView.setOnMenuVisibilityChangedListener(open -> {
            if (wm == null || rootView == null) return;
            if (open) {
                // 菜单打开：铺满全屏接收触摸
                menusContainer.setVisibility(View.VISIBLE);
                wlp.width  = WindowManager.LayoutParams.MATCH_PARENT;
                wlp.height = WindowManager.LayoutParams.MATCH_PARENT;
                wlp.gravity = Gravity.TOP | Gravity.START;
            } else {
                // 菜单关闭：缩回 WRAP_CONTENT
                menusContainer.setVisibility(View.GONE);
                wlp.width  = WindowManager.LayoutParams.WRAP_CONTENT;
                wlp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                wlp.gravity = Gravity.CENTER;
            }
            try { wm.updateViewLayout(rootView, wlp); } catch (Exception ignored) {}
        });

        rootView.addView(menusContainer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        rootView.addView(floatBallView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        try {
            wm.addView(rootView, wlp);
            floatBallView.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void hide() {
        if (rootView != null && wm != null) {
            try { wm.removeView(rootView); } catch (Exception ignored) {}
            rootView = null;
        }
        if (floatBallView != null) {
            floatBallView.destroy();
            floatBallView = null;
        }
        menusContainer = null;
        wm = null;
    }
}
