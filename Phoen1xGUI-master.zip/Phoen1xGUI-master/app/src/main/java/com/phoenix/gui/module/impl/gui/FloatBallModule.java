package com.phoenix.gui.module.impl.gui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.phoenix.gui.module.Module;
import com.phoenix.gui.module.ModuleCategory;
import com.phoenix.gui.ui.FloatBallView;
import com.phoenix.gui.ui.UI;
import com.phoenix.gui.ui.widgets.SubMenuPanel;

/** FloatBall: WRAP_CONTENT 独立窗口，拖动通过 updateViewLayout。菜单容器单独一个 MATCH_PARENT 窗口。 */
public class FloatBallModule extends Module {

    private WindowManager wm;
    private FloatBallView floatBallView;
    private WindowManager.LayoutParams ballWlp;

    // 菜单用独立全屏窗口（FLAG_NOT_TOUCHABLE 关闭时）
    private FrameLayout menusRoot;
    private WindowManager.LayoutParams menusWlp;

    private float dragStartRawX, dragStartRawY;
    private int dragStartWlpX, dragStartWlpY;

    public FloatBallModule() {
        super("FloatBall", ModuleCategory.MISC, "ClickGUI floating ball");
    }

    @Override protected void onEnable()  { show(); }
    @Override protected void onDisable() { hide(); }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addText("Tap to open/close ClickGUI. Drag to move.");
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void show() {
        Context ctx = UI.getContext();
        if (ctx == null) return;
        wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;

        // ── 菜单容器窗口（全屏，默认 NOT_TOUCHABLE，菜单打开时去掉该 flag）
        menusRoot = new FrameLayout(ctx);
        menusRoot.setVisibility(View.GONE);
        menusWlp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        menusWlp.gravity = Gravity.TOP | Gravity.START;

        // ── 浮球窗口（WRAP_CONTENT，居中）
        ballWlp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        ballWlp.gravity = Gravity.CENTER;

        floatBallView = new FloatBallView(ctx, menusRoot);

        // 注册菜单开关回调：切换 menusRoot 的可触摸性
        floatBallView.setOnMenuVisibilityChangedListener(open -> {
            if (wm == null || menusRoot == null) return;
            if (open) {
                menusRoot.setVisibility(View.VISIBLE);
                menusWlp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            } else {
                menusRoot.setVisibility(View.GONE);
                menusWlp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            }
            try { wm.updateViewLayout(menusRoot, menusWlp); } catch (Exception ignored) {}
        });

        // 拖动：用 wlp.x/y + updateViewLayout（不用 setTranslationX）
        floatBallView.setExternalDragListener((rawX, rawY, action) -> {
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    dragStartRawX = rawX;
                    dragStartRawY = rawY;
                    dragStartWlpX = ballWlp.x;
                    dragStartWlpY = ballWlp.y;
                    break;
                case MotionEvent.ACTION_MOVE:
                    ballWlp.x = dragStartWlpX + (int)(rawX - dragStartRawX);
                    ballWlp.y = dragStartWlpY + (int)(rawY - dragStartRawY);
                    try { wm.updateViewLayout(floatBallView, ballWlp); } catch (Exception ignored) {}
                    break;
            }
        });

        try {
            wm.addView(menusRoot, menusWlp);
            wm.addView(floatBallView, ballWlp);
            floatBallView.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void hide() {
        if (floatBallView != null) {
            floatBallView.hide();
            floatBallView.destroy();
            try { if (wm != null) wm.removeView(floatBallView); } catch (Exception ignored) {}
            floatBallView = null;
        }
        if (menusRoot != null) {
            try { if (wm != null) wm.removeView(menusRoot); } catch (Exception ignored) {}
            menusRoot = null;
        }
        wm = null;
    }
}
